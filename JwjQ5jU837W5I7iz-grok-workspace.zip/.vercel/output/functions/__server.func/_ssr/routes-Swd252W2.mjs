import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Check, i as Copy, n as Play, r as Download } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Swd252W2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FAMILIES = [
	{
		id: "apparel",
		name: "Apparel",
		blanks: "Shaka Wear tees, Shaka Wear hoodies, Bella+Canvas shorts",
		focus: "PhotoCraft and EffectCraft",
		upload: "{build}/apparel_final.png",
		note: "",
		traceExtra: "",
		steps: [{
			name: "photocraft_trim",
			module: "photocraft",
			command: "photocraft-cli --input {art} --trim-alpha true --target-dpi 300 --color-profile srgb --dimensions 14x16in --out-dir {work}/apparel/",
			output: "{work}/apparel/trimmed.png",
			validator: null,
			timeout: null
		}, {
			name: "effectcraft_distress",
			module: "effectcraft",
			command: "effectcraft-cli --input {work}/apparel/trimmed.png --filter vintage_screen_300 --output {build}/apparel_final.png",
			output: "{build}/apparel_final.png",
			validator: "png_with_alpha",
			timeout: null
		}]
	},
	{
		id: "knitwear",
		name: "Knitwear",
		blanks: "Knit crewnecks, cardigans, vests",
		focus: "DesignCraft and VectorCraft",
		upload: "{build}/knitwear_final.bmp",
		note: "A BMP stitch grid may be refused by the image library. The run then ends needs_manual_upload and still counts as processed.",
		traceExtra: "--palette-limit {cfg[palette_limit]}",
		steps: [{
			name: "designcraft_stitch_matrix",
			module: "designcraft",
			command: "designcraft-cli --mode stitch_matrix --input {art} --palette-limit {cfg[palette_limit]} --grid-scale {cfg[knit_grid]} --output {build}/knitwear_final.bmp",
			output: "{build}/knitwear_final.bmp",
			validator: "knit_bmp",
			timeout: null
		}]
	},
	{
		id: "accessories",
		name: "Accessories",
		blanks: "AS Colour caps, crossbody bags, Under Armour backpacks",
		focus: "DesignCraft",
		upload: "{build}/accessory_final.pdf",
		note: "Safe-zone bounding boxes and kerning live inside DesignCraft. The orchestrator only checks that the PDF has a header and a trailer.",
		traceExtra: "",
		steps: [{
			name: "designcraft_template",
			module: "designcraft",
			command: "designcraft-cli --template {cfg[template]} --layer artwork --embed {art} --layer care_label --text \"{cfg[care_text]}\" --output {build}/accessory_final.pdf",
			output: "{build}/accessory_final.pdf",
			validator: "pdf",
			timeout: null
		}]
	},
	{
		id: "odd_3d",
		name: "Odd / 3D",
		blanks: "Sublimation socks, Arctic Zone tumblers",
		focus: "DesignCraft and EffectCraft",
		upload: "{build}/odd_final.pdf",
		note: "Bleed is 0.25 in. Cylinder taper is a separate EffectCraft step so a bad wrap never reaches the tumbler deform.",
		traceExtra: "",
		steps: [{
			name: "designcraft_wrap_tile",
			module: "designcraft",
			command: "designcraft-cli --mode wrap_tile --bleed {cfg[bleed_in]} --input {art} --output {work}/odd/tiled.pdf",
			output: "{work}/odd/tiled.pdf",
			validator: "pdf",
			timeout: null
		}, {
			name: "effectcraft_cylinder_taper",
			module: "effectcraft",
			command: "effectcraft-cli --cylinder-taper --input {work}/odd/tiled.pdf --output {build}/odd_final.pdf",
			output: "{build}/odd_final.pdf",
			validator: "pdf",
			timeout: null
		}]
	},
	{
		id: "stationery",
		name: "Stationery",
		blanks: "Karst bound notebooks",
		focus: "DesignCraft and FilmCraft",
		upload: "{build}/print_ready_stationery.pdf",
		note: "The reel is a marketing file, not the Fourthwall upload. Packing slips are not built on this route — a cover exists before any order does.",
		traceExtra: "",
		steps: [{
			name: "designcraft_cover",
			module: "designcraft",
			command: "designcraft-cli --input {cfg[cover_template]} --embed {art} --output {build}/print_ready_stationery.pdf",
			output: "{build}/print_ready_stationery.pdf",
			validator: "pdf",
			timeout: null
		}, {
			name: "filmcraft_reel",
			module: "filmcraft",
			command: "filmcraft-cli --template {cfg[reel_template]} --asset-layer product_front --input {build}/print_ready_stationery.pdf --render-preset {cfg[reel_preset]} --output {build}/promo_reel.mp4",
			output: "{build}/promo_reel.mp4",
			validator: "mp4",
			timeout: "1800s"
		}]
	}
];
var ASSUMPTIONS = [
	"The spec never gave a vectorcraft-cli line. routes.py owns the contract: trace --input --svg-out --pdf-out. Knitwear adds --palette-limit.",
	"Exit code 1 on that trace is the only automatic fallback. Any other trace exit fails the run.",
	"The raster fallback expects a PNG inside --out-dir. DPI comes from POD_FALLBACK_RASTER_DPI, default 600.",
	"stitch_matrix had no input flag in the spec. The route adds --input.",
	"The stationery cover adds --embed and drops --variable-data order_id. There is no order yet.",
	"Vendor Craft binaries are not in this tree. deploy/craft-bin exits 127 until they replace those files. tests/stubs/craft_stub.py is the contract double, not a production tool."
];
var CFG = {
	palette_limit: "6",
	knit_grid: "112x140",
	template: "fourthwall_crossbody_v1",
	care_text: "100% Polyester",
	bleed_in: "0.25",
	cover_template: "notebook_cover_template",
	reel_template: "reel_promo_9_16",
	reel_preset: "tiktok_1080p",
	fallback_dpi: "600"
};
var RUN_ID = "8f3c1a9b-4e20-4c11-9a77-0b1d2e3f4a5b";
var ROOT = "/opt/pod-pipeline";
var TREE = `/opt/pod-pipeline
├── bin/                         Craft CLIs, first on PATH
├── config/pipeline.env          systemd EnvironmentFile
├── config/products.json         template ids, knit grid, care text
├── data/inbox/<account_id>/     scan_inbox, after the file settles
├── sandbox/<run_id>/            scratch; deleted when the run succeeds
├── build/<run_id>/              fsynced finals, kept
├── logs/jobs/<run_id>/          one capped log per attempt
├── sql/schema.sql
├── pod_pipeline/                orchestrator, MCP, Fourthwall client
├── tests/stubs/craft_stub.py    test double only
└── deploy/                      setup-pipeline.sh, compose, systemd`;
var DOCKER_ARGV = `docker run --rm --init --name pod-<id> \\
  --memory 2g --memory-swap 2g \\
  --cpus 1.5 --cpu-shares 256 \\
  --pids-limit 256 --network none \\
  --cap-drop ALL --security-opt no-new-privileges \\
  --read-only --tmpfs /tmp:rw,size=512m -e HOME=/tmp \\
  --user <uid>:<gid> \\
  -v <work>:<work>:rw -v <build>:<build>:rw -w <work> \\
  pod-craft-runner:latest \\
  <craft argv>`;
var NATIVE_ARGV = "nice -n 10 ionice -c 3 <craft argv>";
function resolve(template, vars) {
	return template.replace(/\{cfg\[(\w+)\]\}|\{(\w+)\}/g, (full, cfgKey, key) => {
		if (cfgKey) return vars[cfgKey] ?? full;
		if (key) return vars[key] ?? full;
		return full;
	});
}
function sandboxFor(kind, docker) {
	if (kind === "db") return "postgres";
	if (kind === "net") return "host network";
	return docker ? "docker 2g · 1.5 cpu · net none" : "nice -n 10 · ionice idle";
}
function familyById(id) {
	const found = FAMILIES.find((family) => family.id === id);
	if (!found) throw new Error(id);
	return found;
}
function buildPlan(familyId, traceFails, docker) {
	const family = familyById(familyId);
	const work = `${ROOT}/sandbox/${RUN_ID}`;
	const build = `${ROOT}/build/${RUN_ID}`;
	const src = `${work}/input.png`;
	const art = traceFails ? `${work}/raster/raster_600dpi.png` : `${work}/traced.svg`;
	const vars = {
		...CFG,
		src,
		art,
		work,
		build,
		run_id: RUN_ID,
		fallback_dpi: CFG.fallback_dpi
	};
	const steps = [];
	const push = (step) => steps.push(step);
	push({
		id: "claim",
		module: "db",
		title: "claim_run",
		command: "UPDATE processing_jobs SET status=running, pid, started_at WHERE status=queued FOR UPDATE SKIP LOCKED",
		sandbox: sandboxFor("db", docker),
		note: "The MCP child and the minute drain cannot take the same run.",
		result: "claimed orchestrator row",
		failed: false
	});
	push({
		id: "stage",
		module: "ingest",
		title: "stage_input",
		command: `sha256 copy ${src}`,
		sandbox: sandboxFor("db", docker),
		note: "A hash mismatch quarantines the asset. Craft is not called.",
		result: "sha256 matches ingested_assets",
		failed: false
	});
	const trace = [
		"vectorcraft-cli trace",
		`--input ${src}`,
		`--svg-out ${work}/traced.svg`,
		`--pdf-out ${work}/traced.pdf`
	];
	if (family.traceExtra) trace.push(resolve(family.traceExtra, vars));
	push({
		id: "trace",
		module: "vectorcraft",
		title: "vector_trace",
		command: trace.join(" "),
		sandbox: sandboxFor("craft", docker),
		note: "Tier 0. Only exit code 1 switches to the raster fallback.",
		result: traceFails ? "exit 1 · ERROR: trace failed: path simplification diverged" : `exit 0 · fsync ${work}/traced.svg`,
		failed: traceFails
	});
	if (traceFails) push({
		id: "fallback",
		module: "photocraft",
		title: "raster_fallback",
		command: resolve("photocraft-cli --input {src} --trim-alpha false --target-dpi {fallback_dpi} --color-profile srgb --out-dir {work}/raster/", vars),
		sandbox: sandboxFor("craft", docker),
		note: "Tier 1. trace_state becomes raster_fallback. Later steps receive the PNG as {art}.",
		result: `exit 0 · fsync ${work}/raster/raster_600dpi.png`,
		failed: false
	});
	for (const step of family.steps) {
		const bits = [step.validator ? `validator ${step.validator}` : "no validator", "fsync file + directory"];
		if (step.timeout) bits.push(`timeout ${step.timeout}`);
		push({
			id: step.name,
			module: step.module,
			title: step.name,
			command: resolve(step.command, vars),
			sandbox: sandboxFor("craft", docker),
			note: bits.join(" · "),
			result: `exit 0 · fsync ${resolve(step.output, vars)}`,
			failed: false
		});
	}
	push({
		id: "upload-url",
		module: "fourthwall",
		title: "media.upload_url",
		command: `POST /open-api/v1.0/media/upload-url  ${resolve(family.upload, vars)}`,
		sandbox: sandboxFor("net", docker),
		note: "Body is fileName, contentType, size. The client allows 20 of these per minute.",
		result: "201 · uploadUrl + fileUrl",
		failed: false
	});
	push({
		id: "gcs",
		module: "fourthwall",
		title: "media.gcs_put",
		command: "PUT <uploadUrl>  Content-Type + x-goog-content-length-range",
		sandbox: sandboxFor("net", docker),
		note: "No Fourthwall credentials on this hop. The storage host must not see the API secret.",
		result: "200 · bytes match the signed size",
		failed: false
	});
	push({
		id: "register",
		module: "fourthwall",
		title: "media.register",
		command: "POST /open-api/v1.0/media/images  {fileUrl, width, height}",
		sandbox: sandboxFor("net", docker),
		note: "The returned id is the imageId stored on fourthwall_products.media_id.",
		result: "200 · imageId",
		failed: false
	});
	push({
		id: "create",
		module: "fourthwall",
		title: "product.create",
		command: "POST /open-api/v1.0/products  type=design  publishOnCreate=false",
		sandbox: sandboxFor("net", docker),
		note: "Not retried on 5xx. An empty fourthwall_template_id fails the run before this call.",
		result: "201 · productId · publish_state draft",
		failed: false
	});
	push({
		id: "finish",
		module: "db",
		title: "finish_run",
		command: "orchestrator row succeeded · asset processed · sandbox removed",
		sandbox: sandboxFor("db", docker),
		note: traceFails ? "trace_state stays raster_fallback." : "trace_state stays traced.",
		result: "build/ kept · auto_publish is false, so the product stays draft",
		failed: false
	});
	return steps;
}
function Board({ family, onFamily, traceFails, onTraceFails, docker, onDocker }) {
	const plan = buildPlan(family, traceFails, docker);
	const [cursor, setCursor] = (0, import_react.useState)(-1);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setCursor(-1);
		setPlaying(false);
	}, [
		family,
		traceFails,
		docker
	]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		if (cursor >= plan.length) {
			setPlaying(false);
			return;
		}
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const timer = window.setTimeout(() => setCursor((current) => current + 1), reduce ? 0 : 320);
		return () => window.clearTimeout(timer);
	}, [
		playing,
		cursor,
		plan.length
	]);
	const done = cursor >= plan.length;
	const runLabel = playing ? "Running" : done ? "Run again" : "Run route";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: "One asset, one route"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-3xl text-sm text-pretty text-muted",
				children: "Commands are the tuples in routes.py, resolved against the example products.json. Fourthwall is the three-step upload in fourthwall.py, not a single POST to /media."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "radiogroup",
				"aria-label": "Product route",
				children: FAMILIES.map((item) => {
					const selected = item.id === family;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "radio",
						"aria-checked": selected,
						className: "h-11 px-3 text-sm transition-colors duration-150 " + (selected ? "bg-brass text-bg" : "border border-fg/15 text-fg hover:border-brass"),
						onClick: () => onFamily(item.id),
						children: item.name
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: traceFails,
						onClick: () => onTraceFails(!traceFails),
						label: "Vector trace exits 1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: docker,
						onClick: () => onDocker(!docker),
						label: "Docker sandbox"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: playing,
						className: "inline-flex h-11 items-center gap-2 bg-brass px-4 text-sm font-medium text-bg transition-opacity duration-150 disabled:opacity-60",
						onClick: () => {
							setCursor(0);
							setPlaying(true);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
							className: "size-4",
							"aria-hidden": "true"
						}), runLabel]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "border border-fg/10",
				"aria-live": "polite",
				children: plan.map((step, index) => {
					const state = cursor < 0 ? "pending" : index < cursor ? "done" : index === cursor && playing ? "running" : "pending";
					const showResult = state === "done";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-1 border-b border-fg/10 p-3 last:border-b-0 md:grid-cols-[3rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs tabular-nums " + (state === "running" ? "text-brass motion-safe:animate-pulse" : showResult && !step.failed ? "text-brass" : "text-muted"),
							children: String(index + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-baseline gap-x-3 gap-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-medium",
											children: step.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-muted",
											children: step.module
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-muted",
											children: step.sandbox
										}),
										showResult && step.failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-fg",
											children: "FAIL"
										}) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 overflow-x-auto font-mono text-xs break-all text-fg md:break-normal",
									children: step.command
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: showResult ? step.result : step.note
								})
							]
						})]
					}, step.id);
				})
			}),
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					traceFails ? "trace_state raster_fallback." : "trace_state traced.",
					" ",
					"publish_state stays draft unless the account has auto_publish."
				]
			}) : null
		]
	});
}
function Toggle({ on, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		className: "h-11 border px-3 text-sm transition-colors duration-150 " + (on ? "border-brass text-brass" : "border-fg/15 text-fg hover:border-brass"),
		onClick,
		children: label
	});
}
var __init___default = "\"\"\"DeerFlow print pipeline. Import submodules directly; this package has no side effects.\"\"\"\n\n__version__ = \"1.0.0\"\n";
var config_default = "\"\"\"Runtime settings. Everything comes from environment variables (see .env.example)\nplus an optional per-category config file at <root>/config/products.json.\"\"\"\nfrom __future__ import annotations\n\nimport json\nimport os\nimport shlex\nfrom dataclasses import dataclass, field\nfrom pathlib import Path\nfrom typing import Any\n\n\nclass ConfigError(RuntimeError):\n    \"\"\"Raised for missing or invalid configuration. Never retried.\"\"\"\n\n\ndef _bool(name: str, default: bool) -> bool:\n    raw = os.environ.get(name)\n    if raw is None:\n        return default\n    return raw.strip().lower() in {\"1\", \"true\", \"yes\", \"on\"}\n\n\ndef _int(name: str, default: int) -> int:\n    raw = os.environ.get(name)\n    if raw is None or raw.strip() == \"\":\n        return default\n    try:\n        return int(raw)\n    except ValueError as exc:\n        raise ConfigError(f\"{name} must be an integer, got {raw!r}\") from exc\n\n\n@dataclass(frozen=True)\nclass Settings:\n    root: Path\n    database_url: str\n    credential_key: str = \"\"\n    fw_base_url: str = \"https://api.fourthwall.com\"\n    fw_api_user: str | None = None\n    fw_api_secret: str | None = None\n    # --- sandboxing -------------------------------------------------------\n    use_docker: bool = False\n    docker_image: str = \"pod-craft-runner:latest\"\n    docker_memory: str = \"2g\"\n    docker_cpus: str = \"1.5\"\n    docker_cpu_shares: int = 256          # relative weight vs. the web app (default 1024)\n    nice_level: int = 10                  # native mode only; see BLUEPRINT.md section 6\n    craft_prefix: tuple[str, ...] = ()    # e.g. (\"xvfb-run\", \"-a\") for GUI toolkits\n    # --- execution --------------------------------------------------------\n    max_concurrency: int = 2\n    step_timeout_s: int = 900\n    max_attempts: int = 2\n    fallback_raster_dpi: int = 600\n    max_log_bytes: int = 5 * 1024 * 1024\n    flush_poll_s: float = 0.2\n    inbox_settle_s: int = 5\n    stuck_after_s: int = 1800\n    # --- MCP server -------------------------------------------------------\n    mcp_host: str = \"127.0.0.1\"\n    mcp_port: int = 8765\n    products: dict[str, dict[str, Any]] = field(default_factory=dict)\n\n    # directory layout ------------------------------------------------------\n    @property\n    def inbox(self) -> Path:\n        return self.root / \"data\" / \"inbox\"\n\n    @property\n    def sandbox(self) -> Path:\n        return self.root / \"sandbox\"\n\n    @property\n    def build(self) -> Path:\n        return self.root / \"build\"\n\n    @property\n    def job_logs(self) -> Path:\n        return self.root / \"logs\" / \"jobs\"\n\n    @property\n    def bin_dir(self) -> Path:\n        return self.root / \"bin\"\n\n    @classmethod\n    def from_env(cls) -> \"Settings\":\n        root = Path(os.environ.get(\"POD_ROOT\", \"/opt/pod-pipeline\")).resolve()\n        db_url = os.environ.get(\"DATABASE_URL\", \"\")\n        if not db_url:\n            raise ConfigError(\"DATABASE_URL is not set\")\n        products: dict[str, dict[str, Any]] = {}\n        cfg_file = root / \"config\" / \"products.json\"\n        if cfg_file.is_file():\n            try:\n                products = json.loads(cfg_file.read_text(encoding=\"utf-8\"))\n            except json.JSONDecodeError as exc:\n                raise ConfigError(f\"{cfg_file} is not valid JSON: {exc}\") from exc\n        return cls(\n            root=root,\n            database_url=db_url,\n            credential_key=os.environ.get(\"POD_CREDENTIAL_KEY\", \"\"),\n            fw_base_url=os.environ.get(\"FW_BASE_URL\", \"https://api.fourthwall.com\").rstrip(\"/\"),\n            fw_api_user=os.environ.get(\"FW_API_USER\") or None,\n            fw_api_secret=os.environ.get(\"FW_API_SECRET\") or None,\n            use_docker=_bool(\"POD_USE_DOCKER\", False),\n            docker_image=os.environ.get(\"POD_DOCKER_IMAGE\", \"pod-craft-runner:latest\"),\n            docker_memory=os.environ.get(\"POD_DOCKER_MEMORY\", \"2g\"),\n            docker_cpus=os.environ.get(\"POD_DOCKER_CPUS\", \"1.5\"),\n            docker_cpu_shares=_int(\"POD_DOCKER_CPU_SHARES\", 256),\n            nice_level=_int(\"POD_NICE_LEVEL\", 10),\n            craft_prefix=tuple(shlex.split(os.environ.get(\"POD_CRAFT_PREFIX\", \"\"))),\n            max_concurrency=max(1, _int(\"POD_MAX_CONCURRENCY\", 2)),\n            step_timeout_s=_int(\"POD_STEP_TIMEOUT_S\", 900),\n            fallback_raster_dpi=_int(\"POD_FALLBACK_RASTER_DPI\", 600),\n            mcp_host=os.environ.get(\"POD_MCP_HOST\", \"127.0.0.1\"),\n            mcp_port=_int(\"POD_MCP_PORT\", 8765),\n            products=products,\n        )\n";
var db_default = "\"\"\"All SQL lives here. Parameterised queries only; no string-built SQL.\"\"\"\nfrom __future__ import annotations\n\nimport json\nimport os\nimport uuid\nfrom typing import Any, Sequence\n\nimport asyncpg\n\nfrom .config import ConfigError, Settings\n\nPool = asyncpg.Pool\n\n\nasync def create_pool(settings: Settings, *, min_size: int = 1, max_size: int = 6) -> Pool:\n    return await asyncpg.create_pool(settings.database_url, min_size=min_size, max_size=max_size, command_timeout=60)\n\n\ndef _rec(row: asyncpg.Record | None) -> dict[str, Any] | None:\n    return dict(row) if row is not None else None\n\n\n# ------------------------------------------------------------------------ runs\nRUN_SELECT = \"\"\"\nSELECT j.id AS job_id, j.run_id, j.account_id, j.asset_id, j.product_type, j.status AS job_status,\n       a.source_path, a.original_filename, a.sha256, a.trace_state,\n       acc.auto_publish, acc.fourthwall_api_user\n  FROM processing_jobs j\n  JOIN ingested_assets a   ON a.id = j.asset_id\n  JOIN users_saas_accounts acc ON acc.id = j.account_id\n WHERE j.module = 'orchestrator'\n\"\"\"\n\n\nasync def enqueue_run(pool: Pool, *, account_id: int, asset_id: int, product_type: str) -> tuple[uuid.UUID, bool]:\n    \"\"\"Insert the run row. Returns (run_id, created). If a live run exists for the same\n    (asset, product_type) the partial unique index rejects the insert and the existing run_id is returned.\"\"\"\n    run_id = uuid.uuid4()\n    async with pool.acquire() as con:\n        try:\n            async with con.transaction():\n                await con.execute(\n                    \"\"\"INSERT INTO processing_jobs (run_id, account_id, asset_id, product_type, module, step_name, step_index, status)\n                       VALUES ($1,$2,$3,$4,'orchestrator','pipeline_run',0,'queued')\"\"\",\n                    run_id, account_id, asset_id, product_type)\n                await con.execute(\n                    \"UPDATE ingested_assets SET status='queued' WHERE id=$1 AND status IN ('pending','failed','processed')\",\n                    asset_id)\n            return run_id, True\n        except asyncpg.UniqueViolationError:\n            existing = await con.fetchval(\n                \"\"\"SELECT run_id FROM processing_jobs WHERE asset_id=$1 AND product_type=$2\n                      AND module='orchestrator' AND status IN ('queued','running') LIMIT 1\"\"\", asset_id, product_type)\n            return existing, False\n\n\nasync def claim_run(pool: Pool, run_id: uuid.UUID | None, pid: int) -> dict[str, Any] | None:\n    \"\"\"Atomically move one queued run to running. run_id=None -> oldest queued run. SKIP LOCKED keeps\n    concurrent workers (MCP-spawned child + timer-driven drain) from taking the same run.\"\"\"\n    async with pool.acquire() as con:\n        row = await con.fetchrow(\n            \"\"\"UPDATE processing_jobs SET status='running', pid=$2, started_at=now()\n                WHERE id = (SELECT id FROM processing_jobs\n                             WHERE module='orchestrator' AND status='queued'\n                               AND ($1::uuid IS NULL OR run_id=$1)\n                             ORDER BY id FOR UPDATE SKIP LOCKED LIMIT 1)\n            RETURNING id, run_id\"\"\", run_id, pid)\n        if row is None:\n            return None\n        return _rec(await con.fetchrow(RUN_SELECT + \" AND j.id=$1\", row[\"id\"]))\n\n\nasync def get_run(pool: Pool, run_id: uuid.UUID) -> dict[str, Any] | None:\n    async with pool.acquire() as con:\n        return _rec(await con.fetchrow(RUN_SELECT + \" AND j.run_id=$1\", run_id))\n\n\nasync def finish_run(pool: Pool, run_id: uuid.UUID, *, ok: bool, digest: str | None) -> None:\n    async with pool.acquire() as con:\n        await con.execute(\n            \"\"\"UPDATE processing_jobs SET status=$2, finished_at=now(), error_digest=$3\n                WHERE run_id=$1 AND module='orchestrator'\"\"\",\n            run_id, \"succeeded\" if ok else \"failed\", (digest or None) and digest[:8000])\n\n\nasync def recover_stale_runs(pool: Pool) -> int:\n    \"\"\"Runs marked 'running' whose worker PID is gone (crash/reboot) go back to 'queued'.\"\"\"\n    n = 0\n    async with pool.acquire() as con:\n        rows = await con.fetch(\"SELECT id, pid FROM processing_jobs WHERE module='orchestrator' AND status='running'\")\n        for r in rows:\n            if r[\"pid\"] and _alive(r[\"pid\"]):\n                continue\n            await con.execute(\"UPDATE processing_jobs SET status='queued', pid=NULL, started_at=NULL WHERE id=$1\", r[\"id\"])\n            n += 1\n    return n\n\n\ndef _alive(pid: int) -> bool:\n    try:\n        os.kill(pid, 0)\n    except ProcessLookupError:\n        return False\n    except PermissionError:\n        return True\n    return True\n\n\n# ----------------------------------------------------------------------- steps\nasync def start_step(pool: Pool, run: dict[str, Any], *, module: str, step_name: str, step_index: int,\n                     attempt: int, tier: int, argv: Sequence[str]) -> int:\n    async with pool.acquire() as con:\n        return await con.fetchval(\n            \"\"\"INSERT INTO processing_jobs (run_id, account_id, asset_id, product_type, module, step_name,\n                                            step_index, attempt, fallback_tier, status, argv, started_at)\n               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'running',$10,now()) RETURNING id\"\"\",\n            run[\"run_id\"], run[\"account_id\"], run[\"asset_id\"], run[\"product_type\"], module, step_name,\n            step_index, attempt, tier, list(argv))\n\n\nasync def finish_step(pool: Pool, job_id: int, *, status: str, exit_code: int | None, pid: int | None,\n                      digest: str | None, log_path: str | None, output_path: str | None) -> None:\n    async with pool.acquire() as con:\n        await con.execute(\n            \"\"\"UPDATE processing_jobs SET status=$2, exit_code=$3, pid=$4, error_digest=$5, log_path=$6,\n                      output_path=$7, finished_at=now() WHERE id=$1\"\"\",\n            job_id, status, exit_code, pid, (digest or None) and digest[:8000], log_path, output_path)\n\n\n# ---------------------------------------------------------------------- assets\nasync def set_asset(pool: Pool, asset_id: int, *, status: str | None = None, trace_state: str | None = None,\n                    trace_bounds: dict[str, Any] | None = None) -> None:\n    async with pool.acquire() as con:\n        await con.execute(\n            \"\"\"UPDATE ingested_assets SET status=COALESCE($2,status), trace_state=COALESCE($3,trace_state),\n                      trace_bounds=COALESCE($4::jsonb,trace_bounds) WHERE id=$1\"\"\",\n            asset_id, status, trace_state, json.dumps(trace_bounds) if trace_bounds is not None else None)\n\n\nasync def register_asset(pool: Pool, *, account_id: int, source_path: str, filename: str, sha256: str,\n                         byte_size: int, mime: str | None, width: int | None, height: int | None,\n                         dpi: int | None, color_space: str, has_alpha: bool | None) -> int | None:\n    async with pool.acquire() as con:\n        return await con.fetchval(\n            \"\"\"INSERT INTO ingested_assets (account_id, source_kind, source_path, original_filename, sha256, byte_size,\n                                            mime_type, width_px, height_px, source_dpi, color_space, has_alpha)\n               VALUES ($1,'directory',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)\n               ON CONFLICT DO NOTHING RETURNING id\"\"\",\n            account_id, source_path, filename, sha256, byte_size, mime, width, height, dpi, color_space, has_alpha)\n\n\nasync def pending_assets(pool: Pool, *, stuck_after_s: int, account_id: int | None = None, limit: int = 200) -> list[dict[str, Any]]:\n    async with pool.acquire() as con:\n        rows = await con.fetch(\n            \"\"\"SELECT id, account_id, original_filename, source_path, byte_size, mime_type, width_px, height_px,\n                      color_space, has_alpha, status, trace_state, created_at, updated_at,\n                      (status IN ('queued','processing') AND updated_at < now() - make_interval(secs => $1)) AS stuck\n                 FROM ingested_assets\n                WHERE ($2::bigint IS NULL OR account_id=$2)\n                  AND (status IN ('pending','failed')\n                       OR (status IN ('queued','processing') AND updated_at < now() - make_interval(secs => $1)))\n                ORDER BY created_at LIMIT $3\"\"\", float(stuck_after_s), account_id, limit)\n        return [dict(r) for r in rows]\n\n\nasync def get_asset(pool: Pool, asset_id: int) -> dict[str, Any] | None:\n    async with pool.acquire() as con:\n        return _rec(await con.fetchrow(\"SELECT * FROM ingested_assets WHERE id=$1\", asset_id))\n\n\n# -------------------------------------------------------------------- products\nasync def upsert_product(pool: Pool, run: dict[str, Any], **fields: Any) -> dict[str, Any]:\n    \"\"\"Create the (account, asset, product_type) row if needed, then apply `fields`.\"\"\"\n    allowed = {\"fw_template_id\", \"media_id\", \"media_file_url\", \"fw_product_id\", \"fw_slug\", \"variants\", \"skus\",\n               \"publish_state\", \"last_error\", \"published_at\"}\n    bad = set(fields) - allowed\n    if bad:\n        raise ValueError(f\"unknown product columns: {sorted(bad)}\")\n    async with pool.acquire() as con:\n        async with con.transaction():\n            await con.execute(\n                \"\"\"INSERT INTO fourthwall_products (account_id, asset_id, run_id, product_type)\n                   VALUES ($1,$2,$3,$4) ON CONFLICT (account_id, asset_id, product_type) DO UPDATE SET run_id=EXCLUDED.run_id\"\"\",\n                run[\"account_id\"], run[\"asset_id\"], run[\"run_id\"], run[\"product_type\"])\n            sets, args = [], [run[\"account_id\"], run[\"asset_id\"], run[\"product_type\"]]\n            for col, val in fields.items():\n                args.append(json.dumps(val) if col == \"variants\" else val)\n                sets.append(f\"{col}=${len(args)}\" + (\"::jsonb\" if col == \"variants\" else \"\"))\n            if sets:\n                await con.execute(\n                    f\"UPDATE fourthwall_products SET {', '.join(sets)} WHERE account_id=$1 AND asset_id=$2 AND product_type=$3\", *args)\n            return dict(await con.fetchrow(\n                \"SELECT * FROM fourthwall_products WHERE account_id=$1 AND asset_id=$2 AND product_type=$3\",\n                run[\"account_id\"], run[\"asset_id\"], run[\"product_type\"]))\n\n\nasync def get_product_row(pool: Pool, ref: str) -> dict[str, Any] | None:\n    \"\"\"`ref` is either our numeric row id or a Fourthwall product id.\"\"\"\n    async with pool.acquire() as con:\n        if ref.isdigit():\n            return _rec(await con.fetchrow(\"SELECT * FROM fourthwall_products WHERE id=$1\", int(ref)))\n        return _rec(await con.fetchrow(\"SELECT * FROM fourthwall_products WHERE fw_product_id=$1 LIMIT 1\", ref))\n\n\n# --------------------------------------------------------------- credentials / logs\nasync def get_fw_credentials(pool: Pool, settings: Settings, account_id: int) -> tuple[str, str] | None:\n    \"\"\"Per-tenant credentials (secret decrypted in SQL with POD_CREDENTIAL_KEY), else env single-tenant fallback.\"\"\"\n    async with pool.acquire() as con:\n        if settings.credential_key:\n            row = await con.fetchrow(\n                \"\"\"SELECT fourthwall_api_user AS u,\n                          CASE WHEN fourthwall_api_secret_enc IS NULL THEN NULL\n                               ELSE pgp_sym_decrypt(fourthwall_api_secret_enc, $2) END AS s\n                     FROM users_saas_accounts WHERE id=$1\"\"\", account_id, settings.credential_key)\n        else:\n            row = None\n    if row and row[\"u\"] and row[\"s\"]:\n        return row[\"u\"], row[\"s\"]\n    if settings.fw_api_user and settings.fw_api_secret:\n        return settings.fw_api_user, settings.fw_api_secret\n    return None\n\n\nasync def log_sync(pool: Pool, *, account_id: int | None, direction: str, channel: str, event_type: str,\n                   run_id: uuid.UUID | None = None, http_method: str | None = None, url: str | None = None,\n                   status_code: int | None = None, success: bool | None = None, duration_ms: int | None = None,\n                   payload: Any = None, fw_product_row_id: int | None = None, external_event_id: str | None = None) -> None:\n    if success is None and status_code is not None:\n        success = 200 <= status_code < 300\n    async with pool.acquire() as con:\n        await con.execute(\n            \"\"\"INSERT INTO agent_sync_logs (account_id, direction, channel, event_type, external_event_id, http_method, url,\n                                            status_code, success, duration_ms, payload, run_id, fw_product_row_id)\n               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12,$13) ON CONFLICT DO NOTHING\"\"\",\n            account_id, direction, channel, event_type, external_event_id, http_method, url, status_code, success,\n            duration_ms, json.dumps(payload, default=str) if payload is not None else None, run_id, fw_product_row_id)\n\n\ndef require(value: Any, what: str) -> Any:\n    if value is None:\n        raise ConfigError(what)\n    return value\n";
var ingest_default = "\"\"\"Inbox scanner. Layout: <root>/data/inbox/<account_id>/<file>. New, settled files are hashed,\ninspected and registered in ingested_assets (status 'pending'). Duplicates (same sha256) are ignored.\"\"\"\nfrom __future__ import annotations\n\nimport asyncio\nimport hashlib\nimport logging\nimport mimetypes\nimport time\nfrom pathlib import Path\nfrom typing import Any\n\nfrom PIL import Image\n\nfrom . import db\nfrom .config import Settings\n\nlog = logging.getLogger(\"pod.ingest\")\nSKIP_SUFFIXES = {\".part\", \".tmp\", \".crdownload\", \".swp\"}\nMAX_INGEST_BYTES = 500 * 1024 * 1024\n\n\ndef inspect_file(path: Path) -> dict[str, Any]:\n    \"\"\"Blocking: hash + cheap metadata. Run in a thread.\"\"\"\n    h = hashlib.sha256()\n    size = 0\n    with open(path, \"rb\") as fh:\n        while chunk := fh.read(1024 * 1024):\n            h.update(chunk)\n            size += len(chunk)\n    meta: dict[str, Any] = {\"sha256\": h.hexdigest(), \"byte_size\": size,\n                            \"mime\": mimetypes.guess_type(path.name)[0], \"width\": None, \"height\": None,\n                            \"dpi\": None, \"color_space\": \"unknown\", \"has_alpha\": None}\n    try:\n        with Image.open(path) as im:\n            meta[\"width\"], meta[\"height\"] = im.width, im.height\n            dpi = im.info.get(\"dpi\")\n            if dpi:\n                meta[\"dpi\"] = int(round(float(dpi[0]))) or None\n            meta[\"mime\"] = Image.MIME.get(im.format or \"\", meta[\"mime\"])\n            meta[\"color_space\"] = {\"RGB\": \"srgb\", \"RGBA\": \"srgb\", \"LA\": \"gray\", \"L\": \"gray\", \"P\": \"indexed\",\n                                   \"PA\": \"indexed\", \"CMYK\": \"cmyk\"}.get(im.mode, \"unknown\")\n            meta[\"has_alpha\"] = im.mode in (\"RGBA\", \"LA\", \"PA\") or \"transparency\" in im.info\n    except Exception:\n        pass            # SVG/PDF/etc.: keep the basics; Craft apps do the real inspection\n    return meta\n\n\nasync def scan_inbox(settings: Settings, pool: db.Pool) -> int:\n    root = settings.inbox\n    if not root.is_dir():\n        return 0\n    registered = 0\n    now = time.time()\n    for acct_dir in sorted(p for p in root.iterdir() if p.is_dir() and p.name.isdigit()):\n        account_id = int(acct_dir.name)\n        async with pool.acquire() as con:\n            if not await con.fetchval(\"SELECT 1 FROM users_saas_accounts WHERE id=$1 AND status='active'\", account_id):\n                log.warning(\"inbox/%s has no active account; skipping\", acct_dir.name)\n                continue\n            known = {r[\"source_path\"] for r in await con.fetch(\n                \"SELECT source_path FROM ingested_assets WHERE account_id=$1\", account_id)}\n        for f in sorted(acct_dir.iterdir()):\n            if (not f.is_file() or f.is_symlink() or f.name.startswith(\".\") or f.suffix.lower() in SKIP_SUFFIXES\n                    or str(f) in known):\n                continue\n            st = f.stat()\n            if now - st.st_mtime < settings.inbox_settle_s or st.st_size == 0 or st.st_size > MAX_INGEST_BYTES:\n                continue            # still being written, empty, or oversized\n            meta = await asyncio.to_thread(inspect_file, f)\n            new_id = await db.register_asset(\n                pool, account_id=account_id, source_path=str(f), filename=f.name, sha256=meta[\"sha256\"],\n                byte_size=meta[\"byte_size\"], mime=meta[\"mime\"], width=meta[\"width\"], height=meta[\"height\"],\n                dpi=meta[\"dpi\"], color_space=meta[\"color_space\"], has_alpha=meta[\"has_alpha\"])\n            if new_id is not None:\n                registered += 1\n                log.info(\"registered asset %s (%s)\", new_id, f.name)\n    return registered\n";
var routes_default = "\"\"\"Product routing table.\n\nThis file is the ONLY place that knows the Craft CLI command lines. Everything is data, so when a\nCraft app changes a flag you edit one tuple here and nothing else.\n\nPlaceholders available inside argv/outputs templates (str.format syntax):\n    {src}  copy of the raw input inside the run sandbox      {art}   current artwork (traced SVG, or the\n    {work} per-run scratch dir                                        raster fallback PNG if tracing failed)\n    {build} per-run output dir                               {fallback_dpi}  raster fallback DPI\n    {run_id} {asset_id}                                      {cfg[key]}  per-category value from products.json\n\nItems marked ASSUMPTION are not in the original spec and must be confirmed against the real CLIs.\n\"\"\"\nfrom __future__ import annotations\n\nfrom dataclasses import dataclass, field\nfrom typing import Any\n\nfrom .config import ConfigError\n\nPRODUCT_TYPES = (\"apparel\", \"knitwear\", \"accessories\", \"odd_3d\", \"stationery\")\n\n# Defaults merged under <root>/config/products.json[<product_type>]\nDEFAULT_CFG: dict[str, dict[str, Any]] = {\n    \"apparel\": {\n        \"regions\": [\"front\"],\n        \"max_px\": [4200, 4800],            # 14x16 in @ 300 dpi\n    },\n    \"knitwear\": {\n        \"regions\": [\"front\"],\n        \"palette_limit\": 6,                 # factory yarn colors: hard maximum\n        \"knit_grid\": \"\",                    # REQUIRED: factory 'COLSxROWS'; deliberately no default\n    },\n    \"accessories\": {\n        \"regions\": [\"front\"],\n        \"template\": \"fourthwall_crossbody_v1\",\n        \"care_text\": \"100% Polyester\",\n    },\n    \"odd_3d\": {\n        \"regions\": [\"front\"],\n        \"bleed_in\": \"0.25\",\n    },\n    \"stationery\": {\n        \"regions\": [\"front\"],\n        \"cover_template\": \"notebook_cover_template\",\n        \"reel_template\": \"reel_promo_9_16\",\n        \"reel_preset\": \"tiktok_1080p\",\n    },\n}\n\n\n@dataclass(frozen=True)\nclass Step:\n    name: str\n    module: str                                  # vectorcraft | photocraft | designcraft | effectcraft | filmcraft\n    argv: tuple[str, ...]\n    outputs: tuple[str, ...]                     # templates; may contain a glob '*'\n    validators: tuple[tuple[str, str], ...] = ()  # (validator_name, output_template)\n    timeout_s: int | None = None\n\n\n@dataclass(frozen=True)\nclass Route:\n    product_type: str\n    trace_extra: tuple[str, ...]\n    steps: tuple[Step, ...]\n    final: str                                   # template: the artifact this category produces\n    upload: str | None                           # template: file sent to Fourthwall media library (None = skip)\n    notes: str = \"\"\n\n\n# --------------------------------------------------------------------------- stage 0 (shared)\ndef trace_step(route: Route) -> Step:\n    \"\"\"VectorCraft trace. ASSUMPTION: the spec gives no vectorcraft-cli command line; this contract is invented.\"\"\"\n    return Step(\n        name=\"vector_trace\",\n        module=\"vectorcraft\",\n        argv=(\"vectorcraft-cli\", \"trace\", \"--input\", \"{src}\",\n              \"--svg-out\", \"{work}/traced.svg\", \"--pdf-out\", \"{work}/traced.pdf\", *route.trace_extra),\n        outputs=(\"{work}/traced.svg\", \"{work}/traced.pdf\"),\n    )\n\n\ndef raster_fallback_step() -> Step:\n    \"\"\"Tier-1 fallback when the vector trace exits with code 1: high-DPI raster path, no tracing.\n    ASSUMPTION: PhotoCraft writes its result as a PNG inside --out-dir.\"\"\"\n    return Step(\n        name=\"raster_fallback\",\n        module=\"photocraft\",\n        argv=(\"photocraft-cli\", \"--input\", \"{src}\", \"--trim-alpha\", \"false\",\n              \"--target-dpi\", \"{fallback_dpi}\", \"--color-profile\", \"srgb\", \"--out-dir\", \"{work}/raster/\"),\n        outputs=(\"{work}/raster/*.png\",),\n    )\n\n\n# ------------------------------------------------------------------------------------- routes\ndef _routes() -> dict[str, Route]:\n    apparel = Route(\n        product_type=\"apparel\",\n        trace_extra=(),\n        steps=(\n            Step(\"photocraft_trim\", \"photocraft\",\n                 # spec lists --target-dpi/--color-profile/--dimensions as agent instructions, not on the\n                 # reference command line; they are merged here. Output name 'trimmed.png' comes from the spec.\n                 (\"photocraft-cli\", \"--input\", \"{art}\", \"--trim-alpha\", \"true\",\n                  \"--target-dpi\", \"300\", \"--color-profile\", \"srgb\", \"--dimensions\", \"14x16in\",\n                  \"--out-dir\", \"{work}/apparel/\"),\n                 (\"{work}/apparel/trimmed.png\",)),\n            Step(\"effectcraft_distress\", \"effectcraft\",\n                 (\"effectcraft-cli\", \"--input\", \"{work}/apparel/trimmed.png\",\n                  \"--filter\", \"vintage_screen_300\", \"--output\", \"{build}/apparel_final.png\"),\n                 (\"{build}/apparel_final.png\",),\n                 validators=((\"png_with_alpha\", \"{build}/apparel_final.png\"),)),\n        ),\n        final=\"{build}/apparel_final.png\",\n        upload=\"{build}/apparel_final.png\",\n    )\n    knitwear = Route(\n        product_type=\"knitwear\",\n        trace_extra=(\"--palette-limit\", \"{cfg[palette_limit]}\"),   # ASSUMPTION: flag name on vectorcraft-cli\n        steps=(\n            Step(\"designcraft_stitch_matrix\", \"designcraft\",\n                 # ASSUMPTION: '--input {art}' added; the spec's reference line has no input argument.\n                 (\"designcraft-cli\", \"--mode\", \"stitch_matrix\", \"--input\", \"{art}\",\n                  \"--palette-limit\", \"{cfg[palette_limit]}\", \"--grid-scale\", \"{cfg[knit_grid]}\",\n                  \"--output\", \"{build}/knitwear_final.bmp\"),\n                 (\"{build}/knitwear_final.bmp\",),\n                 validators=((\"knit_bmp\", \"{build}/knitwear_final.bmp\"),)),\n        ),\n        final=\"{build}/knitwear_final.bmp\",\n        upload=\"{build}/knitwear_final.bmp\",\n        notes=\"Fourthwall's media API is an image library; a BMP stitch grid may be refused -> needs_manual_upload.\",\n    )\n    accessories = Route(\n        product_type=\"accessories\",\n        trace_extra=(),\n        steps=(\n            Step(\"designcraft_template\", \"designcraft\",\n                 (\"designcraft-cli\", \"--template\", \"{cfg[template]}\", \"--layer\", \"artwork\", \"--embed\", \"{art}\",\n                  \"--layer\", \"care_label\", \"--text\", \"{cfg[care_text]}\",\n                  \"--output\", \"{build}/accessory_final.pdf\"),\n                 (\"{build}/accessory_final.pdf\",),\n                 validators=((\"pdf\", \"{build}/accessory_final.pdf\"),)),\n        ),\n        final=\"{build}/accessory_final.pdf\",\n        upload=\"{build}/accessory_final.pdf\",\n        notes=\"Safe-zone bbox checks and tracking/kerning auto-adjust must live inside DesignCraft.\",\n    )\n    odd_3d = Route(\n        product_type=\"odd_3d\",\n        trace_extra=(),\n        steps=(\n            Step(\"designcraft_wrap_tile\", \"designcraft\",\n                 (\"designcraft-cli\", \"--mode\", \"wrap_tile\", \"--bleed\", \"{cfg[bleed_in]}\", \"--input\", \"{art}\",\n                  \"--output\", \"{work}/odd/tiled.pdf\"),\n                 (\"{work}/odd/tiled.pdf\",),\n                 validators=((\"pdf\", \"{work}/odd/tiled.pdf\"),)),\n            Step(\"effectcraft_cylinder_taper\", \"effectcraft\",\n                 (\"effectcraft-cli\", \"--cylinder-taper\", \"--input\", \"{work}/odd/tiled.pdf\",\n                  \"--output\", \"{build}/odd_final.pdf\"),\n                 (\"{build}/odd_final.pdf\",),\n                 validators=((\"pdf\", \"{build}/odd_final.pdf\"),)),\n        ),\n        final=\"{build}/odd_final.pdf\",\n        upload=\"{build}/odd_final.pdf\",\n    )\n    stationery = Route(\n        product_type=\"stationery\",\n        trace_extra=(),\n        steps=(\n            Step(\"designcraft_cover\", \"designcraft\",\n                 # ASSUMPTION: '--embed {art}' added so artwork reaches the template; '--variable-data order_id'\n                 # is dropped here because a cover is built before any order exists.\n                 (\"designcraft-cli\", \"--input\", \"{cfg[cover_template]}\", \"--embed\", \"{art}\",\n                  \"--output\", \"{build}/print_ready_stationery.pdf\"),\n                 (\"{build}/print_ready_stationery.pdf\",),\n                 validators=((\"pdf\", \"{build}/print_ready_stationery.pdf\"),)),\n            Step(\"filmcraft_reel\", \"filmcraft\",\n                 (\"filmcraft-cli\", \"--template\", \"{cfg[reel_template]}\", \"--asset-layer\", \"product_front\",\n                  \"--input\", \"{build}/print_ready_stationery.pdf\", \"--render-preset\", \"{cfg[reel_preset]}\",\n                  \"--output\", \"{build}/promo_reel.mp4\"),\n                 (\"{build}/promo_reel.mp4\",),\n                 validators=((\"mp4\", \"{build}/promo_reel.mp4\"),),\n                 timeout_s=1800),\n        ),\n        final=\"{build}/print_ready_stationery.pdf\",\n        upload=\"{build}/print_ready_stationery.pdf\",\n        notes=\"promo_reel.mp4 is a marketing asset, not a Fourthwall upload. Packing slips are NOT built here.\",\n    )\n    return {r.product_type: r for r in (apparel, knitwear, accessories, odd_3d, stationery)}\n\n\nROUTES: dict[str, Route] = _routes()\n\n\ndef merged_cfg(product_type: str, overrides: dict[str, dict[str, Any]]) -> dict[str, Any]:\n    if product_type not in ROUTES:\n        raise ConfigError(f\"unknown product_type {product_type!r}; expected one of {', '.join(PRODUCT_TYPES)}\")\n    return {**DEFAULT_CFG.get(product_type, {}), **overrides.get(product_type, {})}\n\n\ndef render(template: str, variables: dict[str, Any], *, where: str) -> str:\n    try:\n        return template.format_map(variables)\n    except (KeyError, IndexError) as exc:\n        raise ConfigError(f\"{where}: placeholder {exc} is not defined (check products.json)\") from exc\n\n\ndef render_argv(step: Step, variables: dict[str, Any]) -> list[str]:\n    out = [render(tok, variables, where=f\"step {step.name}\") for tok in step.argv]\n    for tok in out:\n        if tok == \"\":\n            raise ConfigError(f\"step {step.name}: an argument rendered empty; a required products.json value is missing\")\n    return out\n";
var runner_default = "\"\"\"Async process runner: sandbox wrapping, streaming log digest, hard timeouts, durable flush.\"\"\"\nfrom __future__ import annotations\n\nimport asyncio\nimport hashlib\nimport os\nimport shutil\nimport signal\nimport time\nimport uuid\nfrom dataclasses import dataclass\nfrom pathlib import Path\n\nfrom .config import Settings\nfrom .logfilter import StreamDigest\n\nTRANSIENT_EXIT_CODES = {-9, -15, 137, 143, 75}   # SIGKILL/SIGTERM (OOM killer), docker 128+n, EX_TEMPFAIL\n\n\n@dataclass\nclass StepOutcome:\n    exit_code: int\n    timed_out: bool\n    pid: int | None\n    duration_s: float\n    digest: str\n    executed_argv: list[str]\n\n    @property\n    def ok(self) -> bool:\n        return self.exit_code == 0 and not self.timed_out\n\n    @property\n    def transient(self) -> bool:\n        return self.timed_out or self.exit_code in TRANSIENT_EXIT_CODES\n\n\nclass FlushTimeout(RuntimeError):\n    pass\n\n\ndef build_command(settings: Settings, argv: list[str], *, work: Path, build: Path, container_name: str) -> list[str]:\n    \"\"\"Wrap a Craft command line in the configured sandbox.\n\n    docker mode: cgroup limits (--memory/--cpus/--cpu-shares) are what protect the web app. `nice` on the\n    `docker run` client would not reach the container's processes (the daemon starts them), so it is not used.\n    native mode: nice + ionice (idle class) on the process itself.\n    \"\"\"\n    inner = [*settings.craft_prefix, *argv]\n    if settings.use_docker:\n        return [\n            \"docker\", \"run\", \"--rm\", \"--init\", \"--name\", container_name,\n            \"--memory\", settings.docker_memory, \"--memory-swap\", settings.docker_memory,   # no swap use\n            \"--cpus\", settings.docker_cpus, \"--cpu-shares\", str(settings.docker_cpu_shares),\n            \"--pids-limit\", \"256\", \"--network\", \"none\",\n            \"--cap-drop\", \"ALL\", \"--security-opt\", \"no-new-privileges\",\n            \"--read-only\", \"--tmpfs\", \"/tmp:rw,size=512m\", \"-e\", \"HOME=/tmp\",\n            \"--user\", f\"{os.getuid()}:{os.getgid()}\",\n            \"-v\", f\"{work}:{work}:rw\", \"-v\", f\"{build}:{build}:rw\", \"-w\", str(work),\n            settings.docker_image, *inner,\n        ]\n    prefix = [\"nice\", \"-n\", str(settings.nice_level)]\n    if shutil.which(\"ionice\"):\n        prefix += [\"ionice\", \"-c\", \"3\"]\n    return [*prefix, *inner]\n\n\ndef _env(settings: Settings, work: Path) -> dict[str, str]:\n    path = f\"{settings.bin_dir}{os.pathsep}{os.environ.get('PATH', '/usr/local/bin:/usr/bin:/bin')}\"\n    return {\"PATH\": path, \"HOME\": str(work), \"LANG\": \"C.UTF-8\", \"TMPDIR\": str(work),\n            \"QT_QPA_PLATFORM\": \"offscreen\", \"POD_RUN_WORKDIR\": str(work)}\n\n\nasync def _terminate(proc: asyncio.subprocess.Process, container: str | None) -> None:\n    if container:\n        killer = await asyncio.create_subprocess_exec(\n            \"docker\", \"kill\", container, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)\n        await killer.wait()\n    for sig, grace in ((signal.SIGTERM, 5.0), (signal.SIGKILL, 5.0)):\n        try:\n            os.killpg(proc.pid, sig)\n        except ProcessLookupError:\n            return\n        try:\n            await asyncio.wait_for(proc.wait(), grace)\n            return\n        except asyncio.TimeoutError:\n            continue\n\n\nasync def run_step(\n    settings: Settings, argv: list[str], *, work: Path, build: Path, log_path: Path, timeout_s: int,\n) -> StepOutcome:\n    container = f\"pod-{uuid.uuid4().hex[:12]}\" if settings.use_docker else None\n    cmd = build_command(settings, argv, work=work, build=build, container_name=container or \"\")\n    digest = StreamDigest(log_path=log_path, max_log_bytes=settings.max_log_bytes)\n    started = time.monotonic()\n    try:\n        proc = await asyncio.create_subprocess_exec(\n            *cmd, stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,\n            stderr=asyncio.subprocess.STDOUT, cwd=work, env=_env(settings, work),\n            start_new_session=True,                       # own process group -> killpg reaches helper processes\n        )\n    except FileNotFoundError as exc:\n        digest.finish()\n        return StepOutcome(127, False, None, 0.0, f\"executable not found: {exc.filename}\", cmd)\n\n    reader = asyncio.create_task(digest.consume(proc.stdout))   # type: ignore[arg-type]\n    timed_out = False\n    try:\n        await asyncio.wait_for(proc.wait(), timeout_s)\n    except asyncio.TimeoutError:\n        timed_out = True\n        await _terminate(proc, container)\n    try:\n        await asyncio.wait_for(reader, 10)\n    except asyncio.TimeoutError:\n        # a grandchild still holds the pipe open after the main process exited: kill the leftovers\n        reader.cancel()\n        try:\n            os.killpg(proc.pid, signal.SIGKILL)\n        except ProcessLookupError:\n            pass\n        digest.finish()\n    code = proc.returncode if proc.returncode is not None else -1\n    return StepOutcome(code, timed_out, proc.pid, time.monotonic() - started, digest.render(), cmd)\n\n\n# ------------------------------------------------------------------------------ durable flush\ndef _fsync_and_hash(path: Path) -> tuple[int, str]:\n    h = hashlib.sha256()\n    size = 0\n    fd = os.open(path, os.O_RDONLY)\n    try:\n        with os.fdopen(os.dup(fd), \"rb\") as fh:\n            while chunk := fh.read(1024 * 1024):\n                h.update(chunk)\n                size += len(chunk)\n        os.fsync(fd)                                      # file data + metadata to stable storage\n    finally:\n        os.close(fd)\n    dfd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)\n    try:\n        os.fsync(dfd)                                     # directory entry (the file's name) too\n    finally:\n        os.close(dfd)\n    return size, h.hexdigest()\n\n\nasync def flush_to_disk(path: Path, *, poll_s: float = 0.2, stable_polls: int = 2, max_wait_s: float = 30.0) -> tuple[int, str]:\n    \"\"\"Wait until `path` stops changing, then fsync it (and its directory) off the event loop.\n\n    Returns (size, sha256). Only after this returns is it safe to stream the file to another host.\"\"\"\n    loop = asyncio.get_running_loop()\n    deadline = loop.time() + max_wait_s\n    last: tuple[int, int] | None = None\n    stable = 0\n    while True:\n        try:\n            st = await asyncio.to_thread(os.stat, path)\n            sig: tuple[int, int] | None = (st.st_size, st.st_mtime_ns)\n        except FileNotFoundError:\n            sig = None\n        stable = stable + 1 if (sig is not None and sig[0] > 0 and sig == last) else 0\n        last = sig\n        if stable >= stable_polls:\n            return await asyncio.to_thread(_fsync_and_hash, path)\n        if loop.time() > deadline:\n            raise FlushTimeout(f\"{path} did not settle within {max_wait_s}s (size/mtime still changing or file missing)\")\n        await asyncio.sleep(poll_s)\n";
var validators_default = "\"\"\"Post-step output validators. They are synchronous; the orchestrator runs them in a worker thread.\n\nA validator raises ValidationError with a precise, short message. Validation failures are\ndeterministic, so the orchestrator never retries them (re-running the same tool gives the same file).\n\"\"\"\nfrom __future__ import annotations\n\nimport json\nimport re\nimport shutil\nimport subprocess\nfrom pathlib import Path\nfrom typing import Any, Callable\n\nfrom PIL import Image\n\nImage.MAX_IMAGE_PIXELS = 400_000_000   # 4200x4800 print files are ~20 MP; this still blocks decompression bombs\n\n\nclass ValidationError(RuntimeError):\n    pass\n\n\ndef parse_grid(spec: str) -> tuple[int, int]:\n    \"\"\"Factory grid spec 'COLSxROWS' (stitches x rows) -> (cols, rows).\"\"\"\n    m = re.fullmatch(r\"\\s*(\\d{1,5})\\s*[xX]\\s*(\\d{1,5})\\s*\", spec or \"\")\n    if not m:\n        raise ValidationError(f\"knit grid spec must look like 'COLSxROWS' (e.g. '112x140'), got {spec!r}\")\n    return int(m.group(1)), int(m.group(2))\n\n\ndef png_with_alpha(path: Path, cfg: dict[str, Any]) -> None:\n    max_w, max_h = cfg.get(\"max_px\", [4200, 4800])      # 14x16 in @ 300 dpi\n    try:\n        with Image.open(path) as im:\n            im.load()\n            if im.format != \"PNG\":\n                raise ValidationError(f\"{path.name}: expected PNG, got {im.format}\")\n            if im.width > max_w or im.height > max_h:\n                raise ValidationError(f\"{path.name}: {im.width}x{im.height}px exceeds {max_w}x{max_h}px print area\")\n            rgba = im.convert(\"RGBA\")\n            if rgba.getchannel(\"A\").getbbox() is None:\n                raise ValidationError(f\"{path.name}: image is fully transparent\")\n    except OSError as exc:\n        raise ValidationError(f\"{path.name}: unreadable image ({exc})\") from exc\n\n\ndef _bmp_header(path: Path) -> tuple[int, int, int, int]:\n    \"\"\"Return (width, height, bits_per_pixel, compression) straight from the BITMAPINFOHEADER.\n\n    Pillow drops the alpha channel of 32-bit BMPs on read, so alpha must be judged from the header.\n    \"\"\"\n    with open(path, \"rb\") as fh:\n        head = fh.read(34)\n    if len(head) < 34 or head[:2] != b\"BM\":\n        raise ValidationError(f\"{path.name}: not a BMP file\")\n    dib_size = int.from_bytes(head[14:18], \"little\")\n    if dib_size < 40:\n        raise ValidationError(f\"{path.name}: unsupported legacy BMP header ({dib_size} bytes)\")\n    width = int.from_bytes(head[18:22], \"little\", signed=True)\n    height = abs(int.from_bytes(head[22:26], \"little\", signed=True))\n    bpp = int.from_bytes(head[28:30], \"little\")\n    compression = int.from_bytes(head[30:34], \"little\")\n    return width, height, bpp, compression\n\n\ndef knit_bmp(path: Path, cfg: dict[str, Any]) -> None:\n    \"\"\"Hard-edge, opaque, palette-limited, exact grid size, uncompressed.\"\"\"\n    cols, rows = parse_grid(str(cfg.get(\"knit_grid\", \"\")))\n    palette_limit = int(cfg.get(\"palette_limit\", 6))\n    width, height, bpp, compression = _bmp_header(path)\n    if compression != 0:\n        raise ValidationError(f\"{path.name}: BMP must be uncompressed (BI_RGB), header says compression={compression}\")\n    if bpp not in (1, 4, 8, 24):\n        raise ValidationError(\n            f\"{path.name}: {bpp}-bit BMP can carry an alpha channel; export 8-bit indexed (preferred) or 24-bit \"\n            \"so every pixel is a 100% opaque thread color\")\n    if (width, height) != (cols, rows):\n        raise ValidationError(f\"{path.name}: grid is {width}x{height}, factory spec is {cols}x{rows}\")\n    try:\n        with Image.open(path) as im:\n            im.load()\n            colors = im.convert(\"RGB\").getcolors(maxcolors=palette_limit + 1)\n    except OSError as exc:\n        raise ValidationError(f\"{path.name}: unreadable image ({exc})\") from exc\n    if colors is None:\n        raise ValidationError(\n            f\"{path.name}: more than {palette_limit} distinct colors. Anti-aliased or gradient edge pixels \"\n            \"produce extra colors; the factory yarn limit is a hard maximum\")\n\n\ndef pdf_ok(path: Path, cfg: dict[str, Any]) -> None:\n    with open(path, \"rb\") as fh:\n        head = fh.read(8)\n        fh.seek(0, 2)\n        size = fh.tell()\n        fh.seek(max(0, size - 2048))\n        tail = fh.read()\n    if not head.startswith(b\"%PDF-\"):\n        raise ValidationError(f\"{path.name}: missing %PDF header\")\n    if b\"%%EOF\" not in tail:\n        raise ValidationError(f\"{path.name}: missing %%EOF trailer (truncated write?)\")\n\n\ndef mp4_ok(path: Path, cfg: dict[str, Any]) -> None:\n    with open(path, \"rb\") as fh:\n        head = fh.read(12)\n    if len(head) < 12 or head[4:8] != b\"ftyp\":\n        raise ValidationError(f\"{path.name}: not an MP4/ISO-BMFF file (no ftyp box)\")\n    ffprobe = shutil.which(\"ffprobe\")\n    if not ffprobe:\n        return   # container check only; install ffmpeg to also verify 1080x1920 / ~5 s\n    want = cfg.get(\"reel\", {\"width\": 1080, \"height\": 1920, \"seconds\": 5.0, \"tolerance\": 0.75})\n    try:\n        out = subprocess.run(\n            [ffprobe, \"-v\", \"error\", \"-select_streams\", \"v:0\", \"-show_entries\",\n             \"stream=width,height:format=duration\", \"-of\", \"json\", str(path)],\n            capture_output=True, text=True, timeout=60, check=True).stdout\n        info = json.loads(out)\n        w, h = info[\"streams\"][0][\"width\"], info[\"streams\"][0][\"height\"]\n        dur = float(info[\"format\"][\"duration\"])\n    except (subprocess.SubprocessError, KeyError, IndexError, ValueError) as exc:\n        raise ValidationError(f\"{path.name}: ffprobe could not read the video ({exc})\") from exc\n    if (w, h) != (want[\"width\"], want[\"height\"]):\n        raise ValidationError(f\"{path.name}: video is {w}x{h}, expected {want['width']}x{want['height']} (9:16)\")\n    if abs(dur - want[\"seconds\"]) > want[\"tolerance\"]:\n        raise ValidationError(f\"{path.name}: duration {dur:.2f}s, expected about {want['seconds']}s\")\n\n\nVALIDATORS: dict[str, Callable[[Path, dict[str, Any]], None]] = {\n    \"png_with_alpha\": png_with_alpha,\n    \"knit_bmp\": knit_bmp,\n    \"pdf\": pdf_ok,\n    \"mp4\": mp4_ok,\n}\n";
var logfilter_default = "\"\"\"Streaming log filter.\n\nCraft binaries can emit many megabytes of progress output. We never hold that in memory and never\nhand it to the LLM. Every byte is (optionally) copied to a size-capped log file on disk, while an\nin-memory digest keeps only: de-duplicated lines matching an error regex, plus the last few lines.\n`render()` returns a small, fixed-size string that is safe to store in Postgres and feed to DeepSeek.\n\"\"\"\nfrom __future__ import annotations\n\nimport asyncio\nimport re\nfrom collections import OrderedDict, deque\nfrom pathlib import Path\nfrom typing import BinaryIO\n\nERROR_RE = re.compile(\n    r\"(?i)\\b(error|fatal|exception|traceback|failed|failure|panic|segfault|segmentation|\"\n    r\"abort(?:ed)?|denied|killed|out of memory|oom|cannot|unable to|invalid|unsupported)\\b\"\n)\n_DIGITS = re.compile(r\"\\d+\")\n_MAX_PENDING = 64 * 1024          # a \"line\" longer than this without a newline is cut here\n\n\nclass StreamDigest:\n    def __init__(\n        self,\n        *,\n        log_path: Path | None = None,\n        max_log_bytes: int = 5 * 1024 * 1024,\n        max_error_entries: int = 20,\n        tail_lines: int = 12,\n        max_line_chars: int = 300,\n    ) -> None:\n        self._max_error_entries = max_error_entries\n        self._max_line_chars = max_line_chars\n        self._tail: deque[str] = deque(maxlen=tail_lines)\n        self._errors: \"OrderedDict[str, list]\" = OrderedDict()   # key -> [first_line, count]\n        self._dropped_errors = 0\n        self._pending = bytearray()\n        self.total_bytes = 0\n        self.total_lines = 0\n        self.log_truncated = False\n        self._log_budget = max_log_bytes\n        self._log: BinaryIO | None = None\n        if log_path is not None:\n            log_path.parent.mkdir(parents=True, exist_ok=True)\n            self._log = open(log_path, \"wb\")\n\n    # ------------------------------------------------------------------ input\n    def feed(self, data: bytes) -> None:\n        if not data:\n            return\n        self.total_bytes += len(data)\n        self._write_log(data)\n        self._pending.extend(data)\n        # split on \\n and \\r: progress bars redraw with \\r and would otherwise form one giant \"line\"\n        while True:\n            cut = self._find_delim(self._pending)\n            if cut < 0:\n                if len(self._pending) > _MAX_PENDING:\n                    self._emit(bytes(self._pending))\n                    self._pending.clear()\n                return\n            line = bytes(self._pending[:cut])\n            del self._pending[: cut + 1]\n            if line:\n                self._emit(line)\n\n    @staticmethod\n    def _find_delim(buf: bytearray) -> int:\n        n, r = buf.find(b\"\\n\"), buf.find(b\"\\r\")\n        if n < 0:\n            return r\n        if r < 0:\n            return n\n        return min(n, r)\n\n    def finish(self) -> None:\n        if self._pending:\n            self._emit(bytes(self._pending))\n            self._pending.clear()\n        if self._log is not None:\n            self._log.flush()\n            self._log.close()\n            self._log = None\n\n    async def consume(self, stream: asyncio.StreamReader) -> None:\n        try:\n            while True:\n                chunk = await stream.read(65536)\n                if not chunk:\n                    break\n                self.feed(chunk)\n        finally:\n            self.finish()\n\n    # ----------------------------------------------------------------- output\n    def render(self, max_chars: int = 2000) -> str:\n        parts = [f\"[{self.total_lines} lines, {self.total_bytes} bytes\"\n                 + (\", log truncated on disk\" if self.log_truncated else \"\") + \"]\"]\n        for first, count in self._errors.values():\n            parts.append(f\"(x{count}) {first}\" if count > 1 else first)\n        if self._dropped_errors:\n            parts.append(f\"... {self._dropped_errors} more distinct error lines omitted\")\n        seen = {first for first, _ in self._errors.values()}\n        tail = [t for t in self._tail if t not in seen]\n        if tail:\n            parts.append(\"-- last lines --\")\n            parts.extend(tail)\n        text = \"\\n\".join(parts)\n        if len(text) > max_chars:\n            text = text[: max_chars - 15].rstrip() + \"\\n...[truncated]\"\n        return text\n\n    # --------------------------------------------------------------- internals\n    def _emit(self, raw: bytes) -> None:\n        line = raw.decode(\"utf-8\", errors=\"replace\").strip()\n        if not line:\n            return\n        self.total_lines += 1\n        if len(line) > self._max_line_chars:\n            line = line[: self._max_line_chars] + \"...\"\n        self._tail.append(line)\n        if ERROR_RE.search(line):\n            key = _DIGITS.sub(\"#\", line)[:120]\n            hit = self._errors.get(key)\n            if hit is not None:\n                hit[1] += 1\n            elif len(self._errors) < self._max_error_entries:\n                self._errors[key] = [line, 1]\n            else:\n                self._dropped_errors += 1\n\n    def _write_log(self, data: bytes) -> None:\n        if self._log is None or self._log_budget <= 0:\n            if self._log is not None and not self.log_truncated:\n                self._log.write(b\"\\n[log truncated: size cap reached]\\n\")\n                self.log_truncated = True\n            return\n        piece = data[: self._log_budget]\n        self._log.write(piece)\n        self._log_budget -= len(piece)\n        if len(piece) < len(data):\n            self._log.write(b\"\\n[log truncated: size cap reached]\\n\")\n            self.log_truncated = True\n";
var orchestrator_default = "\"\"\"Pipeline orchestrator: one `run_pipeline()` call = one asset through one product route.\n\nFlow:  claim run -> stage input (sha256 verified) -> VectorCraft trace (raster fallback on exit 1)\n       -> route steps (validate + fsync after each) -> publish to Fourthwall -> mark run.\n\"\"\"\nfrom __future__ import annotations\n\nimport asyncio\nimport datetime as dt\nimport hashlib\nimport logging\nimport shutil\nimport traceback\nimport uuid\nfrom dataclasses import dataclass, field\nfrom pathlib import Path\nfrom typing import Any\n\nimport httpx\n\nfrom . import db\nfrom .config import ConfigError, Settings\nfrom .fourthwall import FourthwallClient, FourthwallError, UnsupportedMedia\nfrom .routes import (ROUTES, Route, Step, merged_cfg, raster_fallback_step, render, render_argv, trace_step)\nfrom .runner import FlushTimeout, StepOutcome, flush_to_disk, run_step\nfrom .validators import VALIDATORS, ValidationError\n\nlog = logging.getLogger(\"pod.orchestrator\")\n\nTRACE_FALLBACK_EXIT_CODES = {1}      # spec: \"if a vector trace step returns exit code 1 -> raster fallback\"\n\n\nclass PipelineError(RuntimeError):\n    def __init__(self, message: str, *, digest: str = \"\", exit_code: int | None = None, quarantine: bool = False):\n        super().__init__(message)\n        self.digest, self.exit_code, self.quarantine = digest, exit_code, quarantine\n\n\n@dataclass\nclass RunCtx:\n    settings: Settings\n    pool: db.Pool\n    run: dict[str, Any]\n    route: Route\n    cfg: dict[str, Any]\n    work: Path\n    build: Path\n    logs: Path\n    vars: dict[str, Any] = field(default_factory=dict)\n    _idx: int = 0\n\n    def next_index(self) -> int:\n        self._idx += 1\n        return self._idx\n\n\n# ------------------------------------------------------------------------------ entry point\nasync def run_pipeline(settings: Settings, pool: db.Pool, run_id: uuid.UUID | None, *, pid: int) -> dict[str, Any] | None:\n    \"\"\"Claim and execute one run (specific run_id, or the oldest queued one when None).\n    Returns a summary dict, or None when nothing was claimable.\"\"\"\n    run = await db.claim_run(pool, run_id, pid)\n    if run is None:\n        return None\n    rid: uuid.UUID = run[\"run_id\"]\n    summary: dict[str, Any] = {\"run_id\": str(rid), \"asset_id\": run[\"asset_id\"], \"product_type\": run[\"product_type\"],\n                               \"ok\": False, \"product_state\": None, \"artifact\": None, \"error\": None}\n    ctx: RunCtx | None = None\n    try:\n        route = ROUTES[run[\"product_type\"]]\n        ctx = RunCtx(settings=settings, pool=pool, run=run, route=route,\n                     cfg=merged_cfg(run[\"product_type\"], settings.products),\n                     work=settings.sandbox / str(rid), build=settings.build / str(rid), logs=settings.job_logs / str(rid))\n        await db.log_sync(pool, account_id=run[\"account_id\"], direction=\"outbound\", channel=\"orchestrator\",\n                          event_type=\"run.started\", run_id=rid, payload={\"product_type\": run[\"product_type\"]})\n        final = await _execute(ctx)\n        summary[\"artifact\"] = str(final)\n        summary[\"product_state\"] = await _publish(ctx, final)\n        await db.set_asset(pool, run[\"asset_id\"], status=\"processed\")\n        await db.finish_run(pool, rid, ok=True, digest=None)\n        summary[\"ok\"] = True\n        await asyncio.to_thread(shutil.rmtree, ctx.work, True)       # keep sandbox only for failed runs\n    except PipelineError as exc:\n        summary[\"error\"] = _short(exc)\n        await _fail(pool, run, exc.digest or str(exc), quarantine=exc.quarantine)\n    except ConfigError as exc:\n        summary[\"error\"] = f\"configuration: {exc}\"\n        await _fail(pool, run, summary[\"error\"])\n    except Exception as exc:                                          # bug or environment failure: keep it compact\n        log.exception(\"run %s crashed\", rid)\n        summary[\"error\"] = f\"{type(exc).__name__}: {exc}\"\n        await _fail(pool, run, \"\".join(traceback.format_exception_only(type(exc), exc)) + _tb_tail())\n    await db.log_sync(pool, account_id=run[\"account_id\"], direction=\"outbound\", channel=\"orchestrator\",\n                      event_type=\"run.finished\", run_id=rid, success=summary[\"ok\"], payload=summary)\n    return summary\n\n\ndef _short(exc: BaseException) -> str:\n    return str(exc)[:500]\n\n\ndef _tb_tail() -> str:\n    return \"\\n\".join(traceback.format_exc().splitlines()[-6:])\n\n\nasync def _fail(pool: db.Pool, run: dict[str, Any], digest: str, *, quarantine: bool = False) -> None:\n    await db.finish_run(pool, run[\"run_id\"], ok=False, digest=digest)\n    await db.set_asset(pool, run[\"asset_id\"], status=\"quarantined\" if quarantine else \"failed\")\n\n\n# ---------------------------------------------------------------------------------- stages\nasync def _execute(ctx: RunCtx) -> Path:\n    s = ctx.settings\n    for d in (ctx.work, ctx.build, ctx.logs):\n        await asyncio.to_thread(d.mkdir, 0o750, True, True)\n    await db.set_asset(ctx.pool, ctx.run[\"asset_id\"], status=\"processing\")\n\n    src_path = Path(ctx.run[\"source_path\"])\n    staged = ctx.work / f\"input{src_path.suffix.lower()}\"\n    await asyncio.to_thread(_stage_input, src_path, staged, ctx.run[\"sha256\"])\n    ctx.vars.update(src=str(staged), art=str(staged), work=str(ctx.work), build=str(ctx.build),\n                    run_id=str(ctx.run[\"run_id\"]), asset_id=ctx.run[\"asset_id\"],\n                    fallback_dpi=s.fallback_raster_dpi, cfg=ctx.cfg)\n\n    await _trace_stage(ctx)\n    for step in ctx.route.steps:\n        await _run_step(ctx, step)\n    final = Path(render(ctx.route.final, ctx.vars, where=\"route.final\"))\n    if not final.is_file():\n        raise PipelineError(f\"route finished but final artifact is missing: {final}\")\n    return final\n\n\ndef _stage_input(src: Path, dst: Path, expected_sha: str) -> None:\n    if not src.is_file():\n        raise PipelineError(f\"source file is gone: {src}\", quarantine=True)\n    h = hashlib.sha256()\n    with open(src, \"rb\") as fi, open(dst, \"wb\") as fo:\n        while chunk := fi.read(1024 * 1024):\n            h.update(chunk)\n            fo.write(chunk)\n        fo.flush()\n    if h.hexdigest() != expected_sha:\n        dst.unlink(missing_ok=True)\n        raise PipelineError(f\"{src.name} changed after ingest (sha256 mismatch); refusing to process\", quarantine=True)\n\n\nasync def _trace_stage(ctx: RunCtx) -> None:\n    pool, asset_id = ctx.pool, ctx.run[\"asset_id\"]\n    step = trace_step(ctx.route)\n    idx = ctx.next_index()\n    await db.set_asset(pool, asset_id, trace_state=\"tracing\")\n    try:\n        outs = await _run_step(ctx, step, index=idx)\n    except PipelineError as exc:\n        if exc.exit_code not in TRACE_FALLBACK_EXIT_CODES:\n            await db.set_asset(pool, asset_id, trace_state=\"trace_failed\")\n            raise\n        log.warning(\"vector trace exited %s; switching to raster fallback (tier 1)\", exc.exit_code)\n        outs = await _run_step(ctx, raster_fallback_step(), index=idx, tier=1)\n        ctx.vars[\"art\"] = str(outs[0])\n        await db.set_asset(pool, asset_id, trace_state=\"raster_fallback\")\n        return\n    ctx.vars[\"art\"] = str(outs[0])           # traced.svg\n    await db.set_asset(pool, asset_id, trace_state=\"traced\")\n\n\nasync def _run_step(ctx: RunCtx, step: Step, *, index: int | None = None, tier: int = 0) -> list[Path]:\n    s = ctx.settings\n    idx = index if index is not None else ctx.next_index()\n    argv = render_argv(step, ctx.vars)\n    timeout = step.timeout_s or s.step_timeout_s\n    last_err: PipelineError | None = None\n    for attempt in range(1, s.max_attempts + 1):\n        log_path = ctx.logs / f\"{idx:02d}-{step.name}-t{tier}-a{attempt}.log\"\n        job_id = await db.start_step(ctx.pool, ctx.run, module=step.module, step_name=step.name, step_index=idx,\n                                     attempt=attempt, tier=tier, argv=argv)\n        outcome: StepOutcome = await run_step(s, argv, work=ctx.work, build=ctx.build, log_path=log_path, timeout_s=timeout)\n        problem: PipelineError | None = None\n        outputs: list[Path] = []\n        if not outcome.ok:\n            why = \"timed out after %ss\" % timeout if outcome.timed_out else f\"exit code {outcome.exit_code}\"\n            problem = PipelineError(f\"{step.name} failed: {why}\", digest=outcome.digest, exit_code=outcome.exit_code)\n        else:\n            try:\n                outputs = await _collect_and_validate(ctx, step)\n            except (PipelineError, ValidationError, FlushTimeout) as exc:\n                code = 0 if isinstance(exc, PipelineError) else None\n                problem = PipelineError(f\"{step.name}: {exc}\", digest=f\"{exc}\\n{outcome.digest}\"[:4000], exit_code=code)\n        await db.finish_step(ctx.pool, job_id, status=\"failed\" if problem else \"succeeded\", exit_code=outcome.exit_code,\n                             pid=outcome.pid, digest=(problem.digest if problem else outcome.digest if outcome.exit_code else None),\n                             log_path=str(log_path), output_path=str(outputs[0]) if outputs else None)\n        if problem is None:\n            return outputs\n        last_err = problem\n        retryable = outcome.transient and attempt < s.max_attempts\n        log.warning(\"step %s attempt %d failed (%s)%s\", step.name, attempt, problem, \"; retrying\" if retryable else \"\")\n        if not retryable:\n            break\n    assert last_err is not None\n    raise last_err\n\n\nasync def _collect_and_validate(ctx: RunCtx, step: Step) -> list[Path]:\n    outputs: list[Path] = []\n    for tmpl in step.outputs:\n        pattern = render(tmpl, ctx.vars, where=f\"step {step.name} outputs\")\n        if \"*\" in pattern:\n            matches = sorted(Path(pattern).parent.glob(Path(pattern).name))\n            if not matches:\n                raise PipelineError(f\"expected output not produced: {pattern}\")\n            path = matches[0]\n        else:\n            path = Path(pattern)\n        if not path.is_file() or path.stat().st_size == 0:\n            raise PipelineError(f\"expected output missing or empty: {path}\")\n        await flush_to_disk(path, poll_s=ctx.settings.flush_poll_s)\n        outputs.append(path)\n    for vname, tmpl in step.validators:\n        target = Path(render(tmpl, ctx.vars, where=f\"step {step.name} validator\"))\n        await asyncio.to_thread(VALIDATORS[vname], target, ctx.cfg)\n    return outputs\n\n\n# --------------------------------------------------------------------------------- publish\nasync def _publish(ctx: RunCtx, final: Path) -> str:\n    \"\"\"Upload to Fourthwall and create the design product. Returns the resulting publish_state.\"\"\"\n    run, pool, cfg = ctx.run, ctx.pool, ctx.cfg\n    row = await db.upsert_product(pool, run)\n    if row[\"fw_product_id\"]:\n        log.info(\"asset %s/%s already has Fourthwall product %s; not creating another\",\n                 run[\"asset_id\"], run[\"product_type\"], row[\"fw_product_id\"])\n        return row[\"publish_state\"]\n    upload_tmpl = ctx.route.upload\n    if upload_tmpl is None:\n        await db.upsert_product(pool, run, publish_state=\"draft\", last_error=\"route has no Fourthwall upload step\")\n        return \"draft\"\n    upload = Path(render(upload_tmpl, ctx.vars, where=\"route.upload\"))\n\n    creds = await db.get_fw_credentials(pool, ctx.settings, run[\"account_id\"])\n    if creds is None:\n        await db.upsert_product(pool, run, publish_state=\"draft\", last_error=\"no Fourthwall credentials configured\")\n        return \"draft\"\n    template_id = cfg.get(\"fourthwall_template_id\")\n    if not template_id:\n        msg = (f\"products.json[{run['product_type']}].fourthwall_template_id is not set \"\n               \"(list ids with: python -m pod_pipeline.worker --list-templates)\")\n        await db.upsert_product(pool, run, publish_state=\"failed\", last_error=msg)\n        raise PipelineError(msg)\n\n    await db.upsert_product(pool, run, publish_state=\"processing\", last_error=None, fw_template_id=template_id)\n\n    async def hook(ev: dict[str, Any]) -> None:\n        await db.log_sync(pool, account_id=run[\"account_id\"], direction=\"outbound\", channel=\"fourthwall_api\",\n                          run_id=run[\"run_id\"], fw_product_row_id=row[\"id\"], **ev)\n\n    stem = Path(run[\"original_filename\"]).stem.replace(\"_\", \" \").replace(\"-\", \" \").strip() or \"Design\"\n    try:\n        async with FourthwallClient(ctx.settings.fw_base_url, creds[0], creds[1], hook=hook) as fw:\n            media_id = row[\"media_id\"]\n            if not media_id:\n                img = await fw.upload_image(upload)\n                media_id = img[\"id\"]\n                await db.upsert_product(pool, run, media_id=media_id, media_file_url=img.get(\"uri\"))\n            created = await fw.create_design_product(\n                template_id=template_id, name=cfg.get(\"product_name\", stem), description=cfg.get(\"description\", stem),\n                regions=[{\"region\": r, \"imageId\": media_id, \"placementStrategy\": \"AUTO\"} for r in cfg.get(\"regions\", [\"front\"])],\n                publish_on_create=False, profit_margin=cfg.get(\"profit_margin\"))\n            fw_id = created.get(\"productId\") or created.get(\"id\")\n            if not fw_id:\n                raise FourthwallError(f\"create product response had no productId: {str(created)[:200]}\")\n            await db.upsert_product(pool, run, fw_product_id=fw_id)\n            detail: dict[str, Any] = {}\n            try:\n                detail = await fw.get_product(fw_id)\n            except FourthwallError as exc:       # product exists; detail is nice-to-have\n                log.warning(\"created %s but could not read it back: %s\", fw_id, exc)\n            variants = detail.get(\"variants\") or []\n            state = \"draft\"\n            if run.get(\"auto_publish\"):\n                await fw.set_state(fw_id, \"PUBLIC\")\n                state = \"active\"\n            await db.upsert_product(\n                pool, run, fw_slug=detail.get(\"slug\"), variants=variants,\n                skus=[v[\"sku\"] for v in variants if v.get(\"sku\")], publish_state=state, last_error=None,\n                published_at=dt.datetime.now(dt.timezone.utc) if state == \"active\" else None)\n            return state\n    except UnsupportedMedia as exc:\n        msg = f\"Fourthwall media library refused {upload.name} ({exc.code}); supported: {exc.supported or 'unknown'}\"\n        await db.upsert_product(pool, run, publish_state=\"needs_manual_upload\", last_error=msg)\n        return \"needs_manual_upload\"\n    except FourthwallError as exc:\n        await db.upsert_product(pool, run, publish_state=\"failed\", last_error=str(exc)[:500])\n        raise PipelineError(f\"Fourthwall publish failed: {exc}\", digest=str(exc)) from exc\n    except httpx.TransportError as exc:\n        await db.upsert_product(pool, run, publish_state=\"failed\", last_error=f\"network: {exc}\"[:500])\n        raise PipelineError(f\"Fourthwall network error: {exc}\") from exc\n\n";
var fourthwall_default = "\"\"\"Fourthwall Open API client.\n\nEndpoints and the exact upload handshake were checked against docs.fourthwall.com (Nov 2026):\n\n    POST /open-api/v1.0/media/upload-url   {fileName, contentType, size}  -> {uploadUrl, fileUrl}\n    PUT  <uploadUrl>   (Google Cloud Storage, NO Fourthwall credentials)\n         headers: Content-Type == contentType, x-goog-content-length-range: 0,<size>   (both are signed)\n    POST /open-api/v1.0/media/images       {fileUrl, width, height}       -> {id: imageId, ...}\n    POST /open-api/v1.0/products           {type:\"design\", productTemplateId, name, regions:[{region,imageId}]}\n    GET  /open-api/v1.0/products/{id}      PUT /open-api/v1.0/products/{id}/state {state: PUBLIC|HIDDEN}\n    GET  /open-api/v1.0/product-templates\n\nAuth: HTTP Basic with an API key pair (docs: \"API keys have full access to these endpoints\").\nRate limits: media/upload-url 20 req/min per shop; most others 100 req / 10 s per shop.\n\"\"\"\nfrom __future__ import annotations\n\nimport asyncio\nimport time\nfrom collections import deque\nfrom pathlib import Path\nfrom typing import Any, Awaitable, Callable\n\nimport httpx\nfrom PIL import Image\n\nHook = Callable[[dict[str, Any]], Awaitable[None]]\n\n\nclass FourthwallError(RuntimeError):\n    def __init__(self, message: str, *, status: int | None = None, code: str | None = None, body: Any = None):\n        super().__init__(message)\n        self.status, self.code, self.body = status, code, body\n\n\nclass UnsupportedMedia(FourthwallError):\n    \"\"\"406 UNSUPPORTED_MEDIA_TYPE_ERROR / UNSUPPORTED_ASSET_TYPE_ERROR from the media library.\"\"\"\n\n    def __init__(self, message: str, *, supported: list[str] | None = None, **kw: Any):\n        super().__init__(message, **kw)\n        self.supported = supported or []\n\n\nclass SlidingWindowLimiter:\n    \"\"\"Client-side guard so we never trip the 20/min media limit (and thus never burn a retry).\"\"\"\n\n    def __init__(self, max_calls: int, period_s: float, *, clock: Callable[[], float] = time.monotonic,\n                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> None:\n        self._max, self._period, self._clock, self._sleep = max_calls, period_s, clock, sleep\n        self._stamps: deque[float] = deque()\n        self._lock = asyncio.Lock()\n\n    async def acquire(self) -> None:\n        async with self._lock:\n            while True:\n                now = self._clock()\n                while self._stamps and now - self._stamps[0] >= self._period:\n                    self._stamps.popleft()\n                if len(self._stamps) < self._max:\n                    self._stamps.append(now)\n                    return\n                await self._sleep(self._period - (now - self._stamps[0]) + 0.01)\n\n\nclass FourthwallClient:\n    def __init__(self, base_url: str, user: str, secret: str, *, hook: Hook | None = None,\n                 transport: httpx.AsyncBaseTransport | None = None,\n                 gcs_transport: httpx.AsyncBaseTransport | None = None,\n                 limiter: SlidingWindowLimiter | None = None, max_429_retries: int = 3) -> None:\n        self._api = httpx.AsyncClient(base_url=base_url, auth=(user, secret), timeout=30.0, transport=transport)\n        self._gcs = httpx.AsyncClient(timeout=300.0, transport=gcs_transport)   # no auth: credentials must not go to GCS\n        self._hook = hook\n        self._media_limiter = limiter or SlidingWindowLimiter(20, 60.0)\n        self._max_429 = max_429_retries\n\n    async def aclose(self) -> None:\n        await self._api.aclose()\n        await self._gcs.aclose()\n\n    async def __aenter__(self) -> \"FourthwallClient\":\n        return self\n\n    async def __aexit__(self, *exc: Any) -> None:\n        await self.aclose()\n\n    # ------------------------------------------------------------------ plumbing\n    async def _call(self, method: str, path: str, *, event: str, json: Any = None, retry_5xx: bool = False) -> Any:\n        attempt = 0\n        while True:\n            t0 = time.monotonic()\n            resp = await self._api.request(method, path, json=json)\n            if self._hook:\n                await self._hook({\n                    \"event_type\": event, \"http_method\": method, \"url\": str(resp.request.url),\n                    \"status_code\": resp.status_code, \"duration_ms\": int((time.monotonic() - t0) * 1000),\n                    \"payload\": {\"request\": json, \"response\": _clip(resp)},\n                })\n            if resp.status_code == 429 and attempt < self._max_429:\n                attempt += 1\n                wait = _retry_after(resp, default=2.0 * attempt)\n                await asyncio.sleep(wait)\n                continue\n            if resp.status_code >= 500 and retry_5xx and attempt < 2:\n                attempt += 1\n                await asyncio.sleep(1.5 * attempt)\n                continue\n            if resp.is_success:\n                return resp.json() if resp.content else None\n            raise _error_from(resp)\n\n    # ------------------------------------------------------------------ media\n    async def request_upload_url(self, file_name: str, content_type: str, size: int) -> dict[str, str]:\n        await self._media_limiter.acquire()\n        return await self._call(\"POST\", \"/open-api/v1.0/media/upload-url\", event=\"media.upload_url\",\n                                json={\"fileName\": file_name, \"contentType\": content_type, \"size\": size})\n\n    async def put_to_storage(self, upload_url: str, data: bytes, content_type: str, size: int) -> None:\n        if len(data) != size:\n            raise FourthwallError(f\"internal: size {size} != len(data) {len(data)}\")\n        t0 = time.monotonic()\n        resp = await self._gcs.put(upload_url, content=data, headers={\n            \"Content-Type\": content_type, \"x-goog-content-length-range\": f\"0,{size}\"})\n        if self._hook:\n            await self._hook({\"event_type\": \"media.gcs_put\", \"http_method\": \"PUT\",\n                              \"url\": upload_url.split(\"?\")[0], \"status_code\": resp.status_code,\n                              \"duration_ms\": int((time.monotonic() - t0) * 1000),\n                              \"payload\": {\"bytes\": size, \"response\": resp.text[:300]}})\n        if not resp.is_success:\n            raise FourthwallError(f\"GCS upload failed with HTTP {resp.status_code}: {resp.text[:200]}\",\n                                  status=resp.status_code, code=\"GCS_UPLOAD_FAILED\")\n\n    async def register_image(self, file_url: str, width: int, height: int) -> dict[str, Any]:\n        return await self._call(\"POST\", \"/open-api/v1.0/media/images\", event=\"media.register\",\n                                json={\"fileUrl\": file_url, \"width\": width, \"height\": height})\n\n    async def upload_image(self, path: Path) -> dict[str, Any]:\n        \"\"\"3-step upload. Returns the registered image dict (its `id` is the imageId).\"\"\"\n        content_type = _content_type(path)\n        data = await asyncio.to_thread(path.read_bytes)\n        width, height = await asyncio.to_thread(_pixel_size, path)\n        slot = await self.request_upload_url(path.name, content_type, len(data))\n        await self.put_to_storage(slot[\"uploadUrl\"], data, content_type, len(data))\n        return await self.register_image(slot[\"fileUrl\"], width, height)\n\n    # ------------------------------------------------------------------ products\n    async def list_product_templates(self) -> Any:\n        return await self._call(\"GET\", \"/open-api/v1.0/product-templates\", event=\"templates.list\", retry_5xx=True)\n\n    async def create_design_product(self, *, template_id: str, name: str, description: str,\n                                    regions: list[dict[str, str]], publish_on_create: bool = False,\n                                    profit_margin: float | None = None) -> dict[str, Any]:\n        body: dict[str, Any] = {\"type\": \"design\", \"productTemplateId\": template_id, \"name\": name,\n                                \"description\": description, \"regions\": regions, \"publishOnCreate\": publish_on_create}\n        if profit_margin is not None:\n            body[\"profitMargin\"] = profit_margin\n        # POST is not retried on 5xx: the product may exist already and a retry would duplicate it.\n        return await self._call(\"POST\", \"/open-api/v1.0/products\", event=\"product.create\", json=body)\n\n    async def get_product(self, product_id: str) -> dict[str, Any]:\n        return await self._call(\"GET\", f\"/open-api/v1.0/products/{product_id}\", event=\"product.get\", retry_5xx=True)\n\n    async def set_state(self, product_id: str, state: str) -> dict[str, Any]:\n        if state not in (\"PUBLIC\", \"HIDDEN\"):\n            raise ValueError(\"state must be PUBLIC or HIDDEN\")\n        return await self._call(\"PUT\", f\"/open-api/v1.0/products/{product_id}/state\", event=\"product.state\",\n                                json={\"state\": state}, retry_5xx=True)\n\n\n# --------------------------------------------------------------------------- helpers\ndef _content_type(path: Path) -> str:\n    return {\".png\": \"image/png\", \".jpg\": \"image/jpeg\", \".jpeg\": \"image/jpeg\", \".webp\": \"image/webp\",\n            \".pdf\": \"application/pdf\", \".bmp\": \"image/bmp\", \".mp4\": \"video/mp4\",\n            \".svg\": \"image/svg+xml\"}.get(path.suffix.lower(), \"application/octet-stream\")\n\n\ndef _pixel_size(path: Path) -> tuple[int, int]:\n    try:\n        with Image.open(path) as im:\n            return im.width, im.height\n    except Exception:\n        return 1, 1          # non-raster file (PDF/MP4): let Fourthwall decide whether it accepts the type\n\n\ndef _clip(resp: httpx.Response, limit: int = 1500) -> Any:\n    try:\n        text = resp.text\n    except Exception:\n        return None\n    return text[:limit]\n\n\ndef _retry_after(resp: httpx.Response, default: float) -> float:\n    try:\n        return min(60.0, max(0.0, float(resp.headers.get(\"Retry-After\", default))))\n    except ValueError:\n        return default\n\n\ndef _error_from(resp: httpx.Response) -> FourthwallError:\n    try:\n        body = resp.json()\n    except ValueError:\n        body = {\"raw\": resp.text[:300]}\n    code = body.get(\"code\") if isinstance(body, dict) else None\n    msg = f\"Fourthwall HTTP {resp.status_code} {code or ''} on {resp.request.method} {resp.request.url.path}\".strip()\n    if code in (\"UNSUPPORTED_MEDIA_TYPE_ERROR\", \"UNSUPPORTED_ASSET_TYPE_ERROR\"):\n        supported = body.get(\"supportedMediaTypes\") or []\n        return UnsupportedMedia(msg, supported=list(supported), status=resp.status_code, code=code, body=body)\n    return FourthwallError(msg, status=resp.status_code, code=code, body=body)\n";
var worker_default = "\"\"\"Worker entry point.\n\n  python -m pod_pipeline.worker --run-id <uuid>        run exactly one queued run (spawned by the MCP tool)\n  python -m pod_pipeline.worker --drain [--scan]       recover stale runs, optionally scan inbox, then run\n                                                       queued runs until none are left (systemd timer target)\n  python -m pod_pipeline.worker --scan                 only register new inbox files\n  python -m pod_pipeline.worker --list-templates       print Fourthwall productTemplateId values\n\"\"\"\nfrom __future__ import annotations\n\nimport argparse\nimport asyncio\nimport json\nimport logging\nimport os\nimport sys\nimport uuid\n\nfrom . import db\nfrom .config import ConfigError, Settings\nfrom .fourthwall import FourthwallClient, FourthwallError\nfrom .ingest import scan_inbox\nfrom .orchestrator import run_pipeline\n\nlog = logging.getLogger(\"pod.worker\")\n\n\nasync def drain(settings: Settings, pool: db.Pool) -> list[dict]:\n    done: list[dict] = []\n    while True:\n        batch = await asyncio.gather(*[run_pipeline(settings, pool, None, pid=os.getpid())\n                                       for _ in range(settings.max_concurrency)])\n        got = [r for r in batch if r]\n        done.extend(got)\n        if not got:\n            return done\n\n\nasync def list_templates(settings: Settings) -> int:\n    if not (settings.fw_api_user and settings.fw_api_secret):\n        print(\"set FW_API_USER and FW_API_SECRET first\", file=sys.stderr)\n        return 2\n    async with FourthwallClient(settings.fw_base_url, settings.fw_api_user, settings.fw_api_secret) as fw:\n        try:\n            print(json.dumps(await fw.list_product_templates(), indent=2))\n        except FourthwallError as exc:\n            print(f\"Fourthwall error: {exc}\", file=sys.stderr)\n            return 1\n    return 0\n\n\nasync def amain(args: argparse.Namespace) -> int:\n    settings = Settings.from_env()\n    if args.list_templates:\n        return await list_templates(settings)\n    pool = await db.create_pool(settings)\n    try:\n        if args.scan:\n            n = await scan_inbox(settings, pool)\n            log.info(\"inbox scan registered %d new asset(s)\", n)\n        if args.run_id:\n            res = await run_pipeline(settings, pool, uuid.UUID(args.run_id), pid=os.getpid())\n            if res is None:\n                log.info(\"run %s was not claimable (already running or finished)\", args.run_id)\n                return 0\n            log.info(\"run finished: %s\", json.dumps(res))\n            return 0 if res[\"ok\"] else 1\n        if args.drain:\n            recovered = await db.recover_stale_runs(pool)\n            if recovered:\n                log.warning(\"re-queued %d stale run(s) whose worker process vanished\", recovered)\n            results = await drain(settings, pool)\n            failed = [r for r in results if not r[\"ok\"]]\n            log.info(\"drained %d run(s), %d failed\", len(results), len(failed))\n            return 1 if failed else 0\n        return 0\n    finally:\n        await pool.close()\n\n\ndef main() -> None:\n    logging.basicConfig(level=os.environ.get(\"POD_LOG_LEVEL\", \"INFO\"), stream=sys.stderr,\n                        format=\"%(asctime)s %(levelname)s %(name)s: %(message)s\")\n    ap = argparse.ArgumentParser(prog=\"pod_pipeline.worker\")\n    g = ap.add_mutually_exclusive_group()\n    g.add_argument(\"--run-id\")\n    g.add_argument(\"--drain\", action=\"store_true\")\n    g.add_argument(\"--list-templates\", action=\"store_true\")\n    ap.add_argument(\"--scan\", action=\"store_true\", help=\"register new inbox files first\")\n    args = ap.parse_args()\n    if not (args.run_id or args.drain or args.list_templates or args.scan):\n        ap.error(\"nothing to do: pass --run-id, --drain, --scan or --list-templates\")\n    try:\n        sys.exit(asyncio.run(amain(args)))\n    except ConfigError as exc:\n        print(f\"configuration error: {exc}\", file=sys.stderr)\n        sys.exit(2)\n\n\nif __name__ == \"__main__\":\n    main()\n";
var mcp_server_default = "\"\"\"MCP server for the pod pipeline.\n\nSpeaks JSON-RPC 2.0 (MCP tools/list + tools/call) on stdio and on\nPOD_MCP_HOST:POD_MCP_PORT. The three tools are the agent contract:\n\n    list_pending_assets(account_id?)\n    trigger_pipeline_job(asset_id, product_type)\n    get_fourthwall_status(product_id)\n\ntrigger_pipeline_job inserts the orchestrator row and spawns\n`python -m pod_pipeline.worker --run-id`. It does not run the craft steps\ninside this process. STATE is the lazy handle tests patch.\n\"\"\"\nfrom __future__ import annotations\n\nimport argparse\nimport asyncio\nimport json\nimport logging\nimport os\nimport sys\nimport uuid\nfrom typing import Any\n\nfrom . import db\nfrom .config import ConfigError, Settings\nfrom .fourthwall import FourthwallClient, FourthwallError\nfrom .routes import PRODUCT_TYPES\n\nlog = logging.getLogger(\"pod.mcp\")\n\nPROTOCOL = \"2024-11-05\"\n\n\nclass State:\n    def __init__(self) -> None:\n        self.settings: Settings | None = None\n        self.pool: db.Pool | None = None\n        self.lock: asyncio.Lock | None = None\n\n\nSTATE = State()\n\n\nclass ToolError(Exception):\n    pass\n\n\nTOOLS: list[dict[str, Any]] = [\n    {\n        \"name\": \"list_pending_assets\",\n        \"description\": \"Assets sitting in the inbox or stuck in queued/processing past POD stuck_after_s.\",\n        \"inputSchema\": {\n            \"type\": \"object\",\n            \"properties\": {\"account_id\": {\"type\": \"integer\"}},\n            \"additionalProperties\": False,\n        },\n    },\n    {\n        \"name\": \"trigger_pipeline_job\",\n        \"description\": \"Enqueue one asset onto one product route and spawn an isolated worker process.\",\n        \"inputSchema\": {\n            \"type\": \"object\",\n            \"properties\": {\n                \"asset_id\": {\"type\": \"integer\"},\n                \"product_type\": {\"type\": \"string\", \"enum\": list(PRODUCT_TYPES)},\n            },\n            \"required\": [\"asset_id\", \"product_type\"],\n            \"additionalProperties\": False,\n        },\n    },\n    {\n        \"name\": \"get_fourthwall_status\",\n        \"description\": \"Local fourthwall_products row plus the live product, if Fourthwall has an id. product_id is our row id or the Fourthwall product id.\",\n        \"inputSchema\": {\n            \"type\": \"object\",\n            \"properties\": {\"product_id\": {\"type\": \"string\"}},\n            \"required\": [\"product_id\"],\n            \"additionalProperties\": False,\n        },\n    },\n]\n\n\ndef dumps(obj: Any) -> str:\n    return json.dumps(obj, default=str, separators=(\",\", \":\"))\n\n\ndef _jsonable(value: Any) -> Any:\n    if isinstance(value, dict):\n        return {str(k): _jsonable(v) for k, v in value.items()}\n    if isinstance(value, (list, tuple)):\n        return [_jsonable(v) for v in value]\n    if isinstance(value, (bytes, memoryview)):\n        return None\n    return value\n\n\ndef _settings() -> Settings:\n    if STATE.settings is None:\n        STATE.settings = Settings.from_env()\n    return STATE.settings\n\n\nasync def _pool() -> db.Pool:\n    if STATE.pool is None:\n        STATE.pool = await db.create_pool(_settings())\n    return STATE.pool\n\n\ndef _need_int(args: dict[str, Any], name: str, *, required: bool) -> int | None:\n    if name not in args or args[name] is None:\n        if required:\n            raise ToolError(f\"{name} is required\")\n        return None\n    try:\n        return int(args[name])\n    except (TypeError, ValueError) as exc:\n        raise ToolError(f\"{name} must be an integer\") from exc\n\n\nasync def list_pending_assets(arguments: dict[str, Any]) -> dict[str, Any]:\n    settings = _settings()\n    pool = await _pool()\n    account_id = _need_int(arguments, \"account_id\", required=False)\n    rows = await db.pending_assets(pool, stuck_after_s=settings.stuck_after_s, account_id=account_id)\n    return {\"assets\": [_jsonable(r) for r in rows]}\n\n\nasync def _spawn_worker(settings: Settings, run_id: uuid.UUID) -> int:\n    log_path = settings.job_logs / \"mcp-spawn.log\"\n    await asyncio.to_thread(log_path.parent.mkdir, 0o750, True, True)\n    handle = await asyncio.to_thread(open, log_path, \"ab\")\n    try:\n        proc = await asyncio.create_subprocess_exec(\n            sys.executable, \"-m\", \"pod_pipeline.worker\", \"--run-id\", str(run_id),\n            cwd=str(settings.root),\n            env=os.environ.copy(),\n            stdin=asyncio.subprocess.DEVNULL,\n            stdout=handle,\n            stderr=asyncio.subprocess.STDOUT,\n            start_new_session=True,\n        )\n    finally:\n        handle.close()\n    if proc.pid is None:\n        raise ToolError(f\"run {run_id} is queued but the worker pid was not assigned\")\n    return proc.pid\n\n\nasync def trigger_pipeline_job(arguments: dict[str, Any]) -> dict[str, Any]:\n    asset_id = _need_int(arguments, \"asset_id\", required=True)\n    product_type = str(arguments.get(\"product_type\") or \"\")\n    if product_type not in PRODUCT_TYPES:\n        raise ToolError(f\"product_type must be one of {', '.join(PRODUCT_TYPES)}\")\n    assert asset_id is not None\n    settings = _settings()\n    pool = await _pool()\n\n    async def body() -> dict[str, Any]:\n        asset = await db.get_asset(pool, asset_id)\n        if asset is None:\n            raise ToolError(f\"asset {asset_id} does not exist\")\n        run_id, created = await db.enqueue_run(\n            pool, account_id=asset[\"account_id\"], asset_id=asset_id, product_type=product_type)\n        await db.log_sync(\n            pool, account_id=asset[\"account_id\"], direction=\"inbound\", channel=\"mcp\",\n            event_type=\"job.triggered\", run_id=run_id,\n            payload={\"asset_id\": asset_id, \"product_type\": product_type, \"created\": created})\n        if not created:\n            return {\"run_id\": str(run_id), \"created\": False, \"spawned\": False, \"pid\": None}\n        try:\n            pid = await _spawn_worker(settings, run_id)\n        except OSError as exc:\n            return {\n                \"run_id\": str(run_id), \"created\": True, \"spawned\": False, \"pid\": None,\n                \"error\": (\n                    f\"worker did not start ({exc}). The run stays queued; \"\n                    \"pod-worker.timer will claim it.\"\n                ),\n            }\n        return {\"run_id\": str(run_id), \"created\": True, \"spawned\": True, \"pid\": pid}\n\n    if STATE.lock is None:\n        return await body()\n    async with STATE.lock:\n        return await body()\n\n\nasync def get_fourthwall_status(arguments: dict[str, Any]) -> dict[str, Any]:\n    product_id = str(arguments.get(\"product_id\") or \"\").strip()\n    if not product_id:\n        raise ToolError(\"product_id is required\")\n    settings = _settings()\n    pool = await _pool()\n    row = await db.get_product_row(pool, product_id)\n    if row is None:\n        return {\"found\": False, \"product_id\": product_id}\n    live: dict[str, Any] | None = None\n    live_error: str | None = None\n    fw_id = row.get(\"fw_product_id\")\n    if fw_id:\n        creds = await db.get_fw_credentials(pool, settings, row[\"account_id\"])\n        if creds is None:\n            live_error = \"no Fourthwall credentials configured\"\n        else:\n            try:\n                async with FourthwallClient(settings.fw_base_url, creds[0], creds[1]) as fw:\n                    live = await fw.get_product(fw_id)\n            except FourthwallError as exc:\n                live_error = str(exc)[:500]\n    return {\"found\": True, \"row\": _jsonable(row), \"live\": live, \"live_error\": live_error}\n\n\nasync def _dispatch(name: str, arguments: Any) -> dict[str, Any]:\n    if not isinstance(arguments, dict):\n        raise ToolError(\"arguments must be an object\")\n    if name == \"list_pending_assets\":\n        return await list_pending_assets(arguments)\n    if name == \"trigger_pipeline_job\":\n        return await trigger_pipeline_job(arguments)\n    if name == \"get_fourthwall_status\":\n        return await get_fourthwall_status(arguments)\n    raise ToolError(f\"unknown tool {name}\")\n\n\ndef _ok(rid: Any, result: Any) -> dict[str, Any]:\n    return {\"jsonrpc\": \"2.0\", \"id\": rid, \"result\": result}\n\n\ndef _err(rid: Any, code: int, message: str) -> dict[str, Any]:\n    return {\"jsonrpc\": \"2.0\", \"id\": rid, \"error\": {\"code\": code, \"message\": message}}\n\n\nasync def handle_rpc(msg: Any) -> dict[str, Any] | None:\n    if not isinstance(msg, dict):\n        return _err(None, -32600, \"invalid request\")\n    if \"id\" not in msg:\n        return None\n    rid = msg.get(\"id\")\n    method = msg.get(\"method\")\n    params = msg.get(\"params\") or {}\n    if not isinstance(params, dict):\n        return _err(rid, -32602, \"params must be an object\")\n    if method == \"initialize\":\n        return _ok(rid, {\n            \"protocolVersion\": PROTOCOL,\n            \"capabilities\": {\"tools\": {}},\n            \"serverInfo\": {\"name\": \"pod-pipeline\", \"version\": \"1.0.0\"},\n        })\n    if method == \"ping\":\n        return _ok(rid, {})\n    if method == \"tools/list\":\n        return _ok(rid, {\"tools\": TOOLS})\n    if method == \"tools/call\":\n        name = str(params.get(\"name\") or \"\")\n        try:\n            result = await _dispatch(name, params.get(\"arguments\") or {})\n        except ToolError as exc:\n            return _ok(rid, {\"content\": [{\"type\": \"text\", \"text\": str(exc)}], \"isError\": True})\n        except Exception as exc:\n            log.exception(\"tool %s failed\", name)\n            text = f\"{type(exc).__name__}: {exc}\"[:500]\n            return _ok(rid, {\"content\": [{\"type\": \"text\", \"text\": text}], \"isError\": True})\n        return _ok(rid, {\"content\": [{\"type\": \"text\", \"text\": dumps(result)}], \"isError\": False})\n    return _err(rid, -32601, f\"method not found: {method}\")\n\n\ndef _http(status: int, body: bytes) -> bytes:\n    reason = {200: \"OK\", 400: \"Bad Request\", 405: \"Method Not Allowed\", 500: \"Internal Server Error\"}[status]\n    head = (\n        f\"HTTP/1.1 {status} {reason}\\r\\n\"\n        \"Content-Type: application/json\\r\\n\"\n        f\"Content-Length: {len(body)}\\r\\n\"\n        \"Connection: close\\r\\n\\r\\n\"\n    )\n    return head.encode(\"ascii\") + body\n\n\nasync def _read_http(reader: asyncio.StreamReader) -> dict[str, Any] | None:\n    try:\n        head = await asyncio.wait_for(reader.readuntil(b\"\\r\\n\\r\\n\"), 15)\n    except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, asyncio.TimeoutError):\n        return None\n    if len(head) > 16384:\n        return None\n    lines = head.decode(\"iso-8859-1\", \"replace\").split(\"\\r\\n\")\n    parts = lines[0].split(\" \")\n    if len(parts) < 2:\n        return None\n    headers: dict[str, str] = {}\n    for line in lines[1:]:\n        if \":\" not in line:\n            continue\n        key, value = line.split(\":\", 1)\n        headers[key.lower()] = value.strip()\n    try:\n        length = int(headers.get(\"content-length\", \"0\") or 0)\n    except ValueError:\n        return None\n    if length < 0 or length > 1_000_000:\n        return None\n    body = await reader.readexactly(length) if length else b\"\"\n    return {\"method\": parts[0], \"path\": parts[1].split(\"?\", 1)[0], \"body\": body}\n\n\nasync def _client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:\n    try:\n        req = await _read_http(reader)\n        if req is None:\n            writer.write(_http(400, dumps(_err(None, -32700, \"bad http\")).encode()))\n        elif req[\"method\"] == \"GET\" and req[\"path\"] == \"/health\":\n            writer.write(_http(200, b'{\"ok\":true}'))\n        elif req[\"method\"] != \"POST\":\n            writer.write(_http(405, b'{\"error\":\"POST JSON-RPC only\"}'))\n        else:\n            try:\n                msg = json.loads(req[\"body\"].decode(\"utf-8\") if req[\"body\"] else \"null\")\n            except json.JSONDecodeError:\n                writer.write(_http(400, dumps(_err(None, -32700, \"parse error\")).encode()))\n            else:\n                resp = await handle_rpc(msg)\n                if resp is None:\n                    writer.write(b\"HTTP/1.1 204 No Content\\r\\nConnection: close\\r\\n\\r\\n\")\n                else:\n                    writer.write(_http(200, dumps(resp).encode()))\n        await writer.drain()\n    except Exception as exc:\n        log.exception(\"mcp connection failed\")\n        try:\n            writer.write(_http(500, dumps(_err(None, -32603, str(exc)[:300])).encode()))\n            await writer.drain()\n        except Exception:\n            pass\n    finally:\n        writer.close()\n        try:\n            await writer.wait_closed()\n        except Exception:\n            pass\n\n\nasync def serve_http() -> None:\n    settings = _settings()\n    server = await asyncio.start_server(_client, settings.mcp_host, settings.mcp_port)\n    sockets = \", \".join(str(s.getsockname()) for s in server.sockets or [])\n    log.info(\"mcp http listening on %s\", sockets)\n    async with server:\n        await server.serve_forever()\n\n\ndef _frame(obj: dict[str, Any], framed: bool) -> bytes:\n    data = dumps(obj).encode()\n    if not framed:\n        return data + b\"\\n\"\n    return f\"Content-Length: {len(data)}\\r\\n\\r\\n\".encode(\"ascii\") + data\n\n\nasync def serve_stdio() -> None:\n    loop = asyncio.get_running_loop()\n    reader = asyncio.StreamReader()\n    protocol = asyncio.StreamReaderProtocol(reader)\n    await loop.connect_read_pipe(lambda: protocol, sys.stdin)\n    framed: bool | None = None\n\n    def write(data: bytes) -> None:\n        sys.stdout.buffer.write(data)\n        sys.stdout.buffer.flush()\n\n    while True:\n        peek = await reader.read(1)\n        if not peek:\n            return\n        if peek == b\"{\":\n            rest = await reader.readline()\n            raw = peek + rest\n            this_framed = False\n        else:\n            this_framed = True\n            header = bytearray(peek)\n            while b\"\\r\\n\\r\\n\" not in header and b\"\\n\\n\" not in header:\n                more = await reader.read(1)\n                if not more:\n                    return\n                header += more\n                if len(header) > 16384:\n                    return\n            text = header.decode(\"iso-8859-1\", \"replace\")\n            sep = \"\\r\\n\\r\\n\" if \"\\r\\n\\r\\n\" in text else \"\\n\\n\"\n            try:\n                length = int(text.lower().split(\"content-length:\", 1)[1].split(\"\\n\", 1)[0].strip())\n            except (IndexError, ValueError):\n                await loop.run_in_executor(None, write, _frame(_err(None, -32700, \"missing Content-Length\"), True))\n                return\n            raw = await reader.readexactly(length)\n        if framed is None:\n            framed = this_framed\n        try:\n            msg = json.loads(raw.decode(\"utf-8\"))\n        except json.JSONDecodeError:\n            await loop.run_in_executor(None, write, _frame(_err(None, -32700, \"parse error\"), bool(framed)))\n            continue\n        resp = await handle_rpc(msg)\n        if resp is not None:\n            await loop.run_in_executor(None, write, _frame(resp, bool(framed)))\n\n\ndef main() -> None:\n    logging.basicConfig(\n        level=os.environ.get(\"POD_LOG_LEVEL\", \"INFO\"), stream=sys.stderr,\n        format=\"%(asctime)s %(levelname)s %(name)s: %(message)s\")\n    ap = argparse.ArgumentParser(prog=\"pod_pipeline.mcp_server\")\n    mode = ap.add_mutually_exclusive_group(required=True)\n    mode.add_argument(\"--http\", action=\"store_true\")\n    mode.add_argument(\"--stdio\", action=\"store_true\")\n    mode.add_argument(\"--call\", nargs=2, metavar=(\"TOOL\", \"JSON\"))\n    args = ap.parse_args()\n    try:\n        if args.call:\n            name, raw = args.call\n            result = asyncio.run(_dispatch(name, json.loads(raw)))\n            print(dumps(result))\n            return\n        asyncio.run(serve_stdio() if args.stdio else serve_http())\n    except ConfigError as exc:\n        print(f\"configuration error: {exc}\", file=sys.stderr)\n        sys.exit(2)\n    except ToolError as exc:\n        print(str(exc), file=sys.stderr)\n        sys.exit(1)\n    except KeyboardInterrupt:\n        sys.exit(0)\n\n\nif __name__ == \"__main__\":\n    main()\n";
var schema_default = "-- DeerFlow pod pipeline. Matches the SQL in pod_pipeline/db.py and tests/conftest.py.\n-- Apply as the database owner (docker image user pod_app, a superuser inside that container):\n--   docker exec -i pod-postgres psql -U pod_app -d pod -v ON_ERROR_STOP=1 < sql/schema.sql\n--\n-- Tenant insert (POD_CREDENTIAL_KEY is the pgp passphrase, never the Fourthwall secret):\n--   INSERT INTO users_saas_accounts\n--     (display_name, tenant_token_hash, sync_domain, fourthwall_api_user, fourthwall_api_secret_enc)\n--   VALUES (\n--     'Shop', encode(sha256('rotate-me'), 'hex'), 'shop.example',\n--     'api-user', pgp_sym_encrypt('api-secret', 'the POD_CREDENTIAL_KEY value')\n--   );\n\nBEGIN;\n\nCREATE EXTENSION IF NOT EXISTS pgcrypto;\n\nCREATE OR REPLACE FUNCTION pod_touch_updated_at() RETURNS trigger\nLANGUAGE plpgsql AS $$\nBEGIN\n    NEW.updated_at := now();\n    RETURN NEW;\nEND;\n$$;\n\nCREATE TABLE IF NOT EXISTS users_saas_accounts (\n    id                          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    display_name                text NOT NULL,\n    tenant_token_hash           text NOT NULL,\n    sync_domain                 text,\n    fourthwall_api_user         text,\n    fourthwall_api_secret_enc   bytea,\n    auto_publish                boolean NOT NULL DEFAULT false,\n    status                      text NOT NULL DEFAULT 'active',\n    created_at                  timestamptz NOT NULL DEFAULT now(),\n    CONSTRAINT users_saas_accounts_token_len CHECK (char_length(tenant_token_hash) = 64),\n    CONSTRAINT users_saas_accounts_status CHECK (status IN ('active', 'revoked')),\n    CONSTRAINT users_saas_accounts_domain CHECK (\n        sync_domain IS NULL OR sync_domain ~ '^[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'\n    )\n);\n\nCREATE UNIQUE INDEX IF NOT EXISTS users_saas_accounts_token_idx\n    ON users_saas_accounts (tenant_token_hash);\n\nCREATE UNIQUE INDEX IF NOT EXISTS users_saas_accounts_domain_idx\n    ON users_saas_accounts (sync_domain)\n    WHERE sync_domain IS NOT NULL AND status = 'active';\n\nCREATE TABLE IF NOT EXISTS ingested_assets (\n    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    account_id          bigint NOT NULL REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,\n    source_kind         text NOT NULL DEFAULT 'directory',\n    source_path         text NOT NULL,\n    original_filename   text NOT NULL,\n    sha256              text NOT NULL,\n    byte_size           bigint NOT NULL,\n    mime_type           text,\n    width_px            integer,\n    height_px           integer,\n    source_dpi          integer,\n    color_space         text NOT NULL DEFAULT 'unknown',\n    has_alpha           boolean,\n    status              text NOT NULL DEFAULT 'pending',\n    trace_state         text NOT NULL DEFAULT 'pending',\n    trace_bounds        jsonb,\n    created_at          timestamptz NOT NULL DEFAULT now(),\n    updated_at          timestamptz NOT NULL DEFAULT now(),\n    CONSTRAINT ingested_assets_sha CHECK (sha256 ~ '^[0-9a-f]{64}$'),\n    CONSTRAINT ingested_assets_size CHECK (byte_size > 0),\n    CONSTRAINT ingested_assets_kind CHECK (source_kind IN ('directory', 'webhook')),\n    CONSTRAINT ingested_assets_dims CHECK (\n        (width_px IS NULL OR width_px > 0) AND (height_px IS NULL OR height_px > 0)\n    ),\n    CONSTRAINT ingested_assets_dpi CHECK (source_dpi IS NULL OR source_dpi > 0),\n    CONSTRAINT ingested_assets_status CHECK (\n        status IN ('pending', 'queued', 'processing', 'processed', 'failed', 'quarantined')\n    ),\n    CONSTRAINT ingested_assets_trace CHECK (\n        trace_state IN ('pending', 'tracing', 'traced', 'raster_fallback', 'trace_failed')\n    )\n);\n\nCREATE UNIQUE INDEX IF NOT EXISTS ingested_assets_account_sha_idx\n    ON ingested_assets (account_id, sha256);\n\nCREATE INDEX IF NOT EXISTS ingested_assets_status_updated_idx\n    ON ingested_assets (status, updated_at);\n\nCREATE INDEX IF NOT EXISTS ingested_assets_source_path_idx\n    ON ingested_assets (source_path);\n\nDROP TRIGGER IF EXISTS ingested_assets_touch ON ingested_assets;\nCREATE TRIGGER ingested_assets_touch\n    BEFORE UPDATE ON ingested_assets\n    FOR EACH ROW EXECUTE FUNCTION pod_touch_updated_at();\n\nCREATE TABLE IF NOT EXISTS processing_jobs (\n    id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    run_id          uuid NOT NULL,\n    account_id      bigint NOT NULL REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,\n    asset_id        bigint NOT NULL REFERENCES ingested_assets (id) ON DELETE RESTRICT,\n    product_type    text NOT NULL,\n    module          text NOT NULL,\n    step_name       text NOT NULL,\n    step_index      integer NOT NULL,\n    attempt         integer NOT NULL DEFAULT 1,\n    fallback_tier   integer NOT NULL DEFAULT 0,\n    status          text NOT NULL,\n    pid             integer,\n    argv            text[],\n    exit_code       integer,\n    error_digest    text,\n    log_path        text,\n    output_path     text,\n    started_at      timestamptz,\n    finished_at     timestamptz,\n    CONSTRAINT processing_jobs_product CHECK (\n        product_type IN ('apparel', 'knitwear', 'accessories', 'odd_3d', 'stationery')\n    ),\n    CONSTRAINT processing_jobs_module CHECK (\n        module IN ('orchestrator', 'vectorcraft', 'photocraft', 'designcraft', 'effectcraft', 'filmcraft')\n    ),\n    CONSTRAINT processing_jobs_status CHECK (status IN ('queued', 'running', 'succeeded', 'failed')),\n    CONSTRAINT processing_jobs_attempt CHECK (attempt >= 1),\n    CONSTRAINT processing_jobs_tier CHECK (fallback_tier >= 0),\n    CONSTRAINT processing_jobs_step CHECK (step_index >= 0),\n    CONSTRAINT processing_jobs_time_order CHECK (\n        finished_at IS NULL OR started_at IS NULL OR finished_at >= started_at\n    ),\n    CONSTRAINT processing_jobs_digest_budget CHECK (\n        error_digest IS NULL OR char_length(error_digest) <= 8000\n    )\n);\n\n-- One live orchestrator run per asset + product. enqueue_run depends on this raising unique_violation.\nCREATE UNIQUE INDEX IF NOT EXISTS processing_jobs_one_live_run\n    ON processing_jobs (asset_id, product_type)\n    WHERE module = 'orchestrator' AND status IN ('queued', 'running');\n\nCREATE INDEX IF NOT EXISTS processing_jobs_run_idx\n    ON processing_jobs (run_id);\n\nCREATE INDEX IF NOT EXISTS processing_jobs_queued_idx\n    ON processing_jobs (id)\n    WHERE module = 'orchestrator' AND status = 'queued';\n\nCREATE TABLE IF NOT EXISTS fourthwall_products (\n    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    account_id          bigint NOT NULL REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,\n    asset_id            bigint NOT NULL REFERENCES ingested_assets (id) ON DELETE RESTRICT,\n    run_id              uuid,\n    product_type        text NOT NULL,\n    fw_template_id      text,\n    media_id            text,\n    media_file_url      text,\n    fw_product_id       text,\n    fw_slug             text,\n    variants            jsonb NOT NULL DEFAULT '[]'::jsonb,\n    skus                text[] NOT NULL DEFAULT '{}',\n    publish_state       text NOT NULL DEFAULT 'draft',\n    last_error          text,\n    published_at        timestamptz,\n    updated_at          timestamptz NOT NULL DEFAULT now(),\n    CONSTRAINT fourthwall_products_natural UNIQUE (account_id, asset_id, product_type),\n    CONSTRAINT fourthwall_products_type CHECK (\n        product_type IN ('apparel', 'knitwear', 'accessories', 'odd_3d', 'stationery')\n    ),\n    CONSTRAINT fourthwall_products_state CHECK (\n        publish_state IN ('draft', 'processing', 'active', 'failed', 'needs_manual_upload')\n    )\n);\n\nCREATE INDEX IF NOT EXISTS fourthwall_products_fw_product_idx\n    ON fourthwall_products (fw_product_id)\n    WHERE fw_product_id IS NOT NULL;\n\nCREATE INDEX IF NOT EXISTS fourthwall_products_media_idx\n    ON fourthwall_products (media_id)\n    WHERE media_id IS NOT NULL;\n\nCREATE INDEX IF NOT EXISTS fourthwall_products_state_idx\n    ON fourthwall_products (publish_state);\n\nDROP TRIGGER IF EXISTS fourthwall_products_touch ON fourthwall_products;\nCREATE TRIGGER fourthwall_products_touch\n    BEFORE UPDATE ON fourthwall_products\n    FOR EACH ROW EXECUTE FUNCTION pod_touch_updated_at();\n\nCREATE TABLE IF NOT EXISTS agent_sync_logs (\n    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,\n    account_id          bigint REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,\n    direction           text NOT NULL,\n    channel             text NOT NULL,\n    event_type          text NOT NULL,\n    external_event_id   text,\n    http_method         text,\n    url                 text,\n    status_code         integer,\n    success             boolean,\n    duration_ms         integer,\n    payload             jsonb,\n    run_id              uuid,\n    fw_product_row_id   bigint REFERENCES fourthwall_products (id) ON DELETE RESTRICT,\n    created_at          timestamptz NOT NULL DEFAULT now(),\n    CONSTRAINT agent_sync_logs_direction CHECK (direction IN ('inbound', 'outbound')),\n    CONSTRAINT agent_sync_logs_duration CHECK (duration_ms IS NULL OR duration_ms >= 0),\n    CONSTRAINT agent_sync_logs_payload_budget CHECK (\n        payload IS NULL OR octet_length(payload::text) <= 32768\n    )\n);\n\n-- log_sync uses ON CONFLICT DO NOTHING. Webhook retries share external_event_id; null ids never collide.\nCREATE UNIQUE INDEX IF NOT EXISTS agent_sync_logs_external_event_idx\n    ON agent_sync_logs (external_event_id)\n    WHERE external_event_id IS NOT NULL;\n\nCREATE INDEX IF NOT EXISTS agent_sync_logs_account_idx\n    ON agent_sync_logs (account_id, id DESC);\n\nCREATE INDEX IF NOT EXISTS agent_sync_logs_run_idx\n    ON agent_sync_logs (run_id)\n    WHERE run_id IS NOT NULL;\n\nCOMMIT;\n";
var products_default = "{\n  \"apparel\": {\n    \"fourthwall_template_id\": \"REPLACE_WITH_TEMPLATE_ID\",\n    \"regions\": [\"front\"],\n    \"profit_margin\": 0.4\n  },\n  \"knitwear\": {\n    \"fourthwall_template_id\": \"REPLACE_WITH_TEMPLATE_ID\",\n    \"regions\": [\"front\"],\n    \"palette_limit\": 6,\n    \"knit_grid\": \"112x140\"\n  },\n  \"accessories\": {\n    \"fourthwall_template_id\": \"REPLACE_WITH_TEMPLATE_ID\",\n    \"regions\": [\"front\"],\n    \"template\": \"fourthwall_crossbody_v1\",\n    \"care_text\": \"100% Polyester\"\n  },\n  \"odd_3d\": {\n    \"fourthwall_template_id\": \"REPLACE_WITH_TEMPLATE_ID\",\n    \"regions\": [\"front\"],\n    \"bleed_in\": \"0.25\"\n  },\n  \"stationery\": {\n    \"fourthwall_template_id\": \"REPLACE_WITH_TEMPLATE_ID\",\n    \"regions\": [\"front\"],\n    \"cover_template\": \"notebook_cover_template\",\n    \"reel_template\": \"reel_promo_9_16\",\n    \"reel_preset\": \"tiktok_1080p\"\n  }\n}\n";
var pipeline_env_default = "# systemd EnvironmentFile. Do not quote values. setup-pipeline.sh replaces the tokens.\nPOD_ROOT=/opt/pod-pipeline\nPYTHONPATH=/opt/pod-pipeline\nDATABASE_URL=postgresql://pod_app:__DB_PASS__@127.0.0.1:5432/pod\nPOD_DB_PASS=__DB_PASS__\nPOD_CREDENTIAL_KEY=__CRED_KEY__\nFW_BASE_URL=https://api.fourthwall.com\nFW_API_USER=\nFW_API_SECRET=\nPOD_USE_DOCKER=0\nPOD_DOCKER_IMAGE=pod-craft-runner:latest\nPOD_DOCKER_MEMORY=2g\nPOD_DOCKER_CPUS=1.5\nPOD_DOCKER_CPU_SHARES=256\nPOD_NICE_LEVEL=10\nPOD_MAX_CONCURRENCY=2\nPOD_STEP_TIMEOUT_S=900\nPOD_FALLBACK_RASTER_DPI=600\nPOD_MCP_HOST=127.0.0.1\nPOD_MCP_PORT=8765\nPOD_LOG_LEVEL=INFO\n";
var requirements_default = "asyncpg>=0.29.0\nhttpx>=0.27.0\nPillow>=10.4.0\n";
var setup_pipeline_default = "#!/usr/bin/env bash\n# Install the DeerFlow pod pipeline onto a Debian/Ubuntu VPS.\n# The tree must already be at /opt/pod-pipeline (this script lives in deploy/).\n# Re-running is safe: env, products.json, and vendor CLIs already in bin/ are kept.\nset -euo pipefail\ntrap 'echo \"setup-pipeline.sh failed at line $LINENO\" >&2' ERR\numask 027\n\nROOT=\"${POD_ROOT:-/opt/pod-pipeline}\"\nAPP_USER=\"${POD_USER:-pod}\"\nAPP_GROUP=\"${POD_GROUP:-pod}\"\n\nif [[ \"$(id -u)\" -ne 0 ]]; then\n  echo \"setup-pipeline.sh must run as root\" >&2\n  exit 1\nfi\nif [[ ! -f \"$ROOT/sql/schema.sql\" || ! -f \"$ROOT/deploy/compose.yml\" ]]; then\n  echo \"expected the pipeline tree at $ROOT\" >&2\n  exit 1\nfi\n\nexport DEBIAN_FRONTEND=noninteractive\napt-get update\napt-get install -y --no-install-recommends \\\n  ca-certificates curl \\\n  python3 python3-venv python3-pip \\\n  imagemagick potrace ghostscript ffmpeg \\\n  docker.io docker-compose-v2\n\nif command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then\n  systemctl enable --now docker\nfi\nif ! docker info >/dev/null 2>&1; then\n  echo \"the docker daemon is not running\" >&2\n  exit 1\nfi\nif ! docker compose version >/dev/null 2>&1; then\n  echo \"docker compose v2 is required\" >&2\n  exit 1\nfi\n\nif ! id -u \"$APP_USER\" >/dev/null 2>&1; then\n  useradd --system --create-home --home-dir \"$ROOT\" --shell /usr/sbin/nologin \"$APP_USER\"\nfi\nif getent group docker >/dev/null 2>&1; then\n  usermod -aG docker \"$APP_USER\"\nfi\n\ninstall -d -o \"$APP_USER\" -g \"$APP_GROUP\" -m 0750 \\\n  \"$ROOT/bin\" \\\n  \"$ROOT/config\" \\\n  \"$ROOT/data/inbox\" \\\n  \"$ROOT/sandbox\" \\\n  \"$ROOT/build\" \\\n  \"$ROOT/logs/jobs\" \\\n  \"$ROOT/sql\" \\\n  \"$ROOT/deploy\"\n\nif [[ ! -x \"$ROOT/.venv/bin/python\" ]]; then\n  python3 -m venv \"$ROOT/.venv\"\nfi\n\"$ROOT/.venv/bin/pip\" install --disable-pip-version-check -r \"$ROOT/requirements.txt\"\n\nfor tool in vectorcraft-cli photocraft-cli designcraft-cli effectcraft-cli filmcraft-cli; do\n  if [[ ! -e \"$ROOT/bin/$tool\" ]]; then\n    install -m 0755 \"$ROOT/deploy/craft-bin/$tool\" \"$ROOT/bin/$tool\"\n  fi\ndone\n\nif [[ ! -f \"$ROOT/config/products.json\" ]]; then\n  echo \"missing $ROOT/config/products.json\" >&2\n  exit 1\nfi\n\nif [[ ! -f \"$ROOT/config/pipeline.env\" ]]; then\n  db_pass=\"$(python3 -c 'import secrets; print(secrets.token_hex(24))')\"\n  cred_key=\"$(python3 -c 'import secrets; print(secrets.token_hex(32))')\"\n  sed -e \"s/__DB_PASS__/${db_pass}/g\" -e \"s/__CRED_KEY__/${cred_key}/g\" \\\n    \"$ROOT/config/pipeline.env.example\" > \"$ROOT/config/pipeline.env\"\n  chmod 0640 \"$ROOT/config/pipeline.env\"\nfi\n\nset -a\n# shellcheck disable=SC1091\n. \"$ROOT/config/pipeline.env\"\nset +a\n\nif [[ -z \"${POD_DB_PASS:-}\" || -z \"${DATABASE_URL:-}\" ]]; then\n  echo \"pipeline.env is missing POD_DB_PASS or DATABASE_URL\" >&2\n  exit 1\nfi\n\nif python3 -c 'import socket,sys;s=socket.socket();s.settimeout(0.3);r=s.connect_ex((\"127.0.0.1\",5432));s.close();sys.exit(0 if r==0 else 1)' \\\n  && ! docker ps --format '{{.Names}}' | grep -qx pod-postgres; then\n  echo \"127.0.0.1:5432 is in use and pod-postgres is not the listener\" >&2\n  exit 1\nfi\n\ndocker build -t \"${POD_DOCKER_IMAGE:-pod-craft-runner:latest}\" -f \"$ROOT/deploy/Dockerfile\" \"$ROOT\"\ndocker compose --env-file \"$ROOT/config/pipeline.env\" -f \"$ROOT/deploy/compose.yml\" up -d\n\nready=0\nfor _ in $(seq 1 40); do\n  status=\"$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{end}}' pod-postgres 2>/dev/null || true)\"\n  if [[ \"$status\" == \"healthy\" ]]; then\n    ready=1\n    break\n  fi\n  sleep 1\ndone\nif [[ \"$ready\" -ne 1 ]]; then\n  echo \"pod-postgres did not become healthy\" >&2\n  docker logs --tail 80 pod-postgres >&2 || true\n  exit 1\nfi\n\ndocker exec -i pod-postgres psql -U pod_app -d pod -v ON_ERROR_STOP=1 < \"$ROOT/sql/schema.sql\"\n\nif command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then\n  install -m 0644 \"$ROOT/deploy/systemd/pod-mcp.service\" /etc/systemd/system/pod-mcp.service\n  install -m 0644 \"$ROOT/deploy/systemd/pod-worker.service\" /etc/systemd/system/pod-worker.service\n  install -m 0644 \"$ROOT/deploy/systemd/pod-worker.timer\" /etc/systemd/system/pod-worker.timer\n  systemctl daemon-reload\n  systemctl enable --now pod-mcp.service pod-worker.timer\nelse\n  echo \"systemd is not running; start the MCP and the worker timer yourself\" >&2\nfi\n\nchown -R \"$APP_USER:$APP_GROUP\" \"$ROOT\"\nchmod 0640 \"$ROOT/config/pipeline.env\"\n\necho \"pod pipeline ready at $ROOT\"\necho \"next: insert a users_saas_accounts row, then drop files in $ROOT/data/inbox/<account_id>/\"\n";
var compose_default = "name: pod-pipeline\nservices:\n  postgres:\n    image: postgres:16\n    container_name: pod-postgres\n    environment:\n      POSTGRES_USER: pod_app\n      POSTGRES_PASSWORD: ${POD_DB_PASS}\n      POSTGRES_DB: pod\n    ports:\n      - \"127.0.0.1:5432:5432\"\n    volumes:\n      - pgdata:/var/lib/postgresql/data\n    mem_limit: 1g\n    cpus: 0.75\n    shm_size: 128mb\n    restart: unless-stopped\n    healthcheck:\n      test: [\"CMD-SHELL\", \"pg_isready -U pod_app -d pod\"]\n      interval: 5s\n      timeout: 3s\n      retries: 20\nvolumes:\n  pgdata:\n";
var Dockerfile_raw_default = "# Craft sandbox image. Build context is /opt/pod-pipeline.\n# CLIs are the scripts in deploy/craft-bin until vendor binaries replace them.\nFROM debian:bookworm-slim\n\nRUN apt-get update \\\n    && apt-get install -y --no-install-recommends \\\n        ca-certificates imagemagick potrace ghostscript ffmpeg python3 \\\n    && rm -rf /var/lib/apt/lists/* \\\n    && useradd --system --uid 10001 --home-dir /tmp --shell /usr/sbin/nologin craft\n\nCOPY deploy/craft-bin/ /usr/local/bin/\n\nUSER 10001:10001\nWORKDIR /tmp\n";
var mcp_stdio_default = "#!/usr/bin/env node\n// stdio MCP bridge. DeerFlow speaks Content-Length frames (or one JSON object\n// per line) on stdin. Each message is POSTed to the Python server and the\n// response is written back as a Content-Length frame.\n//\n// Tools live in pod_pipeline/mcp_server.py:\n//   list_pending_assets, trigger_pipeline_job, get_fourthwall_status\n//\n//   node deploy/mcp-stdio.mjs\n//   POD_MCP_URL defaults to http://127.0.0.1:8765/\n\nimport { Buffer } from \"node:buffer\";\n\nconst url = process.env.POD_MCP_URL ?? \"http://127.0.0.1:8765/\";\n\nfunction createReader(stream) {\n  let buf = Buffer.alloc(0);\n  let ended = false;\n  /** @type {Array<() => void>} */\n  const pending = [];\n\n  stream.on(\"data\", (chunk) => {\n    buf = Buffer.concat([buf, chunk]);\n    while (pending.length) {\n      const wake = pending.shift();\n      if (wake) wake();\n    }\n  });\n  stream.on(\"end\", () => {\n    ended = true;\n    while (pending.length) {\n      const wake = pending.shift();\n      if (wake) wake();\n    }\n  });\n\n  function wait() {\n    return new Promise((resolve) => {\n      pending.push(resolve);\n    });\n  }\n\n  function take(n) {\n    const out = Buffer.from(buf.subarray(0, n));\n    buf = buf.subarray(n);\n    return out;\n  }\n\n  async function fill(n) {\n    while (buf.length < n) {\n      if (ended) return false;\n      await wait();\n    }\n    return true;\n  }\n\n  return {\n    async readMessage() {\n      if (!(await fill(1))) return null;\n      if (buf[0] === 0x7b) {\n        while (buf.indexOf(0x0a) < 0) {\n          if (!(await fill(buf.length + 1))) return null;\n        }\n        const line = take(buf.indexOf(0x0a));\n        take(1);\n        return JSON.parse(line.toString(\"utf8\"));\n      }\n      while (buf.indexOf(\"\\r\\n\\r\\n\") < 0 && buf.indexOf(\"\\n\\n\") < 0) {\n        if (!(await fill(buf.length + 1))) return null;\n      }\n      let sep = buf.indexOf(\"\\r\\n\\r\\n\");\n      let sepLen = 4;\n      if (sep < 0) {\n        sep = buf.indexOf(\"\\n\\n\");\n        sepLen = 2;\n      }\n      const header = take(sep + sepLen).toString(\"utf8\");\n      const match = /content-length:\\s*(\\d+)/i.exec(header);\n      if (!match) throw new Error(\"missing Content-Length\");\n      const n = Number(match[1]);\n      if (!(await fill(n))) return null;\n      return JSON.parse(take(n).toString(\"utf8\"));\n    },\n  };\n}\n\nfunction writeFrame(obj) {\n  const body = Buffer.from(JSON.stringify(obj));\n  process.stdout.write(`Content-Length: ${body.length}\\r\\n\\r\\n`);\n  process.stdout.write(body);\n}\n\nasync function main() {\n  const reader = createReader(process.stdin);\n  for (;;) {\n    const msg = await reader.readMessage();\n    if (msg == null) return;\n    /** @type {unknown} */\n    let out;\n    try {\n      const res = await fetch(url, {\n        method: \"POST\",\n        headers: { \"content-type\": \"application/json\" },\n        body: JSON.stringify(msg),\n      });\n      if (res.status === 204) continue;\n      out = await res.json();\n    } catch (err) {\n      out = {\n        jsonrpc: \"2.0\",\n        id: msg.id ?? null,\n        error: { code: -32000, message: err instanceof Error ? err.message : \"bridge failed\" },\n      };\n    }\n    if (msg.id === undefined) continue;\n    writeFrame(out);\n  }\n}\n\nmain().catch((err) => {\n  process.stderr.write(`${err instanceof Error ? err.stack : String(err)}\\n`);\n  process.exit(1);\n});\n";
var pod_mcp_default = "[Unit]\nDescription=DeerFlow pod pipeline MCP\nAfter=docker.service network-online.target\nWants=docker.service network-online.target\n\n[Service]\nUser=pod\nGroup=pod\nSupplementaryGroups=docker\nWorkingDirectory=/opt/pod-pipeline\nEnvironmentFile=/opt/pod-pipeline/config/pipeline.env\nExecStart=/opt/pod-pipeline/.venv/bin/python -m pod_pipeline.mcp_server --http\nRestart=on-failure\nRestartSec=2\nNoNewPrivileges=true\n\n[Install]\nWantedBy=multi-user.target\n";
var pod_worker_default$1 = "[Unit]\nDescription=Drain DeerFlow pod pipeline runs\nAfter=docker.service pod-mcp.service\nWants=docker.service\n\n[Service]\nType=oneshot\nUser=pod\nGroup=pod\nSupplementaryGroups=docker\nWorkingDirectory=/opt/pod-pipeline\nEnvironmentFile=/opt/pod-pipeline/config/pipeline.env\nExecStart=/opt/pod-pipeline/.venv/bin/python -m pod_pipeline.worker --drain --scan\nNoNewPrivileges=true\n";
var pod_worker_default = "[Unit]\nDescription=Drain the DeerFlow pod pipeline every minute\n\n[Timer]\nOnBootSec=45\nOnUnitActiveSec=60\nAccuracySec=10\nPersistent=true\n\n[Install]\nWantedBy=timers.target\n";
var vectorcraft_cli_raw_default = "#!/bin/sh\necho \"vectorcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner.\" >&2\nexit 127\n";
var photocraft_cli_raw_default = "#!/bin/sh\necho \"photocraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner.\" >&2\nexit 127\n";
var designcraft_cli_raw_default = "#!/bin/sh\necho \"designcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner.\" >&2\nexit 127\n";
var effectcraft_cli_raw_default = "#!/bin/sh\necho \"effectcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner.\" >&2\nexit 127\n";
var filmcraft_cli_raw_default = "#!/bin/sh\necho \"filmcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner.\" >&2\nexit 127\n";
var conftest_default = "from __future__ import annotations\n\nimport dataclasses\nimport json\nimport os\nimport re\nimport stat\nimport subprocess\nimport sys\nfrom pathlib import Path\nfrom typing import Any, Callable\n\nimport asyncpg\nimport httpx\nimport pytest\nimport pytest_asyncio\nfrom PIL import Image\n\nfrom pod_pipeline import db, orchestrator\nfrom pod_pipeline.config import Settings\nfrom pod_pipeline.fourthwall import FourthwallClient\n\nROOT = Path(__file__).resolve().parent.parent\nTEST_DB_URL = os.environ.get(\"TEST_DATABASE_URL\", \"postgresql://pod_app:devpass@127.0.0.1:5432/pod_test\")\nCRED_KEY = \"test-credential-key-0123456789abcdef\"\nCRAFT_TOOLS = (\"photocraft-cli\", \"vectorcraft-cli\", \"designcraft-cli\", \"effectcraft-cli\", \"filmcraft-cli\")\n\n\ndef _admin(sql: str) -> None:\n    subprocess.run([\"su\", \"postgres\", \"-c\", f'psql -v ON_ERROR_STOP=1 -q -c \"{sql}\"'], check=True, capture_output=True)\n\n\n@pytest.fixture(scope=\"session\", autouse=True)\ndef _database() -> None:\n    m = re.match(r\"postgresql://([^:]+):([^@]+)@([^:/]+):(\\d+)/(\\w+)\", TEST_DB_URL)\n    user, _pw, _h, _p, name = m.groups()           # type: ignore[union-attr]\n    _admin(f\"DROP DATABASE IF EXISTS {name}\")\n    _admin(f\"CREATE DATABASE {name} OWNER {user}\")\n    env = {**os.environ, \"PGPASSWORD\": _pw}\n    subprocess.run([\"psql\", TEST_DB_URL, \"-v\", \"ON_ERROR_STOP=1\", \"-q\", \"-1\", \"-f\", str(ROOT / \"sql\" / \"schema.sql\")],\n                   check=True, capture_output=True, env=env)\n\n\n@pytest.fixture\ndef stubs_env(tmp_path: Path) -> Path:\n    \"\"\"<root>/bin with launcher scripts for every Craft CLI -> tests/stubs/craft_stub.py.\"\"\"\n    bin_dir = tmp_path / \"root\" / \"bin\"\n    bin_dir.mkdir(parents=True)\n    for tool in CRAFT_TOOLS:\n        launcher = bin_dir / tool\n        launcher.write_text(f\"#!{sys.executable}\\nimport runpy,sys\\nsys.path.insert(0, {str(ROOT / 'tests' / 'stubs')!r})\\n\"\n                            f\"import craft_stub\\ncraft_stub.main()\\n\")\n        launcher.chmod(launcher.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)\n    return tmp_path / \"root\"\n\n\n@pytest.fixture\ndef settings(stubs_env: Path) -> Settings:\n    products = {\n        \"apparel\": {\"fourthwall_template_id\": \"pro_apparel\"},\n        \"knitwear\": {\"fourthwall_template_id\": \"pro_knit\", \"knit_grid\": \"40x50\", \"palette_limit\": 6},\n        \"accessories\": {\"fourthwall_template_id\": \"pro_acc\"},\n        \"odd_3d\": {\"fourthwall_template_id\": \"pro_odd\"},\n        \"stationery\": {\"fourthwall_template_id\": \"pro_stat\"},\n    }\n    return Settings(root=stubs_env, database_url=TEST_DB_URL, credential_key=CRED_KEY, flush_poll_s=0.02,\n                    inbox_settle_s=0, step_timeout_s=30, max_log_bytes=2 * 1024 * 1024, products=products)\n\n\n@pytest_asyncio.fixture\nasync def pool(settings: Settings):\n    p = await asyncpg.create_pool(TEST_DB_URL, min_size=1, max_size=6)\n    await p.execute(\"TRUNCATE users_saas_accounts, ingested_assets, processing_jobs, fourthwall_products, \"\n                    \"agent_sync_logs RESTART IDENTITY CASCADE\")\n    yield p\n    await p.close()\n\n\n@pytest_asyncio.fixture\nasync def account(pool: asyncpg.Pool) -> int:\n    return await pool.fetchval(\n        \"\"\"INSERT INTO users_saas_accounts (display_name, tenant_token_hash, fourthwall_api_user, fourthwall_api_secret_enc)\n           VALUES ('Test shop', repeat('a',64), 'apiuser', pgp_sym_encrypt('apisecret', $1)) RETURNING id\"\"\", CRED_KEY)\n\n\n@pytest.fixture\ndef make_asset(settings: Settings, pool: asyncpg.Pool, account: int) -> Callable[..., Any]:\n    from pod_pipeline.ingest import scan_inbox\n\n    async def _make(name: str = \"Cool_Design.png\", size: tuple[int, int] = (200, 160), account_id: int | None = None) -> int:\n        acct = account_id or account\n        d = settings.inbox / str(acct)\n        d.mkdir(parents=True, exist_ok=True)\n        Image.new(\"RGBA\", size, (255, 0, 0, 255)).save(d / name, \"PNG\")\n        await scan_inbox(settings, pool)\n        return await pool.fetchval(\"SELECT id FROM ingested_assets WHERE source_path=$1\", str(d / name))\n\n    return _make\n\n\nclass FakeFourthwall:\n    \"\"\"In-memory Fourthwall: api transport (Fourthwall host) + gcs transport (storage host), with call recording.\"\"\"\n\n    def __init__(self) -> None:\n        self.calls: list[tuple[str, str]] = []\n        self.gcs_puts: list[dict[str, Any]] = []\n        self.auth_headers: list[str] = []\n        self.reject_media_type = False\n        self.fail_create_with: int | None = None\n        self.products: dict[str, dict[str, Any]] = {}\n        self._n = 0\n        self.api = httpx.MockTransport(self._api)\n        self.gcs = httpx.MockTransport(self._gcs)\n\n    def count(self, method: str, path_prefix: str) -> int:\n        return sum(1 for m, p in self.calls if m == method and p.startswith(path_prefix))\n\n    def _api(self, req: httpx.Request) -> httpx.Response:\n        path, method = req.url.path, req.method\n        self.calls.append((method, path))\n        self.auth_headers.append(req.headers.get(\"authorization\", \"\"))\n        body = json.loads(req.content) if req.content else None\n        if path == \"/open-api/v1.0/media/upload-url\":\n            if self.reject_media_type:\n                return httpx.Response(406, json={\"code\": \"UNSUPPORTED_MEDIA_TYPE_ERROR\", \"mediaType\": body[\"contentType\"],\n                                                 \"supportedMediaTypes\": [\"image/png\", \"image/jpeg\"]})\n            assert body[\"size\"] > 0 and body[\"fileName\"] and body[\"contentType\"]\n            self._n += 1\n            return httpx.Response(201, json={\"uploadUrl\": f\"https://storage.fake.test/up/{self._n}?sig=abc\",\n                                             \"fileUrl\": f\"https://cdn.fake.test/media/{self._n}/{body['fileName']}\"})\n        if path == \"/open-api/v1.0/media/images\":\n            return httpx.Response(200, json={\"id\": f\"img_{self._n}\", \"uri\": body[\"fileUrl\"],\n                                             \"width\": body[\"width\"], \"height\": body[\"height\"]})\n        if path == \"/open-api/v1.0/products\" and method == \"POST\":\n            if self.fail_create_with:\n                return httpx.Response(self.fail_create_with, json={\"code\": \"SOMETHING_BROKE\"})\n            assert body[\"type\"] == \"design\" and body[\"regions\"][0][\"imageId\"].startswith(\"img_\")\n            pid = f\"off_{len(self.products) + 1}\"\n            self.products[pid] = {\"id\": pid, \"name\": body[\"name\"], \"slug\": body[\"name\"].lower().replace(\" \", \"-\"),\n                                  \"access\": {\"type\": \"HIDDEN\"}, \"state\": {\"type\": \"AVAILABLE\"},\n                                  \"variants\": [{\"id\": \"v1\", \"sku\": f\"SKU-{pid}-S\"}, {\"id\": \"v2\", \"sku\": f\"SKU-{pid}-M\"}],\n                                  \"images\": [{\"id\": \"i\"}], \"updatedAt\": \"2026-11-04T10:00:00Z\"}\n            return httpx.Response(201, json={\"productId\": pid, \"customizationId\": \"cus_1\", \"images\": []})\n        m = re.fullmatch(r\"/open-api/v1.0/products/([^/]+)(/state)?\", path)\n        if m and m.group(1) in self.products:\n            prod = self.products[m.group(1)]\n            if method == \"GET\":\n                return httpx.Response(200, json=prod)\n            if method == \"PUT\" and m.group(2):\n                prod[\"access\"] = {\"type\": body[\"state\"]}\n                return httpx.Response(200, json=prod)\n        return httpx.Response(404, json={\"code\": \"NOT_FOUND\"})\n\n    def _gcs(self, req: httpx.Request) -> httpx.Response:\n        self.gcs_puts.append({\"headers\": dict(req.headers), \"len\": len(req.content), \"url\": str(req.url)})\n        return httpx.Response(200)\n\n\n@pytest.fixture\ndef fake_fw(monkeypatch: pytest.MonkeyPatch) -> FakeFourthwall:\n    fw = FakeFourthwall()\n\n    class Patched(FourthwallClient):\n        def __init__(self, base_url: str, user: str, secret: str, **kw: Any) -> None:\n            super().__init__(base_url, user, secret, transport=fw.api, gcs_transport=fw.gcs, **kw)\n\n    monkeypatch.setattr(orchestrator, \"FourthwallClient\", Patched)\n    from pod_pipeline import mcp_server\n    monkeypatch.setattr(mcp_server, \"FourthwallClient\", Patched)\n    return fw\n\n\n@pytest.fixture\ndef with_state(settings: Settings, pool: asyncpg.Pool, monkeypatch: pytest.MonkeyPatch):\n    \"\"\"Point the MCP module's lazy state at the test settings/pool.\"\"\"\n    from pod_pipeline import mcp_server\n    monkeypatch.setattr(mcp_server.STATE, \"settings\", settings)\n    monkeypatch.setattr(mcp_server.STATE, \"pool\", pool)\n    monkeypatch.setattr(mcp_server.STATE, \"lock\", None)\n    return mcp_server\n\n\ndef replace(settings: Settings, **kw: Any) -> Settings:\n    return dataclasses.replace(settings, **kw)\n";
var craft_stub_default = "\"\"\"Stand-in for the five Craft CLIs. Invoked through launcher scripts named photocraft-cli, vectorcraft-cli, ...\nIt checks that the orchestrator passes the flags the spec requires, then writes plausible output files.\n\nBehaviour switches (environment variables):\n  STUB_VECTOR_EXIT=<n>     vectorcraft-cli exits n after printing an error\n  STUB_SLEEP=<seconds>     sleep before doing anything (timeout tests); also leaves a background child behind\n  STUB_SPAM_MB=<n>         print ~n MB of progress noise, a few error lines mixed in\n  STUB_FLAKY_MARK=<path>   first call exits 137 (OOM-style) and creates the marker; later calls succeed\n  STUB_KNIT=ok|antialias|rgba32   what kind of BMP designcraft stitch_matrix writes\n\"\"\"\nimport os\nimport sys\nimport time\nfrom pathlib import Path\n\nfrom PIL import Image, ImageDraw\n\nPDF = b\"%PDF-1.4\\n1 0 obj<<>>endobj\\ntrailer<<>>\\n%%EOF\\n\"\n\n\ndef args_to_dict(argv):\n    out, i = {}, 0\n    while i < len(argv):\n        tok = argv[i]\n        if tok.startswith(\"--\"):\n            if i + 1 < len(argv) and not argv[i + 1].startswith(\"--\"):\n                out.setdefault(tok, []).append(argv[i + 1])\n                i += 2\n                continue\n            out.setdefault(tok, []).append(True)\n        i += 1\n    return out\n\n\ndef need(a, flag, value=None):\n    if flag not in a:\n        print(f\"ERROR: stub requires {flag}\", file=sys.stderr)\n        sys.exit(64)\n    if value is not None and a[flag][0] != value:\n        print(f\"ERROR: stub requires {flag} {value}, got {a[flag][0]}\", file=sys.stderr)\n        sys.exit(64)\n    return a[flag][0]\n\n\ndef art(path, size=(120, 90), alpha=True):\n    im = Image.new(\"RGBA\", size, (0, 0, 0, 0))\n    ImageDraw.Draw(im).ellipse((10, 10, size[0] - 10, size[1] - 10), fill=(200, 30, 30, 255))\n    path = Path(path)\n    path.parent.mkdir(parents=True, exist_ok=True)\n    im.save(path, \"PNG\")\n\n\ndef main():\n    tool = os.path.basename(sys.argv[0])\n    a = args_to_dict(sys.argv[1:])\n    if os.environ.get(\"STUB_SLEEP\"):\n        os.system(\"sleep 120 &\")                      # grandchild that must be killed with the group\n        time.sleep(float(os.environ[\"STUB_SLEEP\"]))\n    mark = os.environ.get(\"STUB_FLAKY_MARK\")\n    if mark and not os.path.exists(mark):\n        Path(mark).write_text(\"x\")\n        print(\"ERROR: simulated OOM kill\", file=sys.stderr)\n        sys.exit(137)\n    mb = float(os.environ.get(\"STUB_SPAM_MB\", \"0\"))\n    if mb:\n        line = \"progress tile 000000 of 999999 ........................................................\\n\"\n        for i in range(int(mb * 1024 * 1024 / len(line))):\n            sys.stdout.write(line.replace(\"000000\", f\"{i:06d}\"))\n            if i % 50000 == 0:\n                sys.stdout.write(f\"WARNING: slow tile {i}\\n\")\n\n    if tool == \"vectorcraft-cli\":\n        assert sys.argv[1] == \"trace\", \"vectorcraft-cli needs the 'trace' subcommand\"\n        code = int(os.environ.get(\"STUB_VECTOR_EXIT\", \"0\"))\n        if code:\n            print(\"ERROR: trace failed: path simplification diverged\", file=sys.stderr)\n            sys.exit(code)\n        need(a, \"--input\")\n        Path(need(a, \"--svg-out\")).write_text(\"<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10'/>\")\n        Path(need(a, \"--pdf-out\")).write_bytes(PDF)\n    elif tool == \"photocraft-cli\":\n        out_dir = Path(need(a, \"--out-dir\"))\n        need(a, \"--input\")\n        if a.get(\"--trim-alpha\", [\"false\"])[0] == \"true\":\n            need(a, \"--target-dpi\", \"300\")\n            need(a, \"--color-profile\", \"srgb\")\n            need(a, \"--dimensions\", \"14x16in\")\n            art(out_dir / \"trimmed.png\")\n        else:\n            need(a, \"--target-dpi\")\n            art(out_dir / \"raster_600dpi.png\")\n    elif tool == \"effectcraft-cli\":\n        out = Path(need(a, \"--output\"))\n        out.parent.mkdir(parents=True, exist_ok=True)\n        if \"--filter\" in a:\n            need(a, \"--filter\", \"vintage_screen_300\")\n            art(out)\n        else:\n            need(a, \"--cylinder-taper\")\n            need(a, \"--input\")\n            out.write_bytes(PDF)\n    elif tool == \"designcraft-cli\":\n        out = Path(need(a, \"--output\"))\n        out.parent.mkdir(parents=True, exist_ok=True)\n        if a.get(\"--mode\", [\"\"])[0] == \"stitch_matrix\":\n            need(a, \"--palette-limit\")\n            cols, rows = [int(x) for x in need(a, \"--grid-scale\").lower().split(\"x\")]\n            mode = os.environ.get(\"STUB_KNIT\", \"ok\")\n            if mode == \"ok\":\n                im = Image.new(\"P\", (cols, rows), 0)\n                im.putpalette([200, 30, 30, 20, 20, 160, 240, 240, 240, 10, 10, 10] + [0] * (768 - 12))\n                ImageDraw.Draw(im).rectangle((2, 2, cols // 2, rows // 2), fill=1)\n                ImageDraw.Draw(im).rectangle((cols // 2, rows // 2, cols - 3, rows - 3), fill=2)\n                im.save(out, \"BMP\")\n            elif mode == \"antialias\":\n                im = Image.new(\"RGB\", (cols, rows))\n                for x in range(cols):\n                    for y in range(rows):\n                        im.putpixel((x, y), ((x * 7) % 256, (y * 5) % 256, (x + y) % 256))\n                im.save(out, \"BMP\")\n            else:\n                Image.new(\"RGBA\", (cols, rows), (10, 10, 10, 128)).save(out, \"BMP\")\n        elif a.get(\"--mode\", [\"\"])[0] == \"wrap_tile\":\n            need(a, \"--bleed\", \"0.25\")\n            need(a, \"--input\")\n            out.write_bytes(PDF)\n        elif \"--template\" in a:\n            need(a, \"--layer\")\n            need(a, \"--embed\")\n            out.write_bytes(PDF)\n        else:\n            need(a, \"--input\")\n            need(a, \"--embed\")\n            out.write_bytes(PDF)\n    elif tool == \"filmcraft-cli\":\n        need(a, \"--template\")\n        need(a, \"--render-preset\")\n        Path(need(a, \"--output\")).write_bytes(b\"\\x00\\x00\\x00\\x18ftypmp42\\x00\\x00\\x00\\x00mp42isom\" + b\"\\x00\" * 64)\n    else:\n        print(f\"unknown tool {tool}\", file=sys.stderr)\n        sys.exit(65)\n\n\nif __name__ == \"__main__\":\n    main()\n";
var _dockerignore_raw_default = ".venv\nsandbox\nbuild\nlogs\ndata\n**/__pycache__\n*.pyc\n";
var SOURCE_GROUPS = [
	{
		id: "package",
		label: "Package"
	},
	{
		id: "sql",
		label: "Schema"
	},
	{
		id: "config",
		label: "Config"
	},
	{
		id: "deploy",
		label: "Deploy"
	},
	{
		id: "tests",
		label: "Tests"
	}
];
var SOURCES = [
	{
		path: "pod_pipeline/__init__.py",
		group: "package",
		source: __init___default
	},
	{
		path: "pod_pipeline/config.py",
		group: "package",
		source: config_default
	},
	{
		path: "pod_pipeline/db.py",
		group: "package",
		source: db_default
	},
	{
		path: "pod_pipeline/ingest.py",
		group: "package",
		source: ingest_default
	},
	{
		path: "pod_pipeline/routes.py",
		group: "package",
		source: routes_default
	},
	{
		path: "pod_pipeline/runner.py",
		group: "package",
		source: runner_default
	},
	{
		path: "pod_pipeline/validators.py",
		group: "package",
		source: validators_default
	},
	{
		path: "pod_pipeline/logfilter.py",
		group: "package",
		source: logfilter_default
	},
	{
		path: "pod_pipeline/orchestrator.py",
		group: "package",
		source: orchestrator_default
	},
	{
		path: "pod_pipeline/fourthwall.py",
		group: "package",
		source: fourthwall_default
	},
	{
		path: "pod_pipeline/worker.py",
		group: "package",
		source: worker_default
	},
	{
		path: "pod_pipeline/mcp_server.py",
		group: "package",
		source: mcp_server_default
	},
	{
		path: "sql/schema.sql",
		group: "sql",
		source: schema_default
	},
	{
		path: "config/products.json",
		group: "config",
		source: products_default
	},
	{
		path: "config/pipeline.env.example",
		group: "config",
		source: pipeline_env_default
	},
	{
		path: "requirements.txt",
		group: "config",
		source: requirements_default
	},
	{
		path: "deploy/setup-pipeline.sh",
		group: "deploy",
		source: setup_pipeline_default
	},
	{
		path: "deploy/compose.yml",
		group: "deploy",
		source: compose_default
	},
	{
		path: "deploy/Dockerfile",
		group: "deploy",
		source: Dockerfile_raw_default
	},
	{
		path: "deploy/mcp-stdio.mjs",
		group: "deploy",
		source: mcp_stdio_default
	},
	{
		path: "deploy/systemd/pod-mcp.service",
		group: "deploy",
		source: pod_mcp_default
	},
	{
		path: "deploy/systemd/pod-worker.service",
		group: "deploy",
		source: pod_worker_default$1
	},
	{
		path: "deploy/systemd/pod-worker.timer",
		group: "deploy",
		source: pod_worker_default
	},
	{
		path: "deploy/craft-bin/vectorcraft-cli",
		group: "deploy",
		source: vectorcraft_cli_raw_default
	},
	{
		path: "deploy/craft-bin/photocraft-cli",
		group: "deploy",
		source: photocraft_cli_raw_default
	},
	{
		path: "deploy/craft-bin/designcraft-cli",
		group: "deploy",
		source: designcraft_cli_raw_default
	},
	{
		path: "deploy/craft-bin/effectcraft-cli",
		group: "deploy",
		source: effectcraft_cli_raw_default
	},
	{
		path: "deploy/craft-bin/filmcraft-cli",
		group: "deploy",
		source: filmcraft_cli_raw_default
	},
	{
		path: ".dockerignore",
		group: "deploy",
		source: _dockerignore_raw_default
	},
	{
		path: "tests/conftest.py",
		group: "tests",
		source: conftest_default
	},
	{
		path: "tests/stubs/craft_stub.py",
		group: "tests",
		source: craft_stub_default
	}
];
function sourceByPath(path) {
	const found = SOURCES.find((file) => file.path === path);
	if (!found) throw new Error(path);
	return found;
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		try {
			const area = document.createElement("textarea");
			area.value = text;
			area.setAttribute("readonly", "");
			document.body.appendChild(area);
			area.select();
			const ok = document.execCommand("copy");
			area.remove();
			return ok;
		} catch {
			return false;
		}
	}
}
function downloadText(filename, text) {
	const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
function CopyButton({ text, label = "Copy" }) {
	const [done, setDone] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "inline-flex h-11 items-center gap-2 border border-fg/15 px-3 text-sm text-fg transition-colors duration-150 hover:border-brass hover:text-brass",
		onClick: () => {
			copyText(text).then((ok) => {
				if (!ok) return;
				setDone(true);
				window.setTimeout(() => setDone(false), 1400);
			});
		},
		children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: "size-4",
			"aria-hidden": "true"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
			className: "size-4",
			"aria-hidden": "true"
		}), done ? "Copied" : label]
	});
}
function DownloadButton({ filename, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "inline-flex h-11 items-center gap-2 border border-fg/15 px-3 text-sm text-fg transition-colors duration-150 hover:border-brass hover:text-brass",
		onClick: () => downloadText(filename, text),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
			className: "size-4",
			"aria-hidden": "true"
		}), "Download"]
	});
}
var STEPS = [
	"Place this tree at /opt/pod-pipeline on a Debian or Ubuntu VPS.",
	"Edit config/products.json. fourthwall_template_id comes from python -m pod_pipeline.worker --list-templates. knit_grid must be the factory COLSxROWS, or the BMP validator rejects the file.",
	"Run deploy/setup-pipeline.sh as root. It installs ImageMagick, Potrace, Ghostscript, ffmpeg, Docker, and a Postgres 16 container bound to 127.0.0.1:5432.",
	"The script writes config/pipeline.env with a database password and POD_CREDENTIAL_KEY, applies sql/schema.sql, and enables pod-mcp plus a one-minute drain timer.",
	"Insert a users_saas_accounts row. The Fourthwall secret is pgp_sym_encrypt'd with POD_CREDENTIAL_KEY. The comment at the top of schema.sql is the statement.",
	"Drop settled files into data/inbox/<account_id>/. The drain scans, or the agent calls trigger_pipeline_job."
];
function PlaybookView({ onOpen }) {
	const setup = sourceByPath("deploy/setup-pipeline.sh");
	const schema = sourceByPath("sql/schema.sql");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: "VPS playbook"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-3xl text-sm text-pretty text-muted",
				children: "The Python package is the pipeline. This script is the machine around it. Re-running the script keeps an existing env file and any Craft binary already in bin/."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-3",
				children: STEPS.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[2rem_1fr] gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-brass tabular-nums",
						children: String(index + 1).padStart(2, "0")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty",
						children: step
					})]
				}, step))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 border border-fg/15 px-3 text-sm hover:border-brass",
						onClick: () => onOpen("pod_pipeline/mcp_server.py"),
						children: "MCP server"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 border border-fg/15 px-3 text-sm hover:border-brass",
						onClick: () => onOpen("config/products.json"),
						children: "products.json"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 border border-fg/15 px-3 text-sm hover:border-brass",
						onClick: () => onOpen("deploy/compose.yml"),
						children: "compose.yml"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
				title: setup.path,
				source: setup.source
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeBlock, {
				title: schema.path,
				source: schema.source
			})
		]
	});
}
function CodeBlock({ title, source }) {
	const filename = title.split("/").pop() ?? title;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-mono text-sm",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: source }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
				filename,
				text: source
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
		className: "mt-2 max-h-screen overflow-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg",
		children: source
	})] });
}
function RoutesView({ family, onFamily }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: "Fourthwall routes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-3xl text-sm text-pretty text-muted",
				children: "routes.py is the only file that knows Craft flags. A flag change is one tuple, not a hunt through the orchestrator."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children: FAMILIES.map((item) => {
					const open = item.id === family;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border " + (open ? "border-brass" : "border-fg/10"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full flex-col gap-1 p-3 text-left md:flex-row md:items-baseline md:justify-between",
							"aria-expanded": open,
							onClick: () => onFamily(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-base font-medium",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: item.focus
							})]
						}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 border-t border-fg/10 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: item.blanks
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: [
										"trace ",
										item.traceExtra ? `+ ${item.traceExtra}` : "with no extra flags",
										" · upload ",
										item.upload
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "flex flex-col gap-3",
									children: item.steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono text-xs text-brass",
													children: String(index + 1).padStart(2, "0")
												}),
												" ",
												step.name,
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [" · ", step.module]
												}),
												step.validator ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [" · ", step.validator]
												}) : null,
												step.timeout ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [" · timeout ", step.timeout]
												}) : null
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 overflow-x-auto font-mono text-xs break-all text-fg md:break-normal",
											children: step.command
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-mono text-xs text-muted",
											children: step.output
										})
									] }, step.name))
								}),
								item.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-pretty text-muted",
									children: item.note
								}) : null
							]
						}) : null]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-base font-medium",
				children: "Assumptions the route file already marks"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-2",
				children: ASSUMPTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-l border-brass pl-3 text-sm text-pretty text-muted",
					children: item
				}, item))
			})] })
		]
	});
}
var LIMITS = [
	{
		name: "memory",
		value: "2g, and memory-swap equal to memory so the container cannot swap",
		where: "POD_DOCKER_MEMORY"
	},
	{
		name: "cpu",
		value: "1.5 cpus, cpu-shares 256 against a default 1024 web process",
		where: "POD_DOCKER_CPUS"
	},
	{
		name: "pids",
		value: "256",
		where: "runner.build_command"
	},
	{
		name: "network",
		value: "none. Craft cannot reach Fourthwall or the agent.",
		where: "--network none"
	},
	{
		name: "privileges",
		value: "cap-drop ALL, no-new-privileges, read-only root",
		where: "docker run"
	},
	{
		name: "tmp",
		value: "tmpfs /tmp, 512m, HOME=/tmp",
		where: "docker run"
	},
	{
		name: "mounts",
		value: "only that run's sandbox and build directories",
		where: "-v work -v build"
	},
	{
		name: "native",
		value: "nice -n 10 and ionice idle class. nice is not applied to the docker client.",
		where: "POD_NICE_LEVEL"
	},
	{
		name: "logs",
		value: "streamed. Disk cap 5 MiB. Agent digest 20 error lines, 12 tail lines, 2000 characters.",
		where: "logfilter.py"
	},
	{
		name: "postgres",
		value: "error_digest sliced to 8000 characters. Sync payloads capped at 32 KiB.",
		where: "db.py · schema.sql"
	}
];
var FAULTS = [
	{
		name: "trace exit 1",
		value: "Tier-1 raster fallback. trace_state becomes raster_fallback. The run continues."
	},
	{
		name: "other trace exit",
		value: "trace_state trace_failed. The run fails. No second tracer."
	},
	{
		name: "exit -9, -15, 137, 143, 75",
		value: "Transient. Retried up to POD max_attempts, default 2."
	},
	{
		name: "step timeout",
		value: "Process group SIGTERM, then SIGKILL. Docker container is killed by name. Transient."
	},
	{
		name: "validator reject",
		value: "Not retried. The same binary would write the same file."
	},
	{
		name: "flush timeout",
		value: "Output never settled for two polls. The step fails."
	},
	{
		name: "sha256 mismatch",
		value: "Asset quarantined before any Craft process starts."
	},
	{
		name: "Fourthwall 406",
		value: "publish_state needs_manual_upload. The run itself succeeds."
	},
	{
		name: "create 5xx",
		value: "Not retried. A retry could duplicate the product."
	},
	{
		name: "429",
		value: "Up to three retries using Retry-After. Upload-url is also capped at 20 per minute."
	},
	{
		name: "worker vanished",
		value: "recover_stale_runs sees a dead pid and puts the orchestrator row back to queued."
	}
];
function SandboxView({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: "Sandbox and faults"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-3xl text-sm text-pretty text-muted",
				children: "Docker limits are what protect the web server. nice on the docker client would not reach processes the daemon starts."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-base font-medium",
				children: "Tree"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-2 overflow-x-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg",
				children: TREE
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-medium",
						children: "Docker wrap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: DOCKER_ARGV })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-2 overflow-x-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg",
					children: DOCKER_ARGV
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: ["Native mode, when POD_USE_DOCKER is off: ", NATIVE_ARGV]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-base font-medium",
				children: "Limits"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 border border-fg/10",
				children: LIMITS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-1 border-b border-fg/10 p-3 last:border-b-0 md:grid-cols-[8rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-brass",
						children: row.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm",
						children: [row.value, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-mono text-xs text-muted",
							children: row.where
						})]
					})]
				}, row.name))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-medium",
					children: "What happens when a step fails"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 border border-fg/10",
					children: FAULTS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-1 border-b border-fg/10 p-3 last:border-b-0 md:grid-cols-[11rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-brass",
							children: row.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-pretty",
							children: row.value
						})]
					}, row.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 h-11 border border-fg/15 px-3 text-sm text-fg hover:border-brass",
					onClick: () => onOpen("pod_pipeline/runner.py"),
					children: "Open runner.py"
				})
			] })
		]
	});
}
function SourcesView({ file, onFile }) {
	const active = SOURCES.find((item) => item.path === file) ?? SOURCES[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[16rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs tracking-wide text-muted",
					children: "Source"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-11 w-full border border-fg/15 bg-bg px-2 text-sm text-fg",
					value: active.path,
					onChange: (event) => onFile(event.target.value),
					children: SOURCE_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
						label: group.label,
						children: SOURCES.filter((item) => item.group === group.id).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.path,
							children: item.path
						}, item.path))
					}, group.id))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden md:block",
				children: SOURCE_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-xs tracking-wide text-muted",
						children: group.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: SOURCES.filter((item) => item.group === group.id).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "w-full truncate px-2 py-2 text-left font-mono text-xs " + (item.path === active.path ? "bg-fg/10 text-brass" : "text-fg hover:bg-fg/5"),
						onClick: () => onFile(item.path),
						children: item.path.split("/").pop()
					}) }, item.path)) })]
				}, group.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcePane, { file: active })]
	});
}
function SourcePane({ file }) {
	const lines = file.source.split("\n").length;
	const filename = file.path.split("/").pop() ?? file.path;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-mono text-sm",
				children: file.path
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-xs text-muted tabular-nums",
				children: [lines, " lines"]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { text: file.source }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadButton, {
					filename,
					text: file.source
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-2 max-h-screen overflow-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg",
			children: file.source
		})]
	});
}
var NAV = [
	{
		id: "board",
		label: "Board"
	},
	{
		id: "routes",
		label: "Routes"
	},
	{
		id: "sandbox",
		label: "Sandbox"
	},
	{
		id: "playbook",
		label: "Playbook"
	},
	{
		id: "sources",
		label: "Sources"
	}
];
function Console() {
	const [section, setSection] = (0, import_react.useState)("board");
	const [family, setFamily] = (0, import_react.useState)("apparel");
	const [traceFails, setTraceFails] = (0, import_react.useState)(false);
	const [docker, setDocker] = (0, import_react.useState)(true);
	const [file, setFile] = (0, import_react.useState)("pod_pipeline/routes.py");
	function openFile(path) {
		setFile(path);
		setSection("sources");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between gap-4 border-b border-fg/10 px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/favicon.svg",
					alt: "",
					width: 32,
					height: 32,
					className: "size-8"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-brass",
					children: "DEERFLOW"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-lg font-medium leading-tight",
					children: "Forge"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden text-right sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "pod_pipeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted",
					children: "Fourthwall Open API · DeepSeek V4.1-Flash"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex gap-2 overflow-x-auto border-b border-fg/10 p-3 md:w-44 md:shrink-0 md:flex-col md:border-r md:border-b-0",
				"aria-label": "Sections",
				children: NAV.map((item) => {
					const selected = item.id === section;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-current": selected ? "page" : void 0,
						className: "h-11 shrink-0 border-l-2 px-3 text-left text-sm " + (selected ? "border-brass bg-fg/10 text-fg" : "border-transparent text-muted hover:text-fg"),
						onClick: () => setSection(item.id),
						children: item.label
					}, item.id);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "min-w-0 flex-1 p-4",
				children: [
					section === "board" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
						family,
						onFamily: setFamily,
						traceFails,
						onTraceFails: setTraceFails,
						docker,
						onDocker: setDocker
					}) : null,
					section === "routes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoutesView, {
						family,
						onFamily: setFamily
					}) : null,
					section === "sandbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SandboxView, { onOpen: openFile }) : null,
					section === "playbook" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaybookView, { onOpen: openFile }) : null,
					section === "sources" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcesView, {
						file,
						onFile: setFile
					}) : null
				]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Console, {});
}
//#endregion
export { Home as component };
