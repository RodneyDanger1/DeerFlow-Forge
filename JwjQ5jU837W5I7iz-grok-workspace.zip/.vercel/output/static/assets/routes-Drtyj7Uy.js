import{i as e,n as t,r as n,t as r}from"./index-9xx5d2nh.js";var i=r(`check`,[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]),a=r(`copy`,[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]),o=r(`download`,[[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`polyline`,{points:`7 10 12 15 17 10`,key:`2ggqvy`}],[`line`,{x1:`12`,x2:`12`,y1:`15`,y2:`3`,key:`1vk2je`}]]),s=r(`play`,[[`polygon`,{points:`6 3 20 12 6 21 6 3`,key:`1oa8hb`}]]),c=e(n(),1),l=[{id:`apparel`,name:`Apparel`,blanks:`Shaka Wear tees, Shaka Wear hoodies, Bella+Canvas shorts`,focus:`PhotoCraft and EffectCraft`,upload:`{build}/apparel_final.png`,note:``,traceExtra:``,steps:[{name:`photocraft_trim`,module:`photocraft`,command:`photocraft-cli --input {art} --trim-alpha true --target-dpi 300 --color-profile srgb --dimensions 14x16in --out-dir {work}/apparel/`,output:`{work}/apparel/trimmed.png`,validator:null,timeout:null},{name:`effectcraft_distress`,module:`effectcraft`,command:`effectcraft-cli --input {work}/apparel/trimmed.png --filter vintage_screen_300 --output {build}/apparel_final.png`,output:`{build}/apparel_final.png`,validator:`png_with_alpha`,timeout:null}]},{id:`knitwear`,name:`Knitwear`,blanks:`Knit crewnecks, cardigans, vests`,focus:`DesignCraft and VectorCraft`,upload:`{build}/knitwear_final.bmp`,note:`A BMP stitch grid may be refused by the image library. The run then ends needs_manual_upload and still counts as processed.`,traceExtra:`--palette-limit {cfg[palette_limit]}`,steps:[{name:`designcraft_stitch_matrix`,module:`designcraft`,command:`designcraft-cli --mode stitch_matrix --input {art} --palette-limit {cfg[palette_limit]} --grid-scale {cfg[knit_grid]} --output {build}/knitwear_final.bmp`,output:`{build}/knitwear_final.bmp`,validator:`knit_bmp`,timeout:null}]},{id:`accessories`,name:`Accessories`,blanks:`AS Colour caps, crossbody bags, Under Armour backpacks`,focus:`DesignCraft`,upload:`{build}/accessory_final.pdf`,note:`Safe-zone bounding boxes and kerning live inside DesignCraft. The orchestrator only checks that the PDF has a header and a trailer.`,traceExtra:``,steps:[{name:`designcraft_template`,module:`designcraft`,command:`designcraft-cli --template {cfg[template]} --layer artwork --embed {art} --layer care_label --text "{cfg[care_text]}" --output {build}/accessory_final.pdf`,output:`{build}/accessory_final.pdf`,validator:`pdf`,timeout:null}]},{id:`odd_3d`,name:`Odd / 3D`,blanks:`Sublimation socks, Arctic Zone tumblers`,focus:`DesignCraft and EffectCraft`,upload:`{build}/odd_final.pdf`,note:`Bleed is 0.25 in. Cylinder taper is a separate EffectCraft step so a bad wrap never reaches the tumbler deform.`,traceExtra:``,steps:[{name:`designcraft_wrap_tile`,module:`designcraft`,command:`designcraft-cli --mode wrap_tile --bleed {cfg[bleed_in]} --input {art} --output {work}/odd/tiled.pdf`,output:`{work}/odd/tiled.pdf`,validator:`pdf`,timeout:null},{name:`effectcraft_cylinder_taper`,module:`effectcraft`,command:`effectcraft-cli --cylinder-taper --input {work}/odd/tiled.pdf --output {build}/odd_final.pdf`,output:`{build}/odd_final.pdf`,validator:`pdf`,timeout:null}]},{id:`stationery`,name:`Stationery`,blanks:`Karst bound notebooks`,focus:`DesignCraft and FilmCraft`,upload:`{build}/print_ready_stationery.pdf`,note:`The reel is a marketing file, not the Fourthwall upload. Packing slips are not built on this route — a cover exists before any order does.`,traceExtra:``,steps:[{name:`designcraft_cover`,module:`designcraft`,command:`designcraft-cli --input {cfg[cover_template]} --embed {art} --output {build}/print_ready_stationery.pdf`,output:`{build}/print_ready_stationery.pdf`,validator:`pdf`,timeout:null},{name:`filmcraft_reel`,module:`filmcraft`,command:`filmcraft-cli --template {cfg[reel_template]} --asset-layer product_front --input {build}/print_ready_stationery.pdf --render-preset {cfg[reel_preset]} --output {build}/promo_reel.mp4`,output:`{build}/promo_reel.mp4`,validator:`mp4`,timeout:`1800s`}]}],u=[`The spec never gave a vectorcraft-cli line. routes.py owns the contract: trace --input --svg-out --pdf-out. Knitwear adds --palette-limit.`,`Exit code 1 on that trace is the only automatic fallback. Any other trace exit fails the run.`,`The raster fallback expects a PNG inside --out-dir. DPI comes from POD_FALLBACK_RASTER_DPI, default 600.`,`stitch_matrix had no input flag in the spec. The route adds --input.`,`The stationery cover adds --embed and drops --variable-data order_id. There is no order yet.`,`Vendor Craft binaries are not in this tree. deploy/craft-bin exits 127 until they replace those files. tests/stubs/craft_stub.py is the contract double, not a production tool.`],d={palette_limit:`6`,knit_grid:`112x140`,template:`fourthwall_crossbody_v1`,care_text:`100% Polyester`,bleed_in:`0.25`,cover_template:`notebook_cover_template`,reel_template:`reel_promo_9_16`,reel_preset:`tiktok_1080p`,fallback_dpi:`600`},f=`8f3c1a9b-4e20-4c11-9a77-0b1d2e3f4a5b`,p=`/opt/pod-pipeline`,m=`/opt/pod-pipeline
├── bin/                         Craft CLIs, first on PATH
├── config/pipeline.env          systemd EnvironmentFile
├── config/products.json         template ids, knit grid, care text
├── data/inbox/<account_id>/     scan_inbox, after the file settles
├── sandbox/<run_id>/            scratch; deleted when the run succeeds
├── build/<run_id>/              fsynced finals, kept
├── logs/jobs/<run_id>/          one capped log per attempt
├── sql/schema.sql
├── pod_pipeline/                orchestrator, MCP, Fourthwall client
├── tests/stubs/craft_stub.py    test double only
└── deploy/                      setup-pipeline.sh, compose, systemd`,h=`docker run --rm --init --name pod-<id> \\
  --memory 2g --memory-swap 2g \\
  --cpus 1.5 --cpu-shares 256 \\
  --pids-limit 256 --network none \\
  --cap-drop ALL --security-opt no-new-privileges \\
  --read-only --tmpfs /tmp:rw,size=512m -e HOME=/tmp \\
  --user <uid>:<gid> \\
  -v <work>:<work>:rw -v <build>:<build>:rw -w <work> \\
  pod-craft-runner:latest \\
  <craft argv>`,ee=`nice -n 10 ionice -c 3 <craft argv>`;function g(e,t){return e.replace(/\{cfg\[(\w+)\]\}|\{(\w+)\}/g,(e,n,r)=>n?t[n]??e:r?t[r]??e:e)}function _(e,t){return e===`db`?`postgres`:e===`net`?`host network`:t?`docker 2g · 1.5 cpu · net none`:`nice -n 10 · ionice idle`}function te(e){let t=l.find(t=>t.id===e);if(!t)throw Error(e);return t}function ne(e,t,n){let r=te(e),i=`${p}/sandbox/${f}`,a=`${p}/build/${f}`,o=`${i}/input.png`,s=t?`${i}/raster/raster_600dpi.png`:`${i}/traced.svg`,c={...d,src:o,art:s,work:i,build:a,run_id:f,fallback_dpi:d.fallback_dpi},l=[],u=e=>l.push(e);u({id:`claim`,module:`db`,title:`claim_run`,command:`UPDATE processing_jobs SET status=running, pid, started_at WHERE status=queued FOR UPDATE SKIP LOCKED`,sandbox:_(`db`,n),note:`The MCP child and the minute drain cannot take the same run.`,result:`claimed orchestrator row`,failed:!1}),u({id:`stage`,module:`ingest`,title:`stage_input`,command:`sha256 copy ${o}`,sandbox:_(`db`,n),note:`A hash mismatch quarantines the asset. Craft is not called.`,result:`sha256 matches ingested_assets`,failed:!1});let m=[`vectorcraft-cli trace`,`--input ${o}`,`--svg-out ${i}/traced.svg`,`--pdf-out ${i}/traced.pdf`];r.traceExtra&&m.push(g(r.traceExtra,c)),u({id:`trace`,module:`vectorcraft`,title:`vector_trace`,command:m.join(` `),sandbox:_(`craft`,n),note:`Tier 0. Only exit code 1 switches to the raster fallback.`,result:t?`exit 1 · ERROR: trace failed: path simplification diverged`:`exit 0 · fsync ${i}/traced.svg`,failed:t}),t&&u({id:`fallback`,module:`photocraft`,title:`raster_fallback`,command:g(`photocraft-cli --input {src} --trim-alpha false --target-dpi {fallback_dpi} --color-profile srgb --out-dir {work}/raster/`,c),sandbox:_(`craft`,n),note:`Tier 1. trace_state becomes raster_fallback. Later steps receive the PNG as {art}.`,result:`exit 0 · fsync ${i}/raster/raster_600dpi.png`,failed:!1});for(let e of r.steps){let t=[e.validator?`validator ${e.validator}`:`no validator`,`fsync file + directory`];e.timeout&&t.push(`timeout ${e.timeout}`),u({id:e.name,module:e.module,title:e.name,command:g(e.command,c),sandbox:_(`craft`,n),note:t.join(` · `),result:`exit 0 · fsync ${g(e.output,c)}`,failed:!1})}return u({id:`upload-url`,module:`fourthwall`,title:`media.upload_url`,command:`POST /open-api/v1.0/media/upload-url  ${g(r.upload,c)}`,sandbox:_(`net`,n),note:`Body is fileName, contentType, size. The client allows 20 of these per minute.`,result:`201 · uploadUrl + fileUrl`,failed:!1}),u({id:`gcs`,module:`fourthwall`,title:`media.gcs_put`,command:`PUT <uploadUrl>  Content-Type + x-goog-content-length-range`,sandbox:_(`net`,n),note:`No Fourthwall credentials on this hop. The storage host must not see the API secret.`,result:`200 · bytes match the signed size`,failed:!1}),u({id:`register`,module:`fourthwall`,title:`media.register`,command:`POST /open-api/v1.0/media/images  {fileUrl, width, height}`,sandbox:_(`net`,n),note:`The returned id is the imageId stored on fourthwall_products.media_id.`,result:`200 · imageId`,failed:!1}),u({id:`create`,module:`fourthwall`,title:`product.create`,command:`POST /open-api/v1.0/products  type=design  publishOnCreate=false`,sandbox:_(`net`,n),note:`Not retried on 5xx. An empty fourthwall_template_id fails the run before this call.`,result:`201 · productId · publish_state draft`,failed:!1}),u({id:`finish`,module:`db`,title:`finish_run`,command:`orchestrator row succeeded · asset processed · sandbox removed`,sandbox:_(`db`,n),note:t?`trace_state stays raster_fallback.`:`trace_state stays traced.`,result:`build/ kept · auto_publish is false, so the product stays draft`,failed:!1}),l}var v=t();function re({family:e,onFamily:t,traceFails:n,onTraceFails:r,docker:i,onDocker:a}){let o=ne(e,n,i),[u,d]=(0,c.useState)(-1),[f,p]=(0,c.useState)(!1);(0,c.useEffect)(()=>{d(-1),p(!1)},[e,n,i]),(0,c.useEffect)(()=>{if(!f)return;if(u>=o.length){p(!1);return}let e=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,t=window.setTimeout(()=>d(e=>e+1),e?0:320);return()=>window.clearTimeout(t)},[f,u,o.length]);let m=u>=o.length,h=f?`Running`:m?`Run again`:`Run route`;return(0,v.jsxs)(`div`,{className:`flex flex-col gap-4`,children:[(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`h2`,{className:`text-xl font-medium`,children:`One asset, one route`}),(0,v.jsx)(`p`,{className:`mt-1 max-w-3xl text-sm text-pretty text-muted`,children:`Commands are the tuples in routes.py, resolved against the example products.json. Fourthwall is the three-step upload in fourthwall.py, not a single POST to /media.`})]}),(0,v.jsx)(`div`,{className:`flex flex-wrap gap-2`,role:`radiogroup`,"aria-label":`Product route`,children:l.map(n=>{let r=n.id===e;return(0,v.jsx)(`button`,{type:`button`,role:`radio`,"aria-checked":r,className:`h-11 px-3 text-sm transition-colors duration-150 `+(r?`bg-brass text-bg`:`border border-fg/15 text-fg hover:border-brass`),onClick:()=>t(n.id),children:n.name},n.id)})}),(0,v.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,v.jsx)(y,{on:n,onClick:()=>r(!n),label:`Vector trace exits 1`}),(0,v.jsx)(y,{on:i,onClick:()=>a(!i),label:`Docker sandbox`}),(0,v.jsxs)(`button`,{type:`button`,disabled:f,className:`inline-flex h-11 items-center gap-2 bg-brass px-4 text-sm font-medium text-bg transition-opacity duration-150 disabled:opacity-60`,onClick:()=>{d(0),p(!0)},children:[(0,v.jsx)(s,{className:`size-4`,"aria-hidden":`true`}),h]})]}),(0,v.jsx)(`ol`,{className:`border border-fg/10`,"aria-live":`polite`,children:o.map((e,t)=>{let n=u<0?`pending`:t<u?`done`:t===u&&f?`running`:`pending`,r=n===`done`;return(0,v.jsxs)(`li`,{className:`grid gap-1 border-b border-fg/10 p-3 last:border-b-0 md:grid-cols-[3rem_1fr]`,children:[(0,v.jsx)(`span`,{className:`font-mono text-xs tabular-nums `+(n===`running`?`text-brass motion-safe:animate-pulse`:r&&!e.failed?`text-brass`:`text-muted`),children:String(t+1).padStart(2,`0`)}),(0,v.jsxs)(`div`,{className:`min-w-0`,children:[(0,v.jsxs)(`div`,{className:`flex flex-wrap items-baseline gap-x-3 gap-y-1`,children:[(0,v.jsx)(`span`,{className:`text-sm font-medium`,children:e.title}),(0,v.jsx)(`span`,{className:`font-mono text-xs text-muted`,children:e.module}),(0,v.jsx)(`span`,{className:`font-mono text-xs text-muted`,children:e.sandbox}),r&&e.failed?(0,v.jsx)(`span`,{className:`font-mono text-xs text-fg`,children:`FAIL`}):null]}),(0,v.jsx)(`p`,{className:`mt-1 overflow-x-auto font-mono text-xs break-all text-fg md:break-normal`,children:e.command}),(0,v.jsx)(`p`,{className:`mt-1 text-sm text-muted`,children:r?e.result:e.note})]})]},e.id)})}),m?(0,v.jsxs)(`p`,{className:`text-sm text-muted`,children:[n?`trace_state raster_fallback.`:`trace_state traced.`,` `,`publish_state stays draft unless the account has auto_publish.`]}):null]})}function y({on:e,onClick:t,label:n}){return(0,v.jsx)(`button`,{type:`button`,"aria-pressed":e,className:`h-11 border px-3 text-sm transition-colors duration-150 `+(e?`border-brass text-brass`:`border-fg/15 text-fg hover:border-brass`),onClick:t,children:n})}var ie=`"""DeerFlow print pipeline. Import submodules directly; this package has no side effects."""

__version__ = "1.0.0"
`,ae=`"""Runtime settings. Everything comes from environment variables (see .env.example)
plus an optional per-category config file at <root>/config/products.json."""
from __future__ import annotations

import json
import os
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


class ConfigError(RuntimeError):
    """Raised for missing or invalid configuration. Never retried."""


def _bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be an integer, got {raw!r}") from exc


@dataclass(frozen=True)
class Settings:
    root: Path
    database_url: str
    credential_key: str = ""
    fw_base_url: str = "https://api.fourthwall.com"
    fw_api_user: str | None = None
    fw_api_secret: str | None = None
    # --- sandboxing -------------------------------------------------------
    use_docker: bool = False
    docker_image: str = "pod-craft-runner:latest"
    docker_memory: str = "2g"
    docker_cpus: str = "1.5"
    docker_cpu_shares: int = 256          # relative weight vs. the web app (default 1024)
    nice_level: int = 10                  # native mode only; see BLUEPRINT.md section 6
    craft_prefix: tuple[str, ...] = ()    # e.g. ("xvfb-run", "-a") for GUI toolkits
    # --- execution --------------------------------------------------------
    max_concurrency: int = 2
    step_timeout_s: int = 900
    max_attempts: int = 2
    fallback_raster_dpi: int = 600
    max_log_bytes: int = 5 * 1024 * 1024
    flush_poll_s: float = 0.2
    inbox_settle_s: int = 5
    stuck_after_s: int = 1800
    # --- MCP server -------------------------------------------------------
    mcp_host: str = "127.0.0.1"
    mcp_port: int = 8765
    products: dict[str, dict[str, Any]] = field(default_factory=dict)

    # directory layout ------------------------------------------------------
    @property
    def inbox(self) -> Path:
        return self.root / "data" / "inbox"

    @property
    def sandbox(self) -> Path:
        return self.root / "sandbox"

    @property
    def build(self) -> Path:
        return self.root / "build"

    @property
    def job_logs(self) -> Path:
        return self.root / "logs" / "jobs"

    @property
    def bin_dir(self) -> Path:
        return self.root / "bin"

    @classmethod
    def from_env(cls) -> "Settings":
        root = Path(os.environ.get("POD_ROOT", "/opt/pod-pipeline")).resolve()
        db_url = os.environ.get("DATABASE_URL", "")
        if not db_url:
            raise ConfigError("DATABASE_URL is not set")
        products: dict[str, dict[str, Any]] = {}
        cfg_file = root / "config" / "products.json"
        if cfg_file.is_file():
            try:
                products = json.loads(cfg_file.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                raise ConfigError(f"{cfg_file} is not valid JSON: {exc}") from exc
        return cls(
            root=root,
            database_url=db_url,
            credential_key=os.environ.get("POD_CREDENTIAL_KEY", ""),
            fw_base_url=os.environ.get("FW_BASE_URL", "https://api.fourthwall.com").rstrip("/"),
            fw_api_user=os.environ.get("FW_API_USER") or None,
            fw_api_secret=os.environ.get("FW_API_SECRET") or None,
            use_docker=_bool("POD_USE_DOCKER", False),
            docker_image=os.environ.get("POD_DOCKER_IMAGE", "pod-craft-runner:latest"),
            docker_memory=os.environ.get("POD_DOCKER_MEMORY", "2g"),
            docker_cpus=os.environ.get("POD_DOCKER_CPUS", "1.5"),
            docker_cpu_shares=_int("POD_DOCKER_CPU_SHARES", 256),
            nice_level=_int("POD_NICE_LEVEL", 10),
            craft_prefix=tuple(shlex.split(os.environ.get("POD_CRAFT_PREFIX", ""))),
            max_concurrency=max(1, _int("POD_MAX_CONCURRENCY", 2)),
            step_timeout_s=_int("POD_STEP_TIMEOUT_S", 900),
            fallback_raster_dpi=_int("POD_FALLBACK_RASTER_DPI", 600),
            mcp_host=os.environ.get("POD_MCP_HOST", "127.0.0.1"),
            mcp_port=_int("POD_MCP_PORT", 8765),
            products=products,
        )
`,oe=`"""All SQL lives here. Parameterised queries only; no string-built SQL."""
from __future__ import annotations

import json
import os
import uuid
from typing import Any, Sequence

import asyncpg

from .config import ConfigError, Settings

Pool = asyncpg.Pool


async def create_pool(settings: Settings, *, min_size: int = 1, max_size: int = 6) -> Pool:
    return await asyncpg.create_pool(settings.database_url, min_size=min_size, max_size=max_size, command_timeout=60)


def _rec(row: asyncpg.Record | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


# ------------------------------------------------------------------------ runs
RUN_SELECT = """
SELECT j.id AS job_id, j.run_id, j.account_id, j.asset_id, j.product_type, j.status AS job_status,
       a.source_path, a.original_filename, a.sha256, a.trace_state,
       acc.auto_publish, acc.fourthwall_api_user
  FROM processing_jobs j
  JOIN ingested_assets a   ON a.id = j.asset_id
  JOIN users_saas_accounts acc ON acc.id = j.account_id
 WHERE j.module = 'orchestrator'
"""


async def enqueue_run(pool: Pool, *, account_id: int, asset_id: int, product_type: str) -> tuple[uuid.UUID, bool]:
    """Insert the run row. Returns (run_id, created). If a live run exists for the same
    (asset, product_type) the partial unique index rejects the insert and the existing run_id is returned."""
    run_id = uuid.uuid4()
    async with pool.acquire() as con:
        try:
            async with con.transaction():
                await con.execute(
                    """INSERT INTO processing_jobs (run_id, account_id, asset_id, product_type, module, step_name, step_index, status)
                       VALUES ($1,$2,$3,$4,'orchestrator','pipeline_run',0,'queued')""",
                    run_id, account_id, asset_id, product_type)
                await con.execute(
                    "UPDATE ingested_assets SET status='queued' WHERE id=$1 AND status IN ('pending','failed','processed')",
                    asset_id)
            return run_id, True
        except asyncpg.UniqueViolationError:
            existing = await con.fetchval(
                """SELECT run_id FROM processing_jobs WHERE asset_id=$1 AND product_type=$2
                      AND module='orchestrator' AND status IN ('queued','running') LIMIT 1""", asset_id, product_type)
            return existing, False


async def claim_run(pool: Pool, run_id: uuid.UUID | None, pid: int) -> dict[str, Any] | None:
    """Atomically move one queued run to running. run_id=None -> oldest queued run. SKIP LOCKED keeps
    concurrent workers (MCP-spawned child + timer-driven drain) from taking the same run."""
    async with pool.acquire() as con:
        row = await con.fetchrow(
            """UPDATE processing_jobs SET status='running', pid=$2, started_at=now()
                WHERE id = (SELECT id FROM processing_jobs
                             WHERE module='orchestrator' AND status='queued'
                               AND ($1::uuid IS NULL OR run_id=$1)
                             ORDER BY id FOR UPDATE SKIP LOCKED LIMIT 1)
            RETURNING id, run_id""", run_id, pid)
        if row is None:
            return None
        return _rec(await con.fetchrow(RUN_SELECT + " AND j.id=$1", row["id"]))


async def get_run(pool: Pool, run_id: uuid.UUID) -> dict[str, Any] | None:
    async with pool.acquire() as con:
        return _rec(await con.fetchrow(RUN_SELECT + " AND j.run_id=$1", run_id))


async def finish_run(pool: Pool, run_id: uuid.UUID, *, ok: bool, digest: str | None) -> None:
    async with pool.acquire() as con:
        await con.execute(
            """UPDATE processing_jobs SET status=$2, finished_at=now(), error_digest=$3
                WHERE run_id=$1 AND module='orchestrator'""",
            run_id, "succeeded" if ok else "failed", (digest or None) and digest[:8000])


async def recover_stale_runs(pool: Pool) -> int:
    """Runs marked 'running' whose worker PID is gone (crash/reboot) go back to 'queued'."""
    n = 0
    async with pool.acquire() as con:
        rows = await con.fetch("SELECT id, pid FROM processing_jobs WHERE module='orchestrator' AND status='running'")
        for r in rows:
            if r["pid"] and _alive(r["pid"]):
                continue
            await con.execute("UPDATE processing_jobs SET status='queued', pid=NULL, started_at=NULL WHERE id=$1", r["id"])
            n += 1
    return n


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


# ----------------------------------------------------------------------- steps
async def start_step(pool: Pool, run: dict[str, Any], *, module: str, step_name: str, step_index: int,
                     attempt: int, tier: int, argv: Sequence[str]) -> int:
    async with pool.acquire() as con:
        return await con.fetchval(
            """INSERT INTO processing_jobs (run_id, account_id, asset_id, product_type, module, step_name,
                                            step_index, attempt, fallback_tier, status, argv, started_at)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'running',$10,now()) RETURNING id""",
            run["run_id"], run["account_id"], run["asset_id"], run["product_type"], module, step_name,
            step_index, attempt, tier, list(argv))


async def finish_step(pool: Pool, job_id: int, *, status: str, exit_code: int | None, pid: int | None,
                      digest: str | None, log_path: str | None, output_path: str | None) -> None:
    async with pool.acquire() as con:
        await con.execute(
            """UPDATE processing_jobs SET status=$2, exit_code=$3, pid=$4, error_digest=$5, log_path=$6,
                      output_path=$7, finished_at=now() WHERE id=$1""",
            job_id, status, exit_code, pid, (digest or None) and digest[:8000], log_path, output_path)


# ---------------------------------------------------------------------- assets
async def set_asset(pool: Pool, asset_id: int, *, status: str | None = None, trace_state: str | None = None,
                    trace_bounds: dict[str, Any] | None = None) -> None:
    async with pool.acquire() as con:
        await con.execute(
            """UPDATE ingested_assets SET status=COALESCE($2,status), trace_state=COALESCE($3,trace_state),
                      trace_bounds=COALESCE($4::jsonb,trace_bounds) WHERE id=$1""",
            asset_id, status, trace_state, json.dumps(trace_bounds) if trace_bounds is not None else None)


async def register_asset(pool: Pool, *, account_id: int, source_path: str, filename: str, sha256: str,
                         byte_size: int, mime: str | None, width: int | None, height: int | None,
                         dpi: int | None, color_space: str, has_alpha: bool | None) -> int | None:
    async with pool.acquire() as con:
        return await con.fetchval(
            """INSERT INTO ingested_assets (account_id, source_kind, source_path, original_filename, sha256, byte_size,
                                            mime_type, width_px, height_px, source_dpi, color_space, has_alpha)
               VALUES ($1,'directory',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
               ON CONFLICT DO NOTHING RETURNING id""",
            account_id, source_path, filename, sha256, byte_size, mime, width, height, dpi, color_space, has_alpha)


async def pending_assets(pool: Pool, *, stuck_after_s: int, account_id: int | None = None, limit: int = 200) -> list[dict[str, Any]]:
    async with pool.acquire() as con:
        rows = await con.fetch(
            """SELECT id, account_id, original_filename, source_path, byte_size, mime_type, width_px, height_px,
                      color_space, has_alpha, status, trace_state, created_at, updated_at,
                      (status IN ('queued','processing') AND updated_at < now() - make_interval(secs => $1)) AS stuck
                 FROM ingested_assets
                WHERE ($2::bigint IS NULL OR account_id=$2)
                  AND (status IN ('pending','failed')
                       OR (status IN ('queued','processing') AND updated_at < now() - make_interval(secs => $1)))
                ORDER BY created_at LIMIT $3""", float(stuck_after_s), account_id, limit)
        return [dict(r) for r in rows]


async def get_asset(pool: Pool, asset_id: int) -> dict[str, Any] | None:
    async with pool.acquire() as con:
        return _rec(await con.fetchrow("SELECT * FROM ingested_assets WHERE id=$1", asset_id))


# -------------------------------------------------------------------- products
async def upsert_product(pool: Pool, run: dict[str, Any], **fields: Any) -> dict[str, Any]:
    """Create the (account, asset, product_type) row if needed, then apply \`fields\`."""
    allowed = {"fw_template_id", "media_id", "media_file_url", "fw_product_id", "fw_slug", "variants", "skus",
               "publish_state", "last_error", "published_at"}
    bad = set(fields) - allowed
    if bad:
        raise ValueError(f"unknown product columns: {sorted(bad)}")
    async with pool.acquire() as con:
        async with con.transaction():
            await con.execute(
                """INSERT INTO fourthwall_products (account_id, asset_id, run_id, product_type)
                   VALUES ($1,$2,$3,$4) ON CONFLICT (account_id, asset_id, product_type) DO UPDATE SET run_id=EXCLUDED.run_id""",
                run["account_id"], run["asset_id"], run["run_id"], run["product_type"])
            sets, args = [], [run["account_id"], run["asset_id"], run["product_type"]]
            for col, val in fields.items():
                args.append(json.dumps(val) if col == "variants" else val)
                sets.append(f"{col}=\${len(args)}" + ("::jsonb" if col == "variants" else ""))
            if sets:
                await con.execute(
                    f"UPDATE fourthwall_products SET {', '.join(sets)} WHERE account_id=$1 AND asset_id=$2 AND product_type=$3", *args)
            return dict(await con.fetchrow(
                "SELECT * FROM fourthwall_products WHERE account_id=$1 AND asset_id=$2 AND product_type=$3",
                run["account_id"], run["asset_id"], run["product_type"]))


async def get_product_row(pool: Pool, ref: str) -> dict[str, Any] | None:
    """\`ref\` is either our numeric row id or a Fourthwall product id."""
    async with pool.acquire() as con:
        if ref.isdigit():
            return _rec(await con.fetchrow("SELECT * FROM fourthwall_products WHERE id=$1", int(ref)))
        return _rec(await con.fetchrow("SELECT * FROM fourthwall_products WHERE fw_product_id=$1 LIMIT 1", ref))


# --------------------------------------------------------------- credentials / logs
async def get_fw_credentials(pool: Pool, settings: Settings, account_id: int) -> tuple[str, str] | None:
    """Per-tenant credentials (secret decrypted in SQL with POD_CREDENTIAL_KEY), else env single-tenant fallback."""
    async with pool.acquire() as con:
        if settings.credential_key:
            row = await con.fetchrow(
                """SELECT fourthwall_api_user AS u,
                          CASE WHEN fourthwall_api_secret_enc IS NULL THEN NULL
                               ELSE pgp_sym_decrypt(fourthwall_api_secret_enc, $2) END AS s
                     FROM users_saas_accounts WHERE id=$1""", account_id, settings.credential_key)
        else:
            row = None
    if row and row["u"] and row["s"]:
        return row["u"], row["s"]
    if settings.fw_api_user and settings.fw_api_secret:
        return settings.fw_api_user, settings.fw_api_secret
    return None


async def log_sync(pool: Pool, *, account_id: int | None, direction: str, channel: str, event_type: str,
                   run_id: uuid.UUID | None = None, http_method: str | None = None, url: str | None = None,
                   status_code: int | None = None, success: bool | None = None, duration_ms: int | None = None,
                   payload: Any = None, fw_product_row_id: int | None = None, external_event_id: str | None = None) -> None:
    if success is None and status_code is not None:
        success = 200 <= status_code < 300
    async with pool.acquire() as con:
        await con.execute(
            """INSERT INTO agent_sync_logs (account_id, direction, channel, event_type, external_event_id, http_method, url,
                                            status_code, success, duration_ms, payload, run_id, fw_product_row_id)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12,$13) ON CONFLICT DO NOTHING""",
            account_id, direction, channel, event_type, external_event_id, http_method, url, status_code, success,
            duration_ms, json.dumps(payload, default=str) if payload is not None else None, run_id, fw_product_row_id)


def require(value: Any, what: str) -> Any:
    if value is None:
        raise ConfigError(what)
    return value
`,b=`"""Inbox scanner. Layout: <root>/data/inbox/<account_id>/<file>. New, settled files are hashed,
inspected and registered in ingested_assets (status 'pending'). Duplicates (same sha256) are ignored."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import mimetypes
import time
from pathlib import Path
from typing import Any

from PIL import Image

from . import db
from .config import Settings

log = logging.getLogger("pod.ingest")
SKIP_SUFFIXES = {".part", ".tmp", ".crdownload", ".swp"}
MAX_INGEST_BYTES = 500 * 1024 * 1024


def inspect_file(path: Path) -> dict[str, Any]:
    """Blocking: hash + cheap metadata. Run in a thread."""
    h = hashlib.sha256()
    size = 0
    with open(path, "rb") as fh:
        while chunk := fh.read(1024 * 1024):
            h.update(chunk)
            size += len(chunk)
    meta: dict[str, Any] = {"sha256": h.hexdigest(), "byte_size": size,
                            "mime": mimetypes.guess_type(path.name)[0], "width": None, "height": None,
                            "dpi": None, "color_space": "unknown", "has_alpha": None}
    try:
        with Image.open(path) as im:
            meta["width"], meta["height"] = im.width, im.height
            dpi = im.info.get("dpi")
            if dpi:
                meta["dpi"] = int(round(float(dpi[0]))) or None
            meta["mime"] = Image.MIME.get(im.format or "", meta["mime"])
            meta["color_space"] = {"RGB": "srgb", "RGBA": "srgb", "LA": "gray", "L": "gray", "P": "indexed",
                                   "PA": "indexed", "CMYK": "cmyk"}.get(im.mode, "unknown")
            meta["has_alpha"] = im.mode in ("RGBA", "LA", "PA") or "transparency" in im.info
    except Exception:
        pass            # SVG/PDF/etc.: keep the basics; Craft apps do the real inspection
    return meta


async def scan_inbox(settings: Settings, pool: db.Pool) -> int:
    root = settings.inbox
    if not root.is_dir():
        return 0
    registered = 0
    now = time.time()
    for acct_dir in sorted(p for p in root.iterdir() if p.is_dir() and p.name.isdigit()):
        account_id = int(acct_dir.name)
        async with pool.acquire() as con:
            if not await con.fetchval("SELECT 1 FROM users_saas_accounts WHERE id=$1 AND status='active'", account_id):
                log.warning("inbox/%s has no active account; skipping", acct_dir.name)
                continue
            known = {r["source_path"] for r in await con.fetch(
                "SELECT source_path FROM ingested_assets WHERE account_id=$1", account_id)}
        for f in sorted(acct_dir.iterdir()):
            if (not f.is_file() or f.is_symlink() or f.name.startswith(".") or f.suffix.lower() in SKIP_SUFFIXES
                    or str(f) in known):
                continue
            st = f.stat()
            if now - st.st_mtime < settings.inbox_settle_s or st.st_size == 0 or st.st_size > MAX_INGEST_BYTES:
                continue            # still being written, empty, or oversized
            meta = await asyncio.to_thread(inspect_file, f)
            new_id = await db.register_asset(
                pool, account_id=account_id, source_path=str(f), filename=f.name, sha256=meta["sha256"],
                byte_size=meta["byte_size"], mime=meta["mime"], width=meta["width"], height=meta["height"],
                dpi=meta["dpi"], color_space=meta["color_space"], has_alpha=meta["has_alpha"])
            if new_id is not None:
                registered += 1
                log.info("registered asset %s (%s)", new_id, f.name)
    return registered
`,x=`"""Product routing table.

This file is the ONLY place that knows the Craft CLI command lines. Everything is data, so when a
Craft app changes a flag you edit one tuple here and nothing else.

Placeholders available inside argv/outputs templates (str.format syntax):
    {src}  copy of the raw input inside the run sandbox      {art}   current artwork (traced SVG, or the
    {work} per-run scratch dir                                        raster fallback PNG if tracing failed)
    {build} per-run output dir                               {fallback_dpi}  raster fallback DPI
    {run_id} {asset_id}                                      {cfg[key]}  per-category value from products.json

Items marked ASSUMPTION are not in the original spec and must be confirmed against the real CLIs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .config import ConfigError

PRODUCT_TYPES = ("apparel", "knitwear", "accessories", "odd_3d", "stationery")

# Defaults merged under <root>/config/products.json[<product_type>]
DEFAULT_CFG: dict[str, dict[str, Any]] = {
    "apparel": {
        "regions": ["front"],
        "max_px": [4200, 4800],            # 14x16 in @ 300 dpi
    },
    "knitwear": {
        "regions": ["front"],
        "palette_limit": 6,                 # factory yarn colors: hard maximum
        "knit_grid": "",                    # REQUIRED: factory 'COLSxROWS'; deliberately no default
    },
    "accessories": {
        "regions": ["front"],
        "template": "fourthwall_crossbody_v1",
        "care_text": "100% Polyester",
    },
    "odd_3d": {
        "regions": ["front"],
        "bleed_in": "0.25",
    },
    "stationery": {
        "regions": ["front"],
        "cover_template": "notebook_cover_template",
        "reel_template": "reel_promo_9_16",
        "reel_preset": "tiktok_1080p",
    },
}


@dataclass(frozen=True)
class Step:
    name: str
    module: str                                  # vectorcraft | photocraft | designcraft | effectcraft | filmcraft
    argv: tuple[str, ...]
    outputs: tuple[str, ...]                     # templates; may contain a glob '*'
    validators: tuple[tuple[str, str], ...] = ()  # (validator_name, output_template)
    timeout_s: int | None = None


@dataclass(frozen=True)
class Route:
    product_type: str
    trace_extra: tuple[str, ...]
    steps: tuple[Step, ...]
    final: str                                   # template: the artifact this category produces
    upload: str | None                           # template: file sent to Fourthwall media library (None = skip)
    notes: str = ""


# --------------------------------------------------------------------------- stage 0 (shared)
def trace_step(route: Route) -> Step:
    """VectorCraft trace. ASSUMPTION: the spec gives no vectorcraft-cli command line; this contract is invented."""
    return Step(
        name="vector_trace",
        module="vectorcraft",
        argv=("vectorcraft-cli", "trace", "--input", "{src}",
              "--svg-out", "{work}/traced.svg", "--pdf-out", "{work}/traced.pdf", *route.trace_extra),
        outputs=("{work}/traced.svg", "{work}/traced.pdf"),
    )


def raster_fallback_step() -> Step:
    """Tier-1 fallback when the vector trace exits with code 1: high-DPI raster path, no tracing.
    ASSUMPTION: PhotoCraft writes its result as a PNG inside --out-dir."""
    return Step(
        name="raster_fallback",
        module="photocraft",
        argv=("photocraft-cli", "--input", "{src}", "--trim-alpha", "false",
              "--target-dpi", "{fallback_dpi}", "--color-profile", "srgb", "--out-dir", "{work}/raster/"),
        outputs=("{work}/raster/*.png",),
    )


# ------------------------------------------------------------------------------------- routes
def _routes() -> dict[str, Route]:
    apparel = Route(
        product_type="apparel",
        trace_extra=(),
        steps=(
            Step("photocraft_trim", "photocraft",
                 # spec lists --target-dpi/--color-profile/--dimensions as agent instructions, not on the
                 # reference command line; they are merged here. Output name 'trimmed.png' comes from the spec.
                 ("photocraft-cli", "--input", "{art}", "--trim-alpha", "true",
                  "--target-dpi", "300", "--color-profile", "srgb", "--dimensions", "14x16in",
                  "--out-dir", "{work}/apparel/"),
                 ("{work}/apparel/trimmed.png",)),
            Step("effectcraft_distress", "effectcraft",
                 ("effectcraft-cli", "--input", "{work}/apparel/trimmed.png",
                  "--filter", "vintage_screen_300", "--output", "{build}/apparel_final.png"),
                 ("{build}/apparel_final.png",),
                 validators=(("png_with_alpha", "{build}/apparel_final.png"),)),
        ),
        final="{build}/apparel_final.png",
        upload="{build}/apparel_final.png",
    )
    knitwear = Route(
        product_type="knitwear",
        trace_extra=("--palette-limit", "{cfg[palette_limit]}"),   # ASSUMPTION: flag name on vectorcraft-cli
        steps=(
            Step("designcraft_stitch_matrix", "designcraft",
                 # ASSUMPTION: '--input {art}' added; the spec's reference line has no input argument.
                 ("designcraft-cli", "--mode", "stitch_matrix", "--input", "{art}",
                  "--palette-limit", "{cfg[palette_limit]}", "--grid-scale", "{cfg[knit_grid]}",
                  "--output", "{build}/knitwear_final.bmp"),
                 ("{build}/knitwear_final.bmp",),
                 validators=(("knit_bmp", "{build}/knitwear_final.bmp"),)),
        ),
        final="{build}/knitwear_final.bmp",
        upload="{build}/knitwear_final.bmp",
        notes="Fourthwall's media API is an image library; a BMP stitch grid may be refused -> needs_manual_upload.",
    )
    accessories = Route(
        product_type="accessories",
        trace_extra=(),
        steps=(
            Step("designcraft_template", "designcraft",
                 ("designcraft-cli", "--template", "{cfg[template]}", "--layer", "artwork", "--embed", "{art}",
                  "--layer", "care_label", "--text", "{cfg[care_text]}",
                  "--output", "{build}/accessory_final.pdf"),
                 ("{build}/accessory_final.pdf",),
                 validators=(("pdf", "{build}/accessory_final.pdf"),)),
        ),
        final="{build}/accessory_final.pdf",
        upload="{build}/accessory_final.pdf",
        notes="Safe-zone bbox checks and tracking/kerning auto-adjust must live inside DesignCraft.",
    )
    odd_3d = Route(
        product_type="odd_3d",
        trace_extra=(),
        steps=(
            Step("designcraft_wrap_tile", "designcraft",
                 ("designcraft-cli", "--mode", "wrap_tile", "--bleed", "{cfg[bleed_in]}", "--input", "{art}",
                  "--output", "{work}/odd/tiled.pdf"),
                 ("{work}/odd/tiled.pdf",),
                 validators=(("pdf", "{work}/odd/tiled.pdf"),)),
            Step("effectcraft_cylinder_taper", "effectcraft",
                 ("effectcraft-cli", "--cylinder-taper", "--input", "{work}/odd/tiled.pdf",
                  "--output", "{build}/odd_final.pdf"),
                 ("{build}/odd_final.pdf",),
                 validators=(("pdf", "{build}/odd_final.pdf"),)),
        ),
        final="{build}/odd_final.pdf",
        upload="{build}/odd_final.pdf",
    )
    stationery = Route(
        product_type="stationery",
        trace_extra=(),
        steps=(
            Step("designcraft_cover", "designcraft",
                 # ASSUMPTION: '--embed {art}' added so artwork reaches the template; '--variable-data order_id'
                 # is dropped here because a cover is built before any order exists.
                 ("designcraft-cli", "--input", "{cfg[cover_template]}", "--embed", "{art}",
                  "--output", "{build}/print_ready_stationery.pdf"),
                 ("{build}/print_ready_stationery.pdf",),
                 validators=(("pdf", "{build}/print_ready_stationery.pdf"),)),
            Step("filmcraft_reel", "filmcraft",
                 ("filmcraft-cli", "--template", "{cfg[reel_template]}", "--asset-layer", "product_front",
                  "--input", "{build}/print_ready_stationery.pdf", "--render-preset", "{cfg[reel_preset]}",
                  "--output", "{build}/promo_reel.mp4"),
                 ("{build}/promo_reel.mp4",),
                 validators=(("mp4", "{build}/promo_reel.mp4"),),
                 timeout_s=1800),
        ),
        final="{build}/print_ready_stationery.pdf",
        upload="{build}/print_ready_stationery.pdf",
        notes="promo_reel.mp4 is a marketing asset, not a Fourthwall upload. Packing slips are NOT built here.",
    )
    return {r.product_type: r for r in (apparel, knitwear, accessories, odd_3d, stationery)}


ROUTES: dict[str, Route] = _routes()


def merged_cfg(product_type: str, overrides: dict[str, dict[str, Any]]) -> dict[str, Any]:
    if product_type not in ROUTES:
        raise ConfigError(f"unknown product_type {product_type!r}; expected one of {', '.join(PRODUCT_TYPES)}")
    return {**DEFAULT_CFG.get(product_type, {}), **overrides.get(product_type, {})}


def render(template: str, variables: dict[str, Any], *, where: str) -> str:
    try:
        return template.format_map(variables)
    except (KeyError, IndexError) as exc:
        raise ConfigError(f"{where}: placeholder {exc} is not defined (check products.json)") from exc


def render_argv(step: Step, variables: dict[str, Any]) -> list[str]:
    out = [render(tok, variables, where=f"step {step.name}") for tok in step.argv]
    for tok in out:
        if tok == "":
            raise ConfigError(f"step {step.name}: an argument rendered empty; a required products.json value is missing")
    return out
`,S=`"""Async process runner: sandbox wrapping, streaming log digest, hard timeouts, durable flush."""
from __future__ import annotations

import asyncio
import hashlib
import os
import shutil
import signal
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from .config import Settings
from .logfilter import StreamDigest

TRANSIENT_EXIT_CODES = {-9, -15, 137, 143, 75}   # SIGKILL/SIGTERM (OOM killer), docker 128+n, EX_TEMPFAIL


@dataclass
class StepOutcome:
    exit_code: int
    timed_out: bool
    pid: int | None
    duration_s: float
    digest: str
    executed_argv: list[str]

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out

    @property
    def transient(self) -> bool:
        return self.timed_out or self.exit_code in TRANSIENT_EXIT_CODES


class FlushTimeout(RuntimeError):
    pass


def build_command(settings: Settings, argv: list[str], *, work: Path, build: Path, container_name: str) -> list[str]:
    """Wrap a Craft command line in the configured sandbox.

    docker mode: cgroup limits (--memory/--cpus/--cpu-shares) are what protect the web app. \`nice\` on the
    \`docker run\` client would not reach the container's processes (the daemon starts them), so it is not used.
    native mode: nice + ionice (idle class) on the process itself.
    """
    inner = [*settings.craft_prefix, *argv]
    if settings.use_docker:
        return [
            "docker", "run", "--rm", "--init", "--name", container_name,
            "--memory", settings.docker_memory, "--memory-swap", settings.docker_memory,   # no swap use
            "--cpus", settings.docker_cpus, "--cpu-shares", str(settings.docker_cpu_shares),
            "--pids-limit", "256", "--network", "none",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
            "--read-only", "--tmpfs", "/tmp:rw,size=512m", "-e", "HOME=/tmp",
            "--user", f"{os.getuid()}:{os.getgid()}",
            "-v", f"{work}:{work}:rw", "-v", f"{build}:{build}:rw", "-w", str(work),
            settings.docker_image, *inner,
        ]
    prefix = ["nice", "-n", str(settings.nice_level)]
    if shutil.which("ionice"):
        prefix += ["ionice", "-c", "3"]
    return [*prefix, *inner]


def _env(settings: Settings, work: Path) -> dict[str, str]:
    path = f"{settings.bin_dir}{os.pathsep}{os.environ.get('PATH', '/usr/local/bin:/usr/bin:/bin')}"
    return {"PATH": path, "HOME": str(work), "LANG": "C.UTF-8", "TMPDIR": str(work),
            "QT_QPA_PLATFORM": "offscreen", "POD_RUN_WORKDIR": str(work)}


async def _terminate(proc: asyncio.subprocess.Process, container: str | None) -> None:
    if container:
        killer = await asyncio.create_subprocess_exec(
            "docker", "kill", container, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
        await killer.wait()
    for sig, grace in ((signal.SIGTERM, 5.0), (signal.SIGKILL, 5.0)):
        try:
            os.killpg(proc.pid, sig)
        except ProcessLookupError:
            return
        try:
            await asyncio.wait_for(proc.wait(), grace)
            return
        except asyncio.TimeoutError:
            continue


async def run_step(
    settings: Settings, argv: list[str], *, work: Path, build: Path, log_path: Path, timeout_s: int,
) -> StepOutcome:
    container = f"pod-{uuid.uuid4().hex[:12]}" if settings.use_docker else None
    cmd = build_command(settings, argv, work=work, build=build, container_name=container or "")
    digest = StreamDigest(log_path=log_path, max_log_bytes=settings.max_log_bytes)
    started = time.monotonic()
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT, cwd=work, env=_env(settings, work),
            start_new_session=True,                       # own process group -> killpg reaches helper processes
        )
    except FileNotFoundError as exc:
        digest.finish()
        return StepOutcome(127, False, None, 0.0, f"executable not found: {exc.filename}", cmd)

    reader = asyncio.create_task(digest.consume(proc.stdout))   # type: ignore[arg-type]
    timed_out = False
    try:
        await asyncio.wait_for(proc.wait(), timeout_s)
    except asyncio.TimeoutError:
        timed_out = True
        await _terminate(proc, container)
    try:
        await asyncio.wait_for(reader, 10)
    except asyncio.TimeoutError:
        # a grandchild still holds the pipe open after the main process exited: kill the leftovers
        reader.cancel()
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        digest.finish()
    code = proc.returncode if proc.returncode is not None else -1
    return StepOutcome(code, timed_out, proc.pid, time.monotonic() - started, digest.render(), cmd)


# ------------------------------------------------------------------------------ durable flush
def _fsync_and_hash(path: Path) -> tuple[int, str]:
    h = hashlib.sha256()
    size = 0
    fd = os.open(path, os.O_RDONLY)
    try:
        with os.fdopen(os.dup(fd), "rb") as fh:
            while chunk := fh.read(1024 * 1024):
                h.update(chunk)
                size += len(chunk)
        os.fsync(fd)                                      # file data + metadata to stable storage
    finally:
        os.close(fd)
    dfd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(dfd)                                     # directory entry (the file's name) too
    finally:
        os.close(dfd)
    return size, h.hexdigest()


async def flush_to_disk(path: Path, *, poll_s: float = 0.2, stable_polls: int = 2, max_wait_s: float = 30.0) -> tuple[int, str]:
    """Wait until \`path\` stops changing, then fsync it (and its directory) off the event loop.

    Returns (size, sha256). Only after this returns is it safe to stream the file to another host."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + max_wait_s
    last: tuple[int, int] | None = None
    stable = 0
    while True:
        try:
            st = await asyncio.to_thread(os.stat, path)
            sig: tuple[int, int] | None = (st.st_size, st.st_mtime_ns)
        except FileNotFoundError:
            sig = None
        stable = stable + 1 if (sig is not None and sig[0] > 0 and sig == last) else 0
        last = sig
        if stable >= stable_polls:
            return await asyncio.to_thread(_fsync_and_hash, path)
        if loop.time() > deadline:
            raise FlushTimeout(f"{path} did not settle within {max_wait_s}s (size/mtime still changing or file missing)")
        await asyncio.sleep(poll_s)
`,C=`"""Post-step output validators. They are synchronous; the orchestrator runs them in a worker thread.

A validator raises ValidationError with a precise, short message. Validation failures are
deterministic, so the orchestrator never retries them (re-running the same tool gives the same file).
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable

from PIL import Image

Image.MAX_IMAGE_PIXELS = 400_000_000   # 4200x4800 print files are ~20 MP; this still blocks decompression bombs


class ValidationError(RuntimeError):
    pass


def parse_grid(spec: str) -> tuple[int, int]:
    """Factory grid spec 'COLSxROWS' (stitches x rows) -> (cols, rows)."""
    m = re.fullmatch(r"\\s*(\\d{1,5})\\s*[xX]\\s*(\\d{1,5})\\s*", spec or "")
    if not m:
        raise ValidationError(f"knit grid spec must look like 'COLSxROWS' (e.g. '112x140'), got {spec!r}")
    return int(m.group(1)), int(m.group(2))


def png_with_alpha(path: Path, cfg: dict[str, Any]) -> None:
    max_w, max_h = cfg.get("max_px", [4200, 4800])      # 14x16 in @ 300 dpi
    try:
        with Image.open(path) as im:
            im.load()
            if im.format != "PNG":
                raise ValidationError(f"{path.name}: expected PNG, got {im.format}")
            if im.width > max_w or im.height > max_h:
                raise ValidationError(f"{path.name}: {im.width}x{im.height}px exceeds {max_w}x{max_h}px print area")
            rgba = im.convert("RGBA")
            if rgba.getchannel("A").getbbox() is None:
                raise ValidationError(f"{path.name}: image is fully transparent")
    except OSError as exc:
        raise ValidationError(f"{path.name}: unreadable image ({exc})") from exc


def _bmp_header(path: Path) -> tuple[int, int, int, int]:
    """Return (width, height, bits_per_pixel, compression) straight from the BITMAPINFOHEADER.

    Pillow drops the alpha channel of 32-bit BMPs on read, so alpha must be judged from the header.
    """
    with open(path, "rb") as fh:
        head = fh.read(34)
    if len(head) < 34 or head[:2] != b"BM":
        raise ValidationError(f"{path.name}: not a BMP file")
    dib_size = int.from_bytes(head[14:18], "little")
    if dib_size < 40:
        raise ValidationError(f"{path.name}: unsupported legacy BMP header ({dib_size} bytes)")
    width = int.from_bytes(head[18:22], "little", signed=True)
    height = abs(int.from_bytes(head[22:26], "little", signed=True))
    bpp = int.from_bytes(head[28:30], "little")
    compression = int.from_bytes(head[30:34], "little")
    return width, height, bpp, compression


def knit_bmp(path: Path, cfg: dict[str, Any]) -> None:
    """Hard-edge, opaque, palette-limited, exact grid size, uncompressed."""
    cols, rows = parse_grid(str(cfg.get("knit_grid", "")))
    palette_limit = int(cfg.get("palette_limit", 6))
    width, height, bpp, compression = _bmp_header(path)
    if compression != 0:
        raise ValidationError(f"{path.name}: BMP must be uncompressed (BI_RGB), header says compression={compression}")
    if bpp not in (1, 4, 8, 24):
        raise ValidationError(
            f"{path.name}: {bpp}-bit BMP can carry an alpha channel; export 8-bit indexed (preferred) or 24-bit "
            "so every pixel is a 100% opaque thread color")
    if (width, height) != (cols, rows):
        raise ValidationError(f"{path.name}: grid is {width}x{height}, factory spec is {cols}x{rows}")
    try:
        with Image.open(path) as im:
            im.load()
            colors = im.convert("RGB").getcolors(maxcolors=palette_limit + 1)
    except OSError as exc:
        raise ValidationError(f"{path.name}: unreadable image ({exc})") from exc
    if colors is None:
        raise ValidationError(
            f"{path.name}: more than {palette_limit} distinct colors. Anti-aliased or gradient edge pixels "
            "produce extra colors; the factory yarn limit is a hard maximum")


def pdf_ok(path: Path, cfg: dict[str, Any]) -> None:
    with open(path, "rb") as fh:
        head = fh.read(8)
        fh.seek(0, 2)
        size = fh.tell()
        fh.seek(max(0, size - 2048))
        tail = fh.read()
    if not head.startswith(b"%PDF-"):
        raise ValidationError(f"{path.name}: missing %PDF header")
    if b"%%EOF" not in tail:
        raise ValidationError(f"{path.name}: missing %%EOF trailer (truncated write?)")


def mp4_ok(path: Path, cfg: dict[str, Any]) -> None:
    with open(path, "rb") as fh:
        head = fh.read(12)
    if len(head) < 12 or head[4:8] != b"ftyp":
        raise ValidationError(f"{path.name}: not an MP4/ISO-BMFF file (no ftyp box)")
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return   # container check only; install ffmpeg to also verify 1080x1920 / ~5 s
    want = cfg.get("reel", {"width": 1080, "height": 1920, "seconds": 5.0, "tolerance": 0.75})
    try:
        out = subprocess.run(
            [ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
             "stream=width,height:format=duration", "-of", "json", str(path)],
            capture_output=True, text=True, timeout=60, check=True).stdout
        info = json.loads(out)
        w, h = info["streams"][0]["width"], info["streams"][0]["height"]
        dur = float(info["format"]["duration"])
    except (subprocess.SubprocessError, KeyError, IndexError, ValueError) as exc:
        raise ValidationError(f"{path.name}: ffprobe could not read the video ({exc})") from exc
    if (w, h) != (want["width"], want["height"]):
        raise ValidationError(f"{path.name}: video is {w}x{h}, expected {want['width']}x{want['height']} (9:16)")
    if abs(dur - want["seconds"]) > want["tolerance"]:
        raise ValidationError(f"{path.name}: duration {dur:.2f}s, expected about {want['seconds']}s")


VALIDATORS: dict[str, Callable[[Path, dict[str, Any]], None]] = {
    "png_with_alpha": png_with_alpha,
    "knit_bmp": knit_bmp,
    "pdf": pdf_ok,
    "mp4": mp4_ok,
}
`,w=`"""Streaming log filter.

Craft binaries can emit many megabytes of progress output. We never hold that in memory and never
hand it to the LLM. Every byte is (optionally) copied to a size-capped log file on disk, while an
in-memory digest keeps only: de-duplicated lines matching an error regex, plus the last few lines.
\`render()\` returns a small, fixed-size string that is safe to store in Postgres and feed to DeepSeek.
"""
from __future__ import annotations

import asyncio
import re
from collections import OrderedDict, deque
from pathlib import Path
from typing import BinaryIO

ERROR_RE = re.compile(
    r"(?i)\\b(error|fatal|exception|traceback|failed|failure|panic|segfault|segmentation|"
    r"abort(?:ed)?|denied|killed|out of memory|oom|cannot|unable to|invalid|unsupported)\\b"
)
_DIGITS = re.compile(r"\\d+")
_MAX_PENDING = 64 * 1024          # a "line" longer than this without a newline is cut here


class StreamDigest:
    def __init__(
        self,
        *,
        log_path: Path | None = None,
        max_log_bytes: int = 5 * 1024 * 1024,
        max_error_entries: int = 20,
        tail_lines: int = 12,
        max_line_chars: int = 300,
    ) -> None:
        self._max_error_entries = max_error_entries
        self._max_line_chars = max_line_chars
        self._tail: deque[str] = deque(maxlen=tail_lines)
        self._errors: "OrderedDict[str, list]" = OrderedDict()   # key -> [first_line, count]
        self._dropped_errors = 0
        self._pending = bytearray()
        self.total_bytes = 0
        self.total_lines = 0
        self.log_truncated = False
        self._log_budget = max_log_bytes
        self._log: BinaryIO | None = None
        if log_path is not None:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            self._log = open(log_path, "wb")

    # ------------------------------------------------------------------ input
    def feed(self, data: bytes) -> None:
        if not data:
            return
        self.total_bytes += len(data)
        self._write_log(data)
        self._pending.extend(data)
        # split on \\n and \\r: progress bars redraw with \\r and would otherwise form one giant "line"
        while True:
            cut = self._find_delim(self._pending)
            if cut < 0:
                if len(self._pending) > _MAX_PENDING:
                    self._emit(bytes(self._pending))
                    self._pending.clear()
                return
            line = bytes(self._pending[:cut])
            del self._pending[: cut + 1]
            if line:
                self._emit(line)

    @staticmethod
    def _find_delim(buf: bytearray) -> int:
        n, r = buf.find(b"\\n"), buf.find(b"\\r")
        if n < 0:
            return r
        if r < 0:
            return n
        return min(n, r)

    def finish(self) -> None:
        if self._pending:
            self._emit(bytes(self._pending))
            self._pending.clear()
        if self._log is not None:
            self._log.flush()
            self._log.close()
            self._log = None

    async def consume(self, stream: asyncio.StreamReader) -> None:
        try:
            while True:
                chunk = await stream.read(65536)
                if not chunk:
                    break
                self.feed(chunk)
        finally:
            self.finish()

    # ----------------------------------------------------------------- output
    def render(self, max_chars: int = 2000) -> str:
        parts = [f"[{self.total_lines} lines, {self.total_bytes} bytes"
                 + (", log truncated on disk" if self.log_truncated else "") + "]"]
        for first, count in self._errors.values():
            parts.append(f"(x{count}) {first}" if count > 1 else first)
        if self._dropped_errors:
            parts.append(f"... {self._dropped_errors} more distinct error lines omitted")
        seen = {first for first, _ in self._errors.values()}
        tail = [t for t in self._tail if t not in seen]
        if tail:
            parts.append("-- last lines --")
            parts.extend(tail)
        text = "\\n".join(parts)
        if len(text) > max_chars:
            text = text[: max_chars - 15].rstrip() + "\\n...[truncated]"
        return text

    # --------------------------------------------------------------- internals
    def _emit(self, raw: bytes) -> None:
        line = raw.decode("utf-8", errors="replace").strip()
        if not line:
            return
        self.total_lines += 1
        if len(line) > self._max_line_chars:
            line = line[: self._max_line_chars] + "..."
        self._tail.append(line)
        if ERROR_RE.search(line):
            key = _DIGITS.sub("#", line)[:120]
            hit = self._errors.get(key)
            if hit is not None:
                hit[1] += 1
            elif len(self._errors) < self._max_error_entries:
                self._errors[key] = [line, 1]
            else:
                self._dropped_errors += 1

    def _write_log(self, data: bytes) -> None:
        if self._log is None or self._log_budget <= 0:
            if self._log is not None and not self.log_truncated:
                self._log.write(b"\\n[log truncated: size cap reached]\\n")
                self.log_truncated = True
            return
        piece = data[: self._log_budget]
        self._log.write(piece)
        self._log_budget -= len(piece)
        if len(piece) < len(data):
            self._log.write(b"\\n[log truncated: size cap reached]\\n")
            self.log_truncated = True
`,T=`"""Pipeline orchestrator: one \`run_pipeline()\` call = one asset through one product route.

Flow:  claim run -> stage input (sha256 verified) -> VectorCraft trace (raster fallback on exit 1)
       -> route steps (validate + fsync after each) -> publish to Fourthwall -> mark run.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import hashlib
import logging
import shutil
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

from . import db
from .config import ConfigError, Settings
from .fourthwall import FourthwallClient, FourthwallError, UnsupportedMedia
from .routes import (ROUTES, Route, Step, merged_cfg, raster_fallback_step, render, render_argv, trace_step)
from .runner import FlushTimeout, StepOutcome, flush_to_disk, run_step
from .validators import VALIDATORS, ValidationError

log = logging.getLogger("pod.orchestrator")

TRACE_FALLBACK_EXIT_CODES = {1}      # spec: "if a vector trace step returns exit code 1 -> raster fallback"


class PipelineError(RuntimeError):
    def __init__(self, message: str, *, digest: str = "", exit_code: int | None = None, quarantine: bool = False):
        super().__init__(message)
        self.digest, self.exit_code, self.quarantine = digest, exit_code, quarantine


@dataclass
class RunCtx:
    settings: Settings
    pool: db.Pool
    run: dict[str, Any]
    route: Route
    cfg: dict[str, Any]
    work: Path
    build: Path
    logs: Path
    vars: dict[str, Any] = field(default_factory=dict)
    _idx: int = 0

    def next_index(self) -> int:
        self._idx += 1
        return self._idx


# ------------------------------------------------------------------------------ entry point
async def run_pipeline(settings: Settings, pool: db.Pool, run_id: uuid.UUID | None, *, pid: int) -> dict[str, Any] | None:
    """Claim and execute one run (specific run_id, or the oldest queued one when None).
    Returns a summary dict, or None when nothing was claimable."""
    run = await db.claim_run(pool, run_id, pid)
    if run is None:
        return None
    rid: uuid.UUID = run["run_id"]
    summary: dict[str, Any] = {"run_id": str(rid), "asset_id": run["asset_id"], "product_type": run["product_type"],
                               "ok": False, "product_state": None, "artifact": None, "error": None}
    ctx: RunCtx | None = None
    try:
        route = ROUTES[run["product_type"]]
        ctx = RunCtx(settings=settings, pool=pool, run=run, route=route,
                     cfg=merged_cfg(run["product_type"], settings.products),
                     work=settings.sandbox / str(rid), build=settings.build / str(rid), logs=settings.job_logs / str(rid))
        await db.log_sync(pool, account_id=run["account_id"], direction="outbound", channel="orchestrator",
                          event_type="run.started", run_id=rid, payload={"product_type": run["product_type"]})
        final = await _execute(ctx)
        summary["artifact"] = str(final)
        summary["product_state"] = await _publish(ctx, final)
        await db.set_asset(pool, run["asset_id"], status="processed")
        await db.finish_run(pool, rid, ok=True, digest=None)
        summary["ok"] = True
        await asyncio.to_thread(shutil.rmtree, ctx.work, True)       # keep sandbox only for failed runs
    except PipelineError as exc:
        summary["error"] = _short(exc)
        await _fail(pool, run, exc.digest or str(exc), quarantine=exc.quarantine)
    except ConfigError as exc:
        summary["error"] = f"configuration: {exc}"
        await _fail(pool, run, summary["error"])
    except Exception as exc:                                          # bug or environment failure: keep it compact
        log.exception("run %s crashed", rid)
        summary["error"] = f"{type(exc).__name__}: {exc}"
        await _fail(pool, run, "".join(traceback.format_exception_only(type(exc), exc)) + _tb_tail())
    await db.log_sync(pool, account_id=run["account_id"], direction="outbound", channel="orchestrator",
                      event_type="run.finished", run_id=rid, success=summary["ok"], payload=summary)
    return summary


def _short(exc: BaseException) -> str:
    return str(exc)[:500]


def _tb_tail() -> str:
    return "\\n".join(traceback.format_exc().splitlines()[-6:])


async def _fail(pool: db.Pool, run: dict[str, Any], digest: str, *, quarantine: bool = False) -> None:
    await db.finish_run(pool, run["run_id"], ok=False, digest=digest)
    await db.set_asset(pool, run["asset_id"], status="quarantined" if quarantine else "failed")


# ---------------------------------------------------------------------------------- stages
async def _execute(ctx: RunCtx) -> Path:
    s = ctx.settings
    for d in (ctx.work, ctx.build, ctx.logs):
        await asyncio.to_thread(d.mkdir, 0o750, True, True)
    await db.set_asset(ctx.pool, ctx.run["asset_id"], status="processing")

    src_path = Path(ctx.run["source_path"])
    staged = ctx.work / f"input{src_path.suffix.lower()}"
    await asyncio.to_thread(_stage_input, src_path, staged, ctx.run["sha256"])
    ctx.vars.update(src=str(staged), art=str(staged), work=str(ctx.work), build=str(ctx.build),
                    run_id=str(ctx.run["run_id"]), asset_id=ctx.run["asset_id"],
                    fallback_dpi=s.fallback_raster_dpi, cfg=ctx.cfg)

    await _trace_stage(ctx)
    for step in ctx.route.steps:
        await _run_step(ctx, step)
    final = Path(render(ctx.route.final, ctx.vars, where="route.final"))
    if not final.is_file():
        raise PipelineError(f"route finished but final artifact is missing: {final}")
    return final


def _stage_input(src: Path, dst: Path, expected_sha: str) -> None:
    if not src.is_file():
        raise PipelineError(f"source file is gone: {src}", quarantine=True)
    h = hashlib.sha256()
    with open(src, "rb") as fi, open(dst, "wb") as fo:
        while chunk := fi.read(1024 * 1024):
            h.update(chunk)
            fo.write(chunk)
        fo.flush()
    if h.hexdigest() != expected_sha:
        dst.unlink(missing_ok=True)
        raise PipelineError(f"{src.name} changed after ingest (sha256 mismatch); refusing to process", quarantine=True)


async def _trace_stage(ctx: RunCtx) -> None:
    pool, asset_id = ctx.pool, ctx.run["asset_id"]
    step = trace_step(ctx.route)
    idx = ctx.next_index()
    await db.set_asset(pool, asset_id, trace_state="tracing")
    try:
        outs = await _run_step(ctx, step, index=idx)
    except PipelineError as exc:
        if exc.exit_code not in TRACE_FALLBACK_EXIT_CODES:
            await db.set_asset(pool, asset_id, trace_state="trace_failed")
            raise
        log.warning("vector trace exited %s; switching to raster fallback (tier 1)", exc.exit_code)
        outs = await _run_step(ctx, raster_fallback_step(), index=idx, tier=1)
        ctx.vars["art"] = str(outs[0])
        await db.set_asset(pool, asset_id, trace_state="raster_fallback")
        return
    ctx.vars["art"] = str(outs[0])           # traced.svg
    await db.set_asset(pool, asset_id, trace_state="traced")


async def _run_step(ctx: RunCtx, step: Step, *, index: int | None = None, tier: int = 0) -> list[Path]:
    s = ctx.settings
    idx = index if index is not None else ctx.next_index()
    argv = render_argv(step, ctx.vars)
    timeout = step.timeout_s or s.step_timeout_s
    last_err: PipelineError | None = None
    for attempt in range(1, s.max_attempts + 1):
        log_path = ctx.logs / f"{idx:02d}-{step.name}-t{tier}-a{attempt}.log"
        job_id = await db.start_step(ctx.pool, ctx.run, module=step.module, step_name=step.name, step_index=idx,
                                     attempt=attempt, tier=tier, argv=argv)
        outcome: StepOutcome = await run_step(s, argv, work=ctx.work, build=ctx.build, log_path=log_path, timeout_s=timeout)
        problem: PipelineError | None = None
        outputs: list[Path] = []
        if not outcome.ok:
            why = "timed out after %ss" % timeout if outcome.timed_out else f"exit code {outcome.exit_code}"
            problem = PipelineError(f"{step.name} failed: {why}", digest=outcome.digest, exit_code=outcome.exit_code)
        else:
            try:
                outputs = await _collect_and_validate(ctx, step)
            except (PipelineError, ValidationError, FlushTimeout) as exc:
                code = 0 if isinstance(exc, PipelineError) else None
                problem = PipelineError(f"{step.name}: {exc}", digest=f"{exc}\\n{outcome.digest}"[:4000], exit_code=code)
        await db.finish_step(ctx.pool, job_id, status="failed" if problem else "succeeded", exit_code=outcome.exit_code,
                             pid=outcome.pid, digest=(problem.digest if problem else outcome.digest if outcome.exit_code else None),
                             log_path=str(log_path), output_path=str(outputs[0]) if outputs else None)
        if problem is None:
            return outputs
        last_err = problem
        retryable = outcome.transient and attempt < s.max_attempts
        log.warning("step %s attempt %d failed (%s)%s", step.name, attempt, problem, "; retrying" if retryable else "")
        if not retryable:
            break
    assert last_err is not None
    raise last_err


async def _collect_and_validate(ctx: RunCtx, step: Step) -> list[Path]:
    outputs: list[Path] = []
    for tmpl in step.outputs:
        pattern = render(tmpl, ctx.vars, where=f"step {step.name} outputs")
        if "*" in pattern:
            matches = sorted(Path(pattern).parent.glob(Path(pattern).name))
            if not matches:
                raise PipelineError(f"expected output not produced: {pattern}")
            path = matches[0]
        else:
            path = Path(pattern)
        if not path.is_file() or path.stat().st_size == 0:
            raise PipelineError(f"expected output missing or empty: {path}")
        await flush_to_disk(path, poll_s=ctx.settings.flush_poll_s)
        outputs.append(path)
    for vname, tmpl in step.validators:
        target = Path(render(tmpl, ctx.vars, where=f"step {step.name} validator"))
        await asyncio.to_thread(VALIDATORS[vname], target, ctx.cfg)
    return outputs


# --------------------------------------------------------------------------------- publish
async def _publish(ctx: RunCtx, final: Path) -> str:
    """Upload to Fourthwall and create the design product. Returns the resulting publish_state."""
    run, pool, cfg = ctx.run, ctx.pool, ctx.cfg
    row = await db.upsert_product(pool, run)
    if row["fw_product_id"]:
        log.info("asset %s/%s already has Fourthwall product %s; not creating another",
                 run["asset_id"], run["product_type"], row["fw_product_id"])
        return row["publish_state"]
    upload_tmpl = ctx.route.upload
    if upload_tmpl is None:
        await db.upsert_product(pool, run, publish_state="draft", last_error="route has no Fourthwall upload step")
        return "draft"
    upload = Path(render(upload_tmpl, ctx.vars, where="route.upload"))

    creds = await db.get_fw_credentials(pool, ctx.settings, run["account_id"])
    if creds is None:
        await db.upsert_product(pool, run, publish_state="draft", last_error="no Fourthwall credentials configured")
        return "draft"
    template_id = cfg.get("fourthwall_template_id")
    if not template_id:
        msg = (f"products.json[{run['product_type']}].fourthwall_template_id is not set "
               "(list ids with: python -m pod_pipeline.worker --list-templates)")
        await db.upsert_product(pool, run, publish_state="failed", last_error=msg)
        raise PipelineError(msg)

    await db.upsert_product(pool, run, publish_state="processing", last_error=None, fw_template_id=template_id)

    async def hook(ev: dict[str, Any]) -> None:
        await db.log_sync(pool, account_id=run["account_id"], direction="outbound", channel="fourthwall_api",
                          run_id=run["run_id"], fw_product_row_id=row["id"], **ev)

    stem = Path(run["original_filename"]).stem.replace("_", " ").replace("-", " ").strip() or "Design"
    try:
        async with FourthwallClient(ctx.settings.fw_base_url, creds[0], creds[1], hook=hook) as fw:
            media_id = row["media_id"]
            if not media_id:
                img = await fw.upload_image(upload)
                media_id = img["id"]
                await db.upsert_product(pool, run, media_id=media_id, media_file_url=img.get("uri"))
            created = await fw.create_design_product(
                template_id=template_id, name=cfg.get("product_name", stem), description=cfg.get("description", stem),
                regions=[{"region": r, "imageId": media_id, "placementStrategy": "AUTO"} for r in cfg.get("regions", ["front"])],
                publish_on_create=False, profit_margin=cfg.get("profit_margin"))
            fw_id = created.get("productId") or created.get("id")
            if not fw_id:
                raise FourthwallError(f"create product response had no productId: {str(created)[:200]}")
            await db.upsert_product(pool, run, fw_product_id=fw_id)
            detail: dict[str, Any] = {}
            try:
                detail = await fw.get_product(fw_id)
            except FourthwallError as exc:       # product exists; detail is nice-to-have
                log.warning("created %s but could not read it back: %s", fw_id, exc)
            variants = detail.get("variants") or []
            state = "draft"
            if run.get("auto_publish"):
                await fw.set_state(fw_id, "PUBLIC")
                state = "active"
            await db.upsert_product(
                pool, run, fw_slug=detail.get("slug"), variants=variants,
                skus=[v["sku"] for v in variants if v.get("sku")], publish_state=state, last_error=None,
                published_at=dt.datetime.now(dt.timezone.utc) if state == "active" else None)
            return state
    except UnsupportedMedia as exc:
        msg = f"Fourthwall media library refused {upload.name} ({exc.code}); supported: {exc.supported or 'unknown'}"
        await db.upsert_product(pool, run, publish_state="needs_manual_upload", last_error=msg)
        return "needs_manual_upload"
    except FourthwallError as exc:
        await db.upsert_product(pool, run, publish_state="failed", last_error=str(exc)[:500])
        raise PipelineError(f"Fourthwall publish failed: {exc}", digest=str(exc)) from exc
    except httpx.TransportError as exc:
        await db.upsert_product(pool, run, publish_state="failed", last_error=f"network: {exc}"[:500])
        raise PipelineError(f"Fourthwall network error: {exc}") from exc

`,E=`"""Fourthwall Open API client.

Endpoints and the exact upload handshake were checked against docs.fourthwall.com (Nov 2026):

    POST /open-api/v1.0/media/upload-url   {fileName, contentType, size}  -> {uploadUrl, fileUrl}
    PUT  <uploadUrl>   (Google Cloud Storage, NO Fourthwall credentials)
         headers: Content-Type == contentType, x-goog-content-length-range: 0,<size>   (both are signed)
    POST /open-api/v1.0/media/images       {fileUrl, width, height}       -> {id: imageId, ...}
    POST /open-api/v1.0/products           {type:"design", productTemplateId, name, regions:[{region,imageId}]}
    GET  /open-api/v1.0/products/{id}      PUT /open-api/v1.0/products/{id}/state {state: PUBLIC|HIDDEN}
    GET  /open-api/v1.0/product-templates

Auth: HTTP Basic with an API key pair (docs: "API keys have full access to these endpoints").
Rate limits: media/upload-url 20 req/min per shop; most others 100 req / 10 s per shop.
"""
from __future__ import annotations

import asyncio
import time
from collections import deque
from pathlib import Path
from typing import Any, Awaitable, Callable

import httpx
from PIL import Image

Hook = Callable[[dict[str, Any]], Awaitable[None]]


class FourthwallError(RuntimeError):
    def __init__(self, message: str, *, status: int | None = None, code: str | None = None, body: Any = None):
        super().__init__(message)
        self.status, self.code, self.body = status, code, body


class UnsupportedMedia(FourthwallError):
    """406 UNSUPPORTED_MEDIA_TYPE_ERROR / UNSUPPORTED_ASSET_TYPE_ERROR from the media library."""

    def __init__(self, message: str, *, supported: list[str] | None = None, **kw: Any):
        super().__init__(message, **kw)
        self.supported = supported or []


class SlidingWindowLimiter:
    """Client-side guard so we never trip the 20/min media limit (and thus never burn a retry)."""

    def __init__(self, max_calls: int, period_s: float, *, clock: Callable[[], float] = time.monotonic,
                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> None:
        self._max, self._period, self._clock, self._sleep = max_calls, period_s, clock, sleep
        self._stamps: deque[float] = deque()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            while True:
                now = self._clock()
                while self._stamps and now - self._stamps[0] >= self._period:
                    self._stamps.popleft()
                if len(self._stamps) < self._max:
                    self._stamps.append(now)
                    return
                await self._sleep(self._period - (now - self._stamps[0]) + 0.01)


class FourthwallClient:
    def __init__(self, base_url: str, user: str, secret: str, *, hook: Hook | None = None,
                 transport: httpx.AsyncBaseTransport | None = None,
                 gcs_transport: httpx.AsyncBaseTransport | None = None,
                 limiter: SlidingWindowLimiter | None = None, max_429_retries: int = 3) -> None:
        self._api = httpx.AsyncClient(base_url=base_url, auth=(user, secret), timeout=30.0, transport=transport)
        self._gcs = httpx.AsyncClient(timeout=300.0, transport=gcs_transport)   # no auth: credentials must not go to GCS
        self._hook = hook
        self._media_limiter = limiter or SlidingWindowLimiter(20, 60.0)
        self._max_429 = max_429_retries

    async def aclose(self) -> None:
        await self._api.aclose()
        await self._gcs.aclose()

    async def __aenter__(self) -> "FourthwallClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    # ------------------------------------------------------------------ plumbing
    async def _call(self, method: str, path: str, *, event: str, json: Any = None, retry_5xx: bool = False) -> Any:
        attempt = 0
        while True:
            t0 = time.monotonic()
            resp = await self._api.request(method, path, json=json)
            if self._hook:
                await self._hook({
                    "event_type": event, "http_method": method, "url": str(resp.request.url),
                    "status_code": resp.status_code, "duration_ms": int((time.monotonic() - t0) * 1000),
                    "payload": {"request": json, "response": _clip(resp)},
                })
            if resp.status_code == 429 and attempt < self._max_429:
                attempt += 1
                wait = _retry_after(resp, default=2.0 * attempt)
                await asyncio.sleep(wait)
                continue
            if resp.status_code >= 500 and retry_5xx and attempt < 2:
                attempt += 1
                await asyncio.sleep(1.5 * attempt)
                continue
            if resp.is_success:
                return resp.json() if resp.content else None
            raise _error_from(resp)

    # ------------------------------------------------------------------ media
    async def request_upload_url(self, file_name: str, content_type: str, size: int) -> dict[str, str]:
        await self._media_limiter.acquire()
        return await self._call("POST", "/open-api/v1.0/media/upload-url", event="media.upload_url",
                                json={"fileName": file_name, "contentType": content_type, "size": size})

    async def put_to_storage(self, upload_url: str, data: bytes, content_type: str, size: int) -> None:
        if len(data) != size:
            raise FourthwallError(f"internal: size {size} != len(data) {len(data)}")
        t0 = time.monotonic()
        resp = await self._gcs.put(upload_url, content=data, headers={
            "Content-Type": content_type, "x-goog-content-length-range": f"0,{size}"})
        if self._hook:
            await self._hook({"event_type": "media.gcs_put", "http_method": "PUT",
                              "url": upload_url.split("?")[0], "status_code": resp.status_code,
                              "duration_ms": int((time.monotonic() - t0) * 1000),
                              "payload": {"bytes": size, "response": resp.text[:300]}})
        if not resp.is_success:
            raise FourthwallError(f"GCS upload failed with HTTP {resp.status_code}: {resp.text[:200]}",
                                  status=resp.status_code, code="GCS_UPLOAD_FAILED")

    async def register_image(self, file_url: str, width: int, height: int) -> dict[str, Any]:
        return await self._call("POST", "/open-api/v1.0/media/images", event="media.register",
                                json={"fileUrl": file_url, "width": width, "height": height})

    async def upload_image(self, path: Path) -> dict[str, Any]:
        """3-step upload. Returns the registered image dict (its \`id\` is the imageId)."""
        content_type = _content_type(path)
        data = await asyncio.to_thread(path.read_bytes)
        width, height = await asyncio.to_thread(_pixel_size, path)
        slot = await self.request_upload_url(path.name, content_type, len(data))
        await self.put_to_storage(slot["uploadUrl"], data, content_type, len(data))
        return await self.register_image(slot["fileUrl"], width, height)

    # ------------------------------------------------------------------ products
    async def list_product_templates(self) -> Any:
        return await self._call("GET", "/open-api/v1.0/product-templates", event="templates.list", retry_5xx=True)

    async def create_design_product(self, *, template_id: str, name: str, description: str,
                                    regions: list[dict[str, str]], publish_on_create: bool = False,
                                    profit_margin: float | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"type": "design", "productTemplateId": template_id, "name": name,
                                "description": description, "regions": regions, "publishOnCreate": publish_on_create}
        if profit_margin is not None:
            body["profitMargin"] = profit_margin
        # POST is not retried on 5xx: the product may exist already and a retry would duplicate it.
        return await self._call("POST", "/open-api/v1.0/products", event="product.create", json=body)

    async def get_product(self, product_id: str) -> dict[str, Any]:
        return await self._call("GET", f"/open-api/v1.0/products/{product_id}", event="product.get", retry_5xx=True)

    async def set_state(self, product_id: str, state: str) -> dict[str, Any]:
        if state not in ("PUBLIC", "HIDDEN"):
            raise ValueError("state must be PUBLIC or HIDDEN")
        return await self._call("PUT", f"/open-api/v1.0/products/{product_id}/state", event="product.state",
                                json={"state": state}, retry_5xx=True)


# --------------------------------------------------------------------------- helpers
def _content_type(path: Path) -> str:
    return {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
            ".pdf": "application/pdf", ".bmp": "image/bmp", ".mp4": "video/mp4",
            ".svg": "image/svg+xml"}.get(path.suffix.lower(), "application/octet-stream")


def _pixel_size(path: Path) -> tuple[int, int]:
    try:
        with Image.open(path) as im:
            return im.width, im.height
    except Exception:
        return 1, 1          # non-raster file (PDF/MP4): let Fourthwall decide whether it accepts the type


def _clip(resp: httpx.Response, limit: int = 1500) -> Any:
    try:
        text = resp.text
    except Exception:
        return None
    return text[:limit]


def _retry_after(resp: httpx.Response, default: float) -> float:
    try:
        return min(60.0, max(0.0, float(resp.headers.get("Retry-After", default))))
    except ValueError:
        return default


def _error_from(resp: httpx.Response) -> FourthwallError:
    try:
        body = resp.json()
    except ValueError:
        body = {"raw": resp.text[:300]}
    code = body.get("code") if isinstance(body, dict) else None
    msg = f"Fourthwall HTTP {resp.status_code} {code or ''} on {resp.request.method} {resp.request.url.path}".strip()
    if code in ("UNSUPPORTED_MEDIA_TYPE_ERROR", "UNSUPPORTED_ASSET_TYPE_ERROR"):
        supported = body.get("supportedMediaTypes") or []
        return UnsupportedMedia(msg, supported=list(supported), status=resp.status_code, code=code, body=body)
    return FourthwallError(msg, status=resp.status_code, code=code, body=body)
`,D=`"""Worker entry point.

  python -m pod_pipeline.worker --run-id <uuid>        run exactly one queued run (spawned by the MCP tool)
  python -m pod_pipeline.worker --drain [--scan]       recover stale runs, optionally scan inbox, then run
                                                       queued runs until none are left (systemd timer target)
  python -m pod_pipeline.worker --scan                 only register new inbox files
  python -m pod_pipeline.worker --list-templates       print Fourthwall productTemplateId values
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import uuid

from . import db
from .config import ConfigError, Settings
from .fourthwall import FourthwallClient, FourthwallError
from .ingest import scan_inbox
from .orchestrator import run_pipeline

log = logging.getLogger("pod.worker")


async def drain(settings: Settings, pool: db.Pool) -> list[dict]:
    done: list[dict] = []
    while True:
        batch = await asyncio.gather(*[run_pipeline(settings, pool, None, pid=os.getpid())
                                       for _ in range(settings.max_concurrency)])
        got = [r for r in batch if r]
        done.extend(got)
        if not got:
            return done


async def list_templates(settings: Settings) -> int:
    if not (settings.fw_api_user and settings.fw_api_secret):
        print("set FW_API_USER and FW_API_SECRET first", file=sys.stderr)
        return 2
    async with FourthwallClient(settings.fw_base_url, settings.fw_api_user, settings.fw_api_secret) as fw:
        try:
            print(json.dumps(await fw.list_product_templates(), indent=2))
        except FourthwallError as exc:
            print(f"Fourthwall error: {exc}", file=sys.stderr)
            return 1
    return 0


async def amain(args: argparse.Namespace) -> int:
    settings = Settings.from_env()
    if args.list_templates:
        return await list_templates(settings)
    pool = await db.create_pool(settings)
    try:
        if args.scan:
            n = await scan_inbox(settings, pool)
            log.info("inbox scan registered %d new asset(s)", n)
        if args.run_id:
            res = await run_pipeline(settings, pool, uuid.UUID(args.run_id), pid=os.getpid())
            if res is None:
                log.info("run %s was not claimable (already running or finished)", args.run_id)
                return 0
            log.info("run finished: %s", json.dumps(res))
            return 0 if res["ok"] else 1
        if args.drain:
            recovered = await db.recover_stale_runs(pool)
            if recovered:
                log.warning("re-queued %d stale run(s) whose worker process vanished", recovered)
            results = await drain(settings, pool)
            failed = [r for r in results if not r["ok"]]
            log.info("drained %d run(s), %d failed", len(results), len(failed))
            return 1 if failed else 0
        return 0
    finally:
        await pool.close()


def main() -> None:
    logging.basicConfig(level=os.environ.get("POD_LOG_LEVEL", "INFO"), stream=sys.stderr,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser(prog="pod_pipeline.worker")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--run-id")
    g.add_argument("--drain", action="store_true")
    g.add_argument("--list-templates", action="store_true")
    ap.add_argument("--scan", action="store_true", help="register new inbox files first")
    args = ap.parse_args()
    if not (args.run_id or args.drain or args.list_templates or args.scan):
        ap.error("nothing to do: pass --run-id, --drain, --scan or --list-templates")
    try:
        sys.exit(asyncio.run(amain(args)))
    except ConfigError as exc:
        print(f"configuration error: {exc}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
`,O=`"""MCP server for the pod pipeline.

Speaks JSON-RPC 2.0 (MCP tools/list + tools/call) on stdio and on
POD_MCP_HOST:POD_MCP_PORT. The three tools are the agent contract:

    list_pending_assets(account_id?)
    trigger_pipeline_job(asset_id, product_type)
    get_fourthwall_status(product_id)

trigger_pipeline_job inserts the orchestrator row and spawns
\`python -m pod_pipeline.worker --run-id\`. It does not run the craft steps
inside this process. STATE is the lazy handle tests patch.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import uuid
from typing import Any

from . import db
from .config import ConfigError, Settings
from .fourthwall import FourthwallClient, FourthwallError
from .routes import PRODUCT_TYPES

log = logging.getLogger("pod.mcp")

PROTOCOL = "2024-11-05"


class State:
    def __init__(self) -> None:
        self.settings: Settings | None = None
        self.pool: db.Pool | None = None
        self.lock: asyncio.Lock | None = None


STATE = State()


class ToolError(Exception):
    pass


TOOLS: list[dict[str, Any]] = [
    {
        "name": "list_pending_assets",
        "description": "Assets sitting in the inbox or stuck in queued/processing past POD stuck_after_s.",
        "inputSchema": {
            "type": "object",
            "properties": {"account_id": {"type": "integer"}},
            "additionalProperties": False,
        },
    },
    {
        "name": "trigger_pipeline_job",
        "description": "Enqueue one asset onto one product route and spawn an isolated worker process.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "asset_id": {"type": "integer"},
                "product_type": {"type": "string", "enum": list(PRODUCT_TYPES)},
            },
            "required": ["asset_id", "product_type"],
            "additionalProperties": False,
        },
    },
    {
        "name": "get_fourthwall_status",
        "description": "Local fourthwall_products row plus the live product, if Fourthwall has an id. product_id is our row id or the Fourthwall product id.",
        "inputSchema": {
            "type": "object",
            "properties": {"product_id": {"type": "string"}},
            "required": ["product_id"],
            "additionalProperties": False,
        },
    },
]


def dumps(obj: Any) -> str:
    return json.dumps(obj, default=str, separators=(",", ":"))


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (bytes, memoryview)):
        return None
    return value


def _settings() -> Settings:
    if STATE.settings is None:
        STATE.settings = Settings.from_env()
    return STATE.settings


async def _pool() -> db.Pool:
    if STATE.pool is None:
        STATE.pool = await db.create_pool(_settings())
    return STATE.pool


def _need_int(args: dict[str, Any], name: str, *, required: bool) -> int | None:
    if name not in args or args[name] is None:
        if required:
            raise ToolError(f"{name} is required")
        return None
    try:
        return int(args[name])
    except (TypeError, ValueError) as exc:
        raise ToolError(f"{name} must be an integer") from exc


async def list_pending_assets(arguments: dict[str, Any]) -> dict[str, Any]:
    settings = _settings()
    pool = await _pool()
    account_id = _need_int(arguments, "account_id", required=False)
    rows = await db.pending_assets(pool, stuck_after_s=settings.stuck_after_s, account_id=account_id)
    return {"assets": [_jsonable(r) for r in rows]}


async def _spawn_worker(settings: Settings, run_id: uuid.UUID) -> int:
    log_path = settings.job_logs / "mcp-spawn.log"
    await asyncio.to_thread(log_path.parent.mkdir, 0o750, True, True)
    handle = await asyncio.to_thread(open, log_path, "ab")
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pod_pipeline.worker", "--run-id", str(run_id),
            cwd=str(settings.root),
            env=os.environ.copy(),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=handle,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        handle.close()
    if proc.pid is None:
        raise ToolError(f"run {run_id} is queued but the worker pid was not assigned")
    return proc.pid


async def trigger_pipeline_job(arguments: dict[str, Any]) -> dict[str, Any]:
    asset_id = _need_int(arguments, "asset_id", required=True)
    product_type = str(arguments.get("product_type") or "")
    if product_type not in PRODUCT_TYPES:
        raise ToolError(f"product_type must be one of {', '.join(PRODUCT_TYPES)}")
    assert asset_id is not None
    settings = _settings()
    pool = await _pool()

    async def body() -> dict[str, Any]:
        asset = await db.get_asset(pool, asset_id)
        if asset is None:
            raise ToolError(f"asset {asset_id} does not exist")
        run_id, created = await db.enqueue_run(
            pool, account_id=asset["account_id"], asset_id=asset_id, product_type=product_type)
        await db.log_sync(
            pool, account_id=asset["account_id"], direction="inbound", channel="mcp",
            event_type="job.triggered", run_id=run_id,
            payload={"asset_id": asset_id, "product_type": product_type, "created": created})
        if not created:
            return {"run_id": str(run_id), "created": False, "spawned": False, "pid": None}
        try:
            pid = await _spawn_worker(settings, run_id)
        except OSError as exc:
            return {
                "run_id": str(run_id), "created": True, "spawned": False, "pid": None,
                "error": (
                    f"worker did not start ({exc}). The run stays queued; "
                    "pod-worker.timer will claim it."
                ),
            }
        return {"run_id": str(run_id), "created": True, "spawned": True, "pid": pid}

    if STATE.lock is None:
        return await body()
    async with STATE.lock:
        return await body()


async def get_fourthwall_status(arguments: dict[str, Any]) -> dict[str, Any]:
    product_id = str(arguments.get("product_id") or "").strip()
    if not product_id:
        raise ToolError("product_id is required")
    settings = _settings()
    pool = await _pool()
    row = await db.get_product_row(pool, product_id)
    if row is None:
        return {"found": False, "product_id": product_id}
    live: dict[str, Any] | None = None
    live_error: str | None = None
    fw_id = row.get("fw_product_id")
    if fw_id:
        creds = await db.get_fw_credentials(pool, settings, row["account_id"])
        if creds is None:
            live_error = "no Fourthwall credentials configured"
        else:
            try:
                async with FourthwallClient(settings.fw_base_url, creds[0], creds[1]) as fw:
                    live = await fw.get_product(fw_id)
            except FourthwallError as exc:
                live_error = str(exc)[:500]
    return {"found": True, "row": _jsonable(row), "live": live, "live_error": live_error}


async def _dispatch(name: str, arguments: Any) -> dict[str, Any]:
    if not isinstance(arguments, dict):
        raise ToolError("arguments must be an object")
    if name == "list_pending_assets":
        return await list_pending_assets(arguments)
    if name == "trigger_pipeline_job":
        return await trigger_pipeline_job(arguments)
    if name == "get_fourthwall_status":
        return await get_fourthwall_status(arguments)
    raise ToolError(f"unknown tool {name}")


def _ok(rid: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def _err(rid: Any, code: int, message: str) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}


async def handle_rpc(msg: Any) -> dict[str, Any] | None:
    if not isinstance(msg, dict):
        return _err(None, -32600, "invalid request")
    if "id" not in msg:
        return None
    rid = msg.get("id")
    method = msg.get("method")
    params = msg.get("params") or {}
    if not isinstance(params, dict):
        return _err(rid, -32602, "params must be an object")
    if method == "initialize":
        return _ok(rid, {
            "protocolVersion": PROTOCOL,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "pod-pipeline", "version": "1.0.0"},
        })
    if method == "ping":
        return _ok(rid, {})
    if method == "tools/list":
        return _ok(rid, {"tools": TOOLS})
    if method == "tools/call":
        name = str(params.get("name") or "")
        try:
            result = await _dispatch(name, params.get("arguments") or {})
        except ToolError as exc:
            return _ok(rid, {"content": [{"type": "text", "text": str(exc)}], "isError": True})
        except Exception as exc:
            log.exception("tool %s failed", name)
            text = f"{type(exc).__name__}: {exc}"[:500]
            return _ok(rid, {"content": [{"type": "text", "text": text}], "isError": True})
        return _ok(rid, {"content": [{"type": "text", "text": dumps(result)}], "isError": False})
    return _err(rid, -32601, f"method not found: {method}")


def _http(status: int, body: bytes) -> bytes:
    reason = {200: "OK", 400: "Bad Request", 405: "Method Not Allowed", 500: "Internal Server Error"}[status]
    head = (
        f"HTTP/1.1 {status} {reason}\\r\\n"
        "Content-Type: application/json\\r\\n"
        f"Content-Length: {len(body)}\\r\\n"
        "Connection: close\\r\\n\\r\\n"
    )
    return head.encode("ascii") + body


async def _read_http(reader: asyncio.StreamReader) -> dict[str, Any] | None:
    try:
        head = await asyncio.wait_for(reader.readuntil(b"\\r\\n\\r\\n"), 15)
    except (asyncio.IncompleteReadError, asyncio.LimitOverrunError, asyncio.TimeoutError):
        return None
    if len(head) > 16384:
        return None
    lines = head.decode("iso-8859-1", "replace").split("\\r\\n")
    parts = lines[0].split(" ")
    if len(parts) < 2:
        return None
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        headers[key.lower()] = value.strip()
    try:
        length = int(headers.get("content-length", "0") or 0)
    except ValueError:
        return None
    if length < 0 or length > 1_000_000:
        return None
    body = await reader.readexactly(length) if length else b""
    return {"method": parts[0], "path": parts[1].split("?", 1)[0], "body": body}


async def _client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        req = await _read_http(reader)
        if req is None:
            writer.write(_http(400, dumps(_err(None, -32700, "bad http")).encode()))
        elif req["method"] == "GET" and req["path"] == "/health":
            writer.write(_http(200, b'{"ok":true}'))
        elif req["method"] != "POST":
            writer.write(_http(405, b'{"error":"POST JSON-RPC only"}'))
        else:
            try:
                msg = json.loads(req["body"].decode("utf-8") if req["body"] else "null")
            except json.JSONDecodeError:
                writer.write(_http(400, dumps(_err(None, -32700, "parse error")).encode()))
            else:
                resp = await handle_rpc(msg)
                if resp is None:
                    writer.write(b"HTTP/1.1 204 No Content\\r\\nConnection: close\\r\\n\\r\\n")
                else:
                    writer.write(_http(200, dumps(resp).encode()))
        await writer.drain()
    except Exception as exc:
        log.exception("mcp connection failed")
        try:
            writer.write(_http(500, dumps(_err(None, -32603, str(exc)[:300])).encode()))
            await writer.drain()
        except Exception:
            pass
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass


async def serve_http() -> None:
    settings = _settings()
    server = await asyncio.start_server(_client, settings.mcp_host, settings.mcp_port)
    sockets = ", ".join(str(s.getsockname()) for s in server.sockets or [])
    log.info("mcp http listening on %s", sockets)
    async with server:
        await server.serve_forever()


def _frame(obj: dict[str, Any], framed: bool) -> bytes:
    data = dumps(obj).encode()
    if not framed:
        return data + b"\\n"
    return f"Content-Length: {len(data)}\\r\\n\\r\\n".encode("ascii") + data


async def serve_stdio() -> None:
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)
    framed: bool | None = None

    def write(data: bytes) -> None:
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()

    while True:
        peek = await reader.read(1)
        if not peek:
            return
        if peek == b"{":
            rest = await reader.readline()
            raw = peek + rest
            this_framed = False
        else:
            this_framed = True
            header = bytearray(peek)
            while b"\\r\\n\\r\\n" not in header and b"\\n\\n" not in header:
                more = await reader.read(1)
                if not more:
                    return
                header += more
                if len(header) > 16384:
                    return
            text = header.decode("iso-8859-1", "replace")
            sep = "\\r\\n\\r\\n" if "\\r\\n\\r\\n" in text else "\\n\\n"
            try:
                length = int(text.lower().split("content-length:", 1)[1].split("\\n", 1)[0].strip())
            except (IndexError, ValueError):
                await loop.run_in_executor(None, write, _frame(_err(None, -32700, "missing Content-Length"), True))
                return
            raw = await reader.readexactly(length)
        if framed is None:
            framed = this_framed
        try:
            msg = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            await loop.run_in_executor(None, write, _frame(_err(None, -32700, "parse error"), bool(framed)))
            continue
        resp = await handle_rpc(msg)
        if resp is not None:
            await loop.run_in_executor(None, write, _frame(resp, bool(framed)))


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("POD_LOG_LEVEL", "INFO"), stream=sys.stderr,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser(prog="pod_pipeline.mcp_server")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--http", action="store_true")
    mode.add_argument("--stdio", action="store_true")
    mode.add_argument("--call", nargs=2, metavar=("TOOL", "JSON"))
    args = ap.parse_args()
    try:
        if args.call:
            name, raw = args.call
            result = asyncio.run(_dispatch(name, json.loads(raw)))
            print(dumps(result))
            return
        asyncio.run(serve_stdio() if args.stdio else serve_http())
    except ConfigError as exc:
        print(f"configuration error: {exc}", file=sys.stderr)
        sys.exit(2)
    except ToolError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
`,k=`-- DeerFlow pod pipeline. Matches the SQL in pod_pipeline/db.py and tests/conftest.py.
-- Apply as the database owner (docker image user pod_app, a superuser inside that container):
--   docker exec -i pod-postgres psql -U pod_app -d pod -v ON_ERROR_STOP=1 < sql/schema.sql
--
-- Tenant insert (POD_CREDENTIAL_KEY is the pgp passphrase, never the Fourthwall secret):
--   INSERT INTO users_saas_accounts
--     (display_name, tenant_token_hash, sync_domain, fourthwall_api_user, fourthwall_api_secret_enc)
--   VALUES (
--     'Shop', encode(sha256('rotate-me'), 'hex'), 'shop.example',
--     'api-user', pgp_sym_encrypt('api-secret', 'the POD_CREDENTIAL_KEY value')
--   );

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE OR REPLACE FUNCTION pod_touch_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

CREATE TABLE IF NOT EXISTS users_saas_accounts (
    id                          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    display_name                text NOT NULL,
    tenant_token_hash           text NOT NULL,
    sync_domain                 text,
    fourthwall_api_user         text,
    fourthwall_api_secret_enc   bytea,
    auto_publish                boolean NOT NULL DEFAULT false,
    status                      text NOT NULL DEFAULT 'active',
    created_at                  timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT users_saas_accounts_token_len CHECK (char_length(tenant_token_hash) = 64),
    CONSTRAINT users_saas_accounts_status CHECK (status IN ('active', 'revoked')),
    CONSTRAINT users_saas_accounts_domain CHECK (
        sync_domain IS NULL OR sync_domain ~ '^[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'
    )
);

CREATE UNIQUE INDEX IF NOT EXISTS users_saas_accounts_token_idx
    ON users_saas_accounts (tenant_token_hash);

CREATE UNIQUE INDEX IF NOT EXISTS users_saas_accounts_domain_idx
    ON users_saas_accounts (sync_domain)
    WHERE sync_domain IS NOT NULL AND status = 'active';

CREATE TABLE IF NOT EXISTS ingested_assets (
    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    account_id          bigint NOT NULL REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,
    source_kind         text NOT NULL DEFAULT 'directory',
    source_path         text NOT NULL,
    original_filename   text NOT NULL,
    sha256              text NOT NULL,
    byte_size           bigint NOT NULL,
    mime_type           text,
    width_px            integer,
    height_px           integer,
    source_dpi          integer,
    color_space         text NOT NULL DEFAULT 'unknown',
    has_alpha           boolean,
    status              text NOT NULL DEFAULT 'pending',
    trace_state         text NOT NULL DEFAULT 'pending',
    trace_bounds        jsonb,
    created_at          timestamptz NOT NULL DEFAULT now(),
    updated_at          timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ingested_assets_sha CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    CONSTRAINT ingested_assets_size CHECK (byte_size > 0),
    CONSTRAINT ingested_assets_kind CHECK (source_kind IN ('directory', 'webhook')),
    CONSTRAINT ingested_assets_dims CHECK (
        (width_px IS NULL OR width_px > 0) AND (height_px IS NULL OR height_px > 0)
    ),
    CONSTRAINT ingested_assets_dpi CHECK (source_dpi IS NULL OR source_dpi > 0),
    CONSTRAINT ingested_assets_status CHECK (
        status IN ('pending', 'queued', 'processing', 'processed', 'failed', 'quarantined')
    ),
    CONSTRAINT ingested_assets_trace CHECK (
        trace_state IN ('pending', 'tracing', 'traced', 'raster_fallback', 'trace_failed')
    )
);

CREATE UNIQUE INDEX IF NOT EXISTS ingested_assets_account_sha_idx
    ON ingested_assets (account_id, sha256);

CREATE INDEX IF NOT EXISTS ingested_assets_status_updated_idx
    ON ingested_assets (status, updated_at);

CREATE INDEX IF NOT EXISTS ingested_assets_source_path_idx
    ON ingested_assets (source_path);

DROP TRIGGER IF EXISTS ingested_assets_touch ON ingested_assets;
CREATE TRIGGER ingested_assets_touch
    BEFORE UPDATE ON ingested_assets
    FOR EACH ROW EXECUTE FUNCTION pod_touch_updated_at();

CREATE TABLE IF NOT EXISTS processing_jobs (
    id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id          uuid NOT NULL,
    account_id      bigint NOT NULL REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,
    asset_id        bigint NOT NULL REFERENCES ingested_assets (id) ON DELETE RESTRICT,
    product_type    text NOT NULL,
    module          text NOT NULL,
    step_name       text NOT NULL,
    step_index      integer NOT NULL,
    attempt         integer NOT NULL DEFAULT 1,
    fallback_tier   integer NOT NULL DEFAULT 0,
    status          text NOT NULL,
    pid             integer,
    argv            text[],
    exit_code       integer,
    error_digest    text,
    log_path        text,
    output_path     text,
    started_at      timestamptz,
    finished_at     timestamptz,
    CONSTRAINT processing_jobs_product CHECK (
        product_type IN ('apparel', 'knitwear', 'accessories', 'odd_3d', 'stationery')
    ),
    CONSTRAINT processing_jobs_module CHECK (
        module IN ('orchestrator', 'vectorcraft', 'photocraft', 'designcraft', 'effectcraft', 'filmcraft')
    ),
    CONSTRAINT processing_jobs_status CHECK (status IN ('queued', 'running', 'succeeded', 'failed')),
    CONSTRAINT processing_jobs_attempt CHECK (attempt >= 1),
    CONSTRAINT processing_jobs_tier CHECK (fallback_tier >= 0),
    CONSTRAINT processing_jobs_step CHECK (step_index >= 0),
    CONSTRAINT processing_jobs_time_order CHECK (
        finished_at IS NULL OR started_at IS NULL OR finished_at >= started_at
    ),
    CONSTRAINT processing_jobs_digest_budget CHECK (
        error_digest IS NULL OR char_length(error_digest) <= 8000
    )
);

-- One live orchestrator run per asset + product. enqueue_run depends on this raising unique_violation.
CREATE UNIQUE INDEX IF NOT EXISTS processing_jobs_one_live_run
    ON processing_jobs (asset_id, product_type)
    WHERE module = 'orchestrator' AND status IN ('queued', 'running');

CREATE INDEX IF NOT EXISTS processing_jobs_run_idx
    ON processing_jobs (run_id);

CREATE INDEX IF NOT EXISTS processing_jobs_queued_idx
    ON processing_jobs (id)
    WHERE module = 'orchestrator' AND status = 'queued';

CREATE TABLE IF NOT EXISTS fourthwall_products (
    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    account_id          bigint NOT NULL REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,
    asset_id            bigint NOT NULL REFERENCES ingested_assets (id) ON DELETE RESTRICT,
    run_id              uuid,
    product_type        text NOT NULL,
    fw_template_id      text,
    media_id            text,
    media_file_url      text,
    fw_product_id       text,
    fw_slug             text,
    variants            jsonb NOT NULL DEFAULT '[]'::jsonb,
    skus                text[] NOT NULL DEFAULT '{}',
    publish_state       text NOT NULL DEFAULT 'draft',
    last_error          text,
    published_at        timestamptz,
    updated_at          timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT fourthwall_products_natural UNIQUE (account_id, asset_id, product_type),
    CONSTRAINT fourthwall_products_type CHECK (
        product_type IN ('apparel', 'knitwear', 'accessories', 'odd_3d', 'stationery')
    ),
    CONSTRAINT fourthwall_products_state CHECK (
        publish_state IN ('draft', 'processing', 'active', 'failed', 'needs_manual_upload')
    )
);

CREATE INDEX IF NOT EXISTS fourthwall_products_fw_product_idx
    ON fourthwall_products (fw_product_id)
    WHERE fw_product_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS fourthwall_products_media_idx
    ON fourthwall_products (media_id)
    WHERE media_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS fourthwall_products_state_idx
    ON fourthwall_products (publish_state);

DROP TRIGGER IF EXISTS fourthwall_products_touch ON fourthwall_products;
CREATE TRIGGER fourthwall_products_touch
    BEFORE UPDATE ON fourthwall_products
    FOR EACH ROW EXECUTE FUNCTION pod_touch_updated_at();

CREATE TABLE IF NOT EXISTS agent_sync_logs (
    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    account_id          bigint REFERENCES users_saas_accounts (id) ON DELETE RESTRICT,
    direction           text NOT NULL,
    channel             text NOT NULL,
    event_type          text NOT NULL,
    external_event_id   text,
    http_method         text,
    url                 text,
    status_code         integer,
    success             boolean,
    duration_ms         integer,
    payload             jsonb,
    run_id              uuid,
    fw_product_row_id   bigint REFERENCES fourthwall_products (id) ON DELETE RESTRICT,
    created_at          timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT agent_sync_logs_direction CHECK (direction IN ('inbound', 'outbound')),
    CONSTRAINT agent_sync_logs_duration CHECK (duration_ms IS NULL OR duration_ms >= 0),
    CONSTRAINT agent_sync_logs_payload_budget CHECK (
        payload IS NULL OR octet_length(payload::text) <= 32768
    )
);

-- log_sync uses ON CONFLICT DO NOTHING. Webhook retries share external_event_id; null ids never collide.
CREATE UNIQUE INDEX IF NOT EXISTS agent_sync_logs_external_event_idx
    ON agent_sync_logs (external_event_id)
    WHERE external_event_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS agent_sync_logs_account_idx
    ON agent_sync_logs (account_id, id DESC);

CREATE INDEX IF NOT EXISTS agent_sync_logs_run_idx
    ON agent_sync_logs (run_id)
    WHERE run_id IS NOT NULL;

COMMIT;
`,A=`{
  "apparel": {
    "fourthwall_template_id": "REPLACE_WITH_TEMPLATE_ID",
    "regions": ["front"],
    "profit_margin": 0.4
  },
  "knitwear": {
    "fourthwall_template_id": "REPLACE_WITH_TEMPLATE_ID",
    "regions": ["front"],
    "palette_limit": 6,
    "knit_grid": "112x140"
  },
  "accessories": {
    "fourthwall_template_id": "REPLACE_WITH_TEMPLATE_ID",
    "regions": ["front"],
    "template": "fourthwall_crossbody_v1",
    "care_text": "100% Polyester"
  },
  "odd_3d": {
    "fourthwall_template_id": "REPLACE_WITH_TEMPLATE_ID",
    "regions": ["front"],
    "bleed_in": "0.25"
  },
  "stationery": {
    "fourthwall_template_id": "REPLACE_WITH_TEMPLATE_ID",
    "regions": ["front"],
    "cover_template": "notebook_cover_template",
    "reel_template": "reel_promo_9_16",
    "reel_preset": "tiktok_1080p"
  }
}
`,j=`# systemd EnvironmentFile. Do not quote values. setup-pipeline.sh replaces the tokens.
POD_ROOT=/opt/pod-pipeline
PYTHONPATH=/opt/pod-pipeline
DATABASE_URL=postgresql://pod_app:__DB_PASS__@127.0.0.1:5432/pod
POD_DB_PASS=__DB_PASS__
POD_CREDENTIAL_KEY=__CRED_KEY__
FW_BASE_URL=https://api.fourthwall.com
FW_API_USER=
FW_API_SECRET=
POD_USE_DOCKER=0
POD_DOCKER_IMAGE=pod-craft-runner:latest
POD_DOCKER_MEMORY=2g
POD_DOCKER_CPUS=1.5
POD_DOCKER_CPU_SHARES=256
POD_NICE_LEVEL=10
POD_MAX_CONCURRENCY=2
POD_STEP_TIMEOUT_S=900
POD_FALLBACK_RASTER_DPI=600
POD_MCP_HOST=127.0.0.1
POD_MCP_PORT=8765
POD_LOG_LEVEL=INFO
`,M=`asyncpg>=0.29.0
httpx>=0.27.0
Pillow>=10.4.0
`,N=`#!/usr/bin/env bash
# Install the DeerFlow pod pipeline onto a Debian/Ubuntu VPS.
# The tree must already be at /opt/pod-pipeline (this script lives in deploy/).
# Re-running is safe: env, products.json, and vendor CLIs already in bin/ are kept.
set -euo pipefail
trap 'echo "setup-pipeline.sh failed at line $LINENO" >&2' ERR
umask 027

ROOT="\${POD_ROOT:-/opt/pod-pipeline}"
APP_USER="\${POD_USER:-pod}"
APP_GROUP="\${POD_GROUP:-pod}"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "setup-pipeline.sh must run as root" >&2
  exit 1
fi
if [[ ! -f "$ROOT/sql/schema.sql" || ! -f "$ROOT/deploy/compose.yml" ]]; then
  echo "expected the pipeline tree at $ROOT" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \\
  ca-certificates curl \\
  python3 python3-venv python3-pip \\
  imagemagick potrace ghostscript ffmpeg \\
  docker.io docker-compose-v2

if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  systemctl enable --now docker
fi
if ! docker info >/dev/null 2>&1; then
  echo "the docker daemon is not running" >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "docker compose v2 is required" >&2
  exit 1
fi

if ! id -u "$APP_USER" >/dev/null 2>&1; then
  useradd --system --create-home --home-dir "$ROOT" --shell /usr/sbin/nologin "$APP_USER"
fi
if getent group docker >/dev/null 2>&1; then
  usermod -aG docker "$APP_USER"
fi

install -d -o "$APP_USER" -g "$APP_GROUP" -m 0750 \\
  "$ROOT/bin" \\
  "$ROOT/config" \\
  "$ROOT/data/inbox" \\
  "$ROOT/sandbox" \\
  "$ROOT/build" \\
  "$ROOT/logs/jobs" \\
  "$ROOT/sql" \\
  "$ROOT/deploy"

if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  python3 -m venv "$ROOT/.venv"
fi
"$ROOT/.venv/bin/pip" install --disable-pip-version-check -r "$ROOT/requirements.txt"

for tool in vectorcraft-cli photocraft-cli designcraft-cli effectcraft-cli filmcraft-cli; do
  if [[ ! -e "$ROOT/bin/$tool" ]]; then
    install -m 0755 "$ROOT/deploy/craft-bin/$tool" "$ROOT/bin/$tool"
  fi
done

if [[ ! -f "$ROOT/config/products.json" ]]; then
  echo "missing $ROOT/config/products.json" >&2
  exit 1
fi

if [[ ! -f "$ROOT/config/pipeline.env" ]]; then
  db_pass="$(python3 -c 'import secrets; print(secrets.token_hex(24))')"
  cred_key="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
  sed -e "s/__DB_PASS__/\${db_pass}/g" -e "s/__CRED_KEY__/\${cred_key}/g" \\
    "$ROOT/config/pipeline.env.example" > "$ROOT/config/pipeline.env"
  chmod 0640 "$ROOT/config/pipeline.env"
fi

set -a
# shellcheck disable=SC1091
. "$ROOT/config/pipeline.env"
set +a

if [[ -z "\${POD_DB_PASS:-}" || -z "\${DATABASE_URL:-}" ]]; then
  echo "pipeline.env is missing POD_DB_PASS or DATABASE_URL" >&2
  exit 1
fi

if python3 -c 'import socket,sys;s=socket.socket();s.settimeout(0.3);r=s.connect_ex(("127.0.0.1",5432));s.close();sys.exit(0 if r==0 else 1)' \\
  && ! docker ps --format '{{.Names}}' | grep -qx pod-postgres; then
  echo "127.0.0.1:5432 is in use and pod-postgres is not the listener" >&2
  exit 1
fi

docker build -t "\${POD_DOCKER_IMAGE:-pod-craft-runner:latest}" -f "$ROOT/deploy/Dockerfile" "$ROOT"
docker compose --env-file "$ROOT/config/pipeline.env" -f "$ROOT/deploy/compose.yml" up -d

ready=0
for _ in $(seq 1 40); do
  status="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{end}}' pod-postgres 2>/dev/null || true)"
  if [[ "$status" == "healthy" ]]; then
    ready=1
    break
  fi
  sleep 1
done
if [[ "$ready" -ne 1 ]]; then
  echo "pod-postgres did not become healthy" >&2
  docker logs --tail 80 pod-postgres >&2 || true
  exit 1
fi

docker exec -i pod-postgres psql -U pod_app -d pod -v ON_ERROR_STOP=1 < "$ROOT/sql/schema.sql"

if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  install -m 0644 "$ROOT/deploy/systemd/pod-mcp.service" /etc/systemd/system/pod-mcp.service
  install -m 0644 "$ROOT/deploy/systemd/pod-worker.service" /etc/systemd/system/pod-worker.service
  install -m 0644 "$ROOT/deploy/systemd/pod-worker.timer" /etc/systemd/system/pod-worker.timer
  systemctl daemon-reload
  systemctl enable --now pod-mcp.service pod-worker.timer
else
  echo "systemd is not running; start the MCP and the worker timer yourself" >&2
fi

chown -R "$APP_USER:$APP_GROUP" "$ROOT"
chmod 0640 "$ROOT/config/pipeline.env"

echo "pod pipeline ready at $ROOT"
echo "next: insert a users_saas_accounts row, then drop files in $ROOT/data/inbox/<account_id>/"
`,P=`name: pod-pipeline
services:
  postgres:
    image: postgres:16
    container_name: pod-postgres
    environment:
      POSTGRES_USER: pod_app
      POSTGRES_PASSWORD: \${POD_DB_PASS}
      POSTGRES_DB: pod
    ports:
      - "127.0.0.1:5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    mem_limit: 1g
    cpus: 0.75
    shm_size: 128mb
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U pod_app -d pod"]
      interval: 5s
      timeout: 3s
      retries: 20
volumes:
  pgdata:
`,F=`# Craft sandbox image. Build context is /opt/pod-pipeline.
# CLIs are the scripts in deploy/craft-bin until vendor binaries replace them.
FROM debian:bookworm-slim

RUN apt-get update \\
    && apt-get install -y --no-install-recommends \\
        ca-certificates imagemagick potrace ghostscript ffmpeg python3 \\
    && rm -rf /var/lib/apt/lists/* \\
    && useradd --system --uid 10001 --home-dir /tmp --shell /usr/sbin/nologin craft

COPY deploy/craft-bin/ /usr/local/bin/

USER 10001:10001
WORKDIR /tmp
`,I=`#!/usr/bin/env node
// stdio MCP bridge. DeerFlow speaks Content-Length frames (or one JSON object
// per line) on stdin. Each message is POSTed to the Python server and the
// response is written back as a Content-Length frame.
//
// Tools live in pod_pipeline/mcp_server.py:
//   list_pending_assets, trigger_pipeline_job, get_fourthwall_status
//
//   node deploy/mcp-stdio.mjs
//   POD_MCP_URL defaults to http://127.0.0.1:8765/

import { Buffer } from "node:buffer";

const url = process.env.POD_MCP_URL ?? "http://127.0.0.1:8765/";

function createReader(stream) {
  let buf = Buffer.alloc(0);
  let ended = false;
  /** @type {Array<() => void>} */
  const pending = [];

  stream.on("data", (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (pending.length) {
      const wake = pending.shift();
      if (wake) wake();
    }
  });
  stream.on("end", () => {
    ended = true;
    while (pending.length) {
      const wake = pending.shift();
      if (wake) wake();
    }
  });

  function wait() {
    return new Promise((resolve) => {
      pending.push(resolve);
    });
  }

  function take(n) {
    const out = Buffer.from(buf.subarray(0, n));
    buf = buf.subarray(n);
    return out;
  }

  async function fill(n) {
    while (buf.length < n) {
      if (ended) return false;
      await wait();
    }
    return true;
  }

  return {
    async readMessage() {
      if (!(await fill(1))) return null;
      if (buf[0] === 0x7b) {
        while (buf.indexOf(0x0a) < 0) {
          if (!(await fill(buf.length + 1))) return null;
        }
        const line = take(buf.indexOf(0x0a));
        take(1);
        return JSON.parse(line.toString("utf8"));
      }
      while (buf.indexOf("\\r\\n\\r\\n") < 0 && buf.indexOf("\\n\\n") < 0) {
        if (!(await fill(buf.length + 1))) return null;
      }
      let sep = buf.indexOf("\\r\\n\\r\\n");
      let sepLen = 4;
      if (sep < 0) {
        sep = buf.indexOf("\\n\\n");
        sepLen = 2;
      }
      const header = take(sep + sepLen).toString("utf8");
      const match = /content-length:\\s*(\\d+)/i.exec(header);
      if (!match) throw new Error("missing Content-Length");
      const n = Number(match[1]);
      if (!(await fill(n))) return null;
      return JSON.parse(take(n).toString("utf8"));
    },
  };
}

function writeFrame(obj) {
  const body = Buffer.from(JSON.stringify(obj));
  process.stdout.write(\`Content-Length: \${body.length}\\r\\n\\r\\n\`);
  process.stdout.write(body);
}

async function main() {
  const reader = createReader(process.stdin);
  for (;;) {
    const msg = await reader.readMessage();
    if (msg == null) return;
    /** @type {unknown} */
    let out;
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(msg),
      });
      if (res.status === 204) continue;
      out = await res.json();
    } catch (err) {
      out = {
        jsonrpc: "2.0",
        id: msg.id ?? null,
        error: { code: -32000, message: err instanceof Error ? err.message : "bridge failed" },
      };
    }
    if (msg.id === undefined) continue;
    writeFrame(out);
  }
}

main().catch((err) => {
  process.stderr.write(\`\${err instanceof Error ? err.stack : String(err)}\\n\`);
  process.exit(1);
});
`,L=`[Unit]
Description=DeerFlow pod pipeline MCP
After=docker.service network-online.target
Wants=docker.service network-online.target

[Service]
User=pod
Group=pod
SupplementaryGroups=docker
WorkingDirectory=/opt/pod-pipeline
EnvironmentFile=/opt/pod-pipeline/config/pipeline.env
ExecStart=/opt/pod-pipeline/.venv/bin/python -m pod_pipeline.mcp_server --http
Restart=on-failure
RestartSec=2
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
`,R=`[Unit]
Description=Drain DeerFlow pod pipeline runs
After=docker.service pod-mcp.service
Wants=docker.service

[Service]
Type=oneshot
User=pod
Group=pod
SupplementaryGroups=docker
WorkingDirectory=/opt/pod-pipeline
EnvironmentFile=/opt/pod-pipeline/config/pipeline.env
ExecStart=/opt/pod-pipeline/.venv/bin/python -m pod_pipeline.worker --drain --scan
NoNewPrivileges=true
`,z=`[Unit]
Description=Drain the DeerFlow pod pipeline every minute

[Timer]
OnBootSec=45
OnUnitActiveSec=60
AccuracySec=10
Persistent=true

[Install]
WantedBy=timers.target
`,se=`#!/bin/sh
echo "vectorcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner." >&2
exit 127
`,B=`#!/bin/sh
echo "photocraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner." >&2
exit 127
`,V=`#!/bin/sh
echo "designcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner." >&2
exit 127
`,H=`#!/bin/sh
echo "effectcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner." >&2
exit 127
`,U=`#!/bin/sh
echo "filmcraft-cli: vendor binary not installed. Replace this file and rebuild pod-craft-runner." >&2
exit 127
`,W=`from __future__ import annotations

import dataclasses
import json
import os
import re
import stat
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable

import asyncpg
import httpx
import pytest
import pytest_asyncio
from PIL import Image

from pod_pipeline import db, orchestrator
from pod_pipeline.config import Settings
from pod_pipeline.fourthwall import FourthwallClient

ROOT = Path(__file__).resolve().parent.parent
TEST_DB_URL = os.environ.get("TEST_DATABASE_URL", "postgresql://pod_app:devpass@127.0.0.1:5432/pod_test")
CRED_KEY = "test-credential-key-0123456789abcdef"
CRAFT_TOOLS = ("photocraft-cli", "vectorcraft-cli", "designcraft-cli", "effectcraft-cli", "filmcraft-cli")


def _admin(sql: str) -> None:
    subprocess.run(["su", "postgres", "-c", f'psql -v ON_ERROR_STOP=1 -q -c "{sql}"'], check=True, capture_output=True)


@pytest.fixture(scope="session", autouse=True)
def _database() -> None:
    m = re.match(r"postgresql://([^:]+):([^@]+)@([^:/]+):(\\d+)/(\\w+)", TEST_DB_URL)
    user, _pw, _h, _p, name = m.groups()           # type: ignore[union-attr]
    _admin(f"DROP DATABASE IF EXISTS {name}")
    _admin(f"CREATE DATABASE {name} OWNER {user}")
    env = {**os.environ, "PGPASSWORD": _pw}
    subprocess.run(["psql", TEST_DB_URL, "-v", "ON_ERROR_STOP=1", "-q", "-1", "-f", str(ROOT / "sql" / "schema.sql")],
                   check=True, capture_output=True, env=env)


@pytest.fixture
def stubs_env(tmp_path: Path) -> Path:
    """<root>/bin with launcher scripts for every Craft CLI -> tests/stubs/craft_stub.py."""
    bin_dir = tmp_path / "root" / "bin"
    bin_dir.mkdir(parents=True)
    for tool in CRAFT_TOOLS:
        launcher = bin_dir / tool
        launcher.write_text(f"#!{sys.executable}\\nimport runpy,sys\\nsys.path.insert(0, {str(ROOT / 'tests' / 'stubs')!r})\\n"
                            f"import craft_stub\\ncraft_stub.main()\\n")
        launcher.chmod(launcher.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return tmp_path / "root"


@pytest.fixture
def settings(stubs_env: Path) -> Settings:
    products = {
        "apparel": {"fourthwall_template_id": "pro_apparel"},
        "knitwear": {"fourthwall_template_id": "pro_knit", "knit_grid": "40x50", "palette_limit": 6},
        "accessories": {"fourthwall_template_id": "pro_acc"},
        "odd_3d": {"fourthwall_template_id": "pro_odd"},
        "stationery": {"fourthwall_template_id": "pro_stat"},
    }
    return Settings(root=stubs_env, database_url=TEST_DB_URL, credential_key=CRED_KEY, flush_poll_s=0.02,
                    inbox_settle_s=0, step_timeout_s=30, max_log_bytes=2 * 1024 * 1024, products=products)


@pytest_asyncio.fixture
async def pool(settings: Settings):
    p = await asyncpg.create_pool(TEST_DB_URL, min_size=1, max_size=6)
    await p.execute("TRUNCATE users_saas_accounts, ingested_assets, processing_jobs, fourthwall_products, "
                    "agent_sync_logs RESTART IDENTITY CASCADE")
    yield p
    await p.close()


@pytest_asyncio.fixture
async def account(pool: asyncpg.Pool) -> int:
    return await pool.fetchval(
        """INSERT INTO users_saas_accounts (display_name, tenant_token_hash, fourthwall_api_user, fourthwall_api_secret_enc)
           VALUES ('Test shop', repeat('a',64), 'apiuser', pgp_sym_encrypt('apisecret', $1)) RETURNING id""", CRED_KEY)


@pytest.fixture
def make_asset(settings: Settings, pool: asyncpg.Pool, account: int) -> Callable[..., Any]:
    from pod_pipeline.ingest import scan_inbox

    async def _make(name: str = "Cool_Design.png", size: tuple[int, int] = (200, 160), account_id: int | None = None) -> int:
        acct = account_id or account
        d = settings.inbox / str(acct)
        d.mkdir(parents=True, exist_ok=True)
        Image.new("RGBA", size, (255, 0, 0, 255)).save(d / name, "PNG")
        await scan_inbox(settings, pool)
        return await pool.fetchval("SELECT id FROM ingested_assets WHERE source_path=$1", str(d / name))

    return _make


class FakeFourthwall:
    """In-memory Fourthwall: api transport (Fourthwall host) + gcs transport (storage host), with call recording."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []
        self.gcs_puts: list[dict[str, Any]] = []
        self.auth_headers: list[str] = []
        self.reject_media_type = False
        self.fail_create_with: int | None = None
        self.products: dict[str, dict[str, Any]] = {}
        self._n = 0
        self.api = httpx.MockTransport(self._api)
        self.gcs = httpx.MockTransport(self._gcs)

    def count(self, method: str, path_prefix: str) -> int:
        return sum(1 for m, p in self.calls if m == method and p.startswith(path_prefix))

    def _api(self, req: httpx.Request) -> httpx.Response:
        path, method = req.url.path, req.method
        self.calls.append((method, path))
        self.auth_headers.append(req.headers.get("authorization", ""))
        body = json.loads(req.content) if req.content else None
        if path == "/open-api/v1.0/media/upload-url":
            if self.reject_media_type:
                return httpx.Response(406, json={"code": "UNSUPPORTED_MEDIA_TYPE_ERROR", "mediaType": body["contentType"],
                                                 "supportedMediaTypes": ["image/png", "image/jpeg"]})
            assert body["size"] > 0 and body["fileName"] and body["contentType"]
            self._n += 1
            return httpx.Response(201, json={"uploadUrl": f"https://storage.fake.test/up/{self._n}?sig=abc",
                                             "fileUrl": f"https://cdn.fake.test/media/{self._n}/{body['fileName']}"})
        if path == "/open-api/v1.0/media/images":
            return httpx.Response(200, json={"id": f"img_{self._n}", "uri": body["fileUrl"],
                                             "width": body["width"], "height": body["height"]})
        if path == "/open-api/v1.0/products" and method == "POST":
            if self.fail_create_with:
                return httpx.Response(self.fail_create_with, json={"code": "SOMETHING_BROKE"})
            assert body["type"] == "design" and body["regions"][0]["imageId"].startswith("img_")
            pid = f"off_{len(self.products) + 1}"
            self.products[pid] = {"id": pid, "name": body["name"], "slug": body["name"].lower().replace(" ", "-"),
                                  "access": {"type": "HIDDEN"}, "state": {"type": "AVAILABLE"},
                                  "variants": [{"id": "v1", "sku": f"SKU-{pid}-S"}, {"id": "v2", "sku": f"SKU-{pid}-M"}],
                                  "images": [{"id": "i"}], "updatedAt": "2026-11-04T10:00:00Z"}
            return httpx.Response(201, json={"productId": pid, "customizationId": "cus_1", "images": []})
        m = re.fullmatch(r"/open-api/v1.0/products/([^/]+)(/state)?", path)
        if m and m.group(1) in self.products:
            prod = self.products[m.group(1)]
            if method == "GET":
                return httpx.Response(200, json=prod)
            if method == "PUT" and m.group(2):
                prod["access"] = {"type": body["state"]}
                return httpx.Response(200, json=prod)
        return httpx.Response(404, json={"code": "NOT_FOUND"})

    def _gcs(self, req: httpx.Request) -> httpx.Response:
        self.gcs_puts.append({"headers": dict(req.headers), "len": len(req.content), "url": str(req.url)})
        return httpx.Response(200)


@pytest.fixture
def fake_fw(monkeypatch: pytest.MonkeyPatch) -> FakeFourthwall:
    fw = FakeFourthwall()

    class Patched(FourthwallClient):
        def __init__(self, base_url: str, user: str, secret: str, **kw: Any) -> None:
            super().__init__(base_url, user, secret, transport=fw.api, gcs_transport=fw.gcs, **kw)

    monkeypatch.setattr(orchestrator, "FourthwallClient", Patched)
    from pod_pipeline import mcp_server
    monkeypatch.setattr(mcp_server, "FourthwallClient", Patched)
    return fw


@pytest.fixture
def with_state(settings: Settings, pool: asyncpg.Pool, monkeypatch: pytest.MonkeyPatch):
    """Point the MCP module's lazy state at the test settings/pool."""
    from pod_pipeline import mcp_server
    monkeypatch.setattr(mcp_server.STATE, "settings", settings)
    monkeypatch.setattr(mcp_server.STATE, "pool", pool)
    monkeypatch.setattr(mcp_server.STATE, "lock", None)
    return mcp_server


def replace(settings: Settings, **kw: Any) -> Settings:
    return dataclasses.replace(settings, **kw)
`,G=`"""Stand-in for the five Craft CLIs. Invoked through launcher scripts named photocraft-cli, vectorcraft-cli, ...
It checks that the orchestrator passes the flags the spec requires, then writes plausible output files.

Behaviour switches (environment variables):
  STUB_VECTOR_EXIT=<n>     vectorcraft-cli exits n after printing an error
  STUB_SLEEP=<seconds>     sleep before doing anything (timeout tests); also leaves a background child behind
  STUB_SPAM_MB=<n>         print ~n MB of progress noise, a few error lines mixed in
  STUB_FLAKY_MARK=<path>   first call exits 137 (OOM-style) and creates the marker; later calls succeed
  STUB_KNIT=ok|antialias|rgba32   what kind of BMP designcraft stitch_matrix writes
"""
import os
import sys
import time
from pathlib import Path

from PIL import Image, ImageDraw

PDF = b"%PDF-1.4\\n1 0 obj<<>>endobj\\ntrailer<<>>\\n%%EOF\\n"


def args_to_dict(argv):
    out, i = {}, 0
    while i < len(argv):
        tok = argv[i]
        if tok.startswith("--"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("--"):
                out.setdefault(tok, []).append(argv[i + 1])
                i += 2
                continue
            out.setdefault(tok, []).append(True)
        i += 1
    return out


def need(a, flag, value=None):
    if flag not in a:
        print(f"ERROR: stub requires {flag}", file=sys.stderr)
        sys.exit(64)
    if value is not None and a[flag][0] != value:
        print(f"ERROR: stub requires {flag} {value}, got {a[flag][0]}", file=sys.stderr)
        sys.exit(64)
    return a[flag][0]


def art(path, size=(120, 90), alpha=True):
    im = Image.new("RGBA", size, (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse((10, 10, size[0] - 10, size[1] - 10), fill=(200, 30, 30, 255))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, "PNG")


def main():
    tool = os.path.basename(sys.argv[0])
    a = args_to_dict(sys.argv[1:])
    if os.environ.get("STUB_SLEEP"):
        os.system("sleep 120 &")                      # grandchild that must be killed with the group
        time.sleep(float(os.environ["STUB_SLEEP"]))
    mark = os.environ.get("STUB_FLAKY_MARK")
    if mark and not os.path.exists(mark):
        Path(mark).write_text("x")
        print("ERROR: simulated OOM kill", file=sys.stderr)
        sys.exit(137)
    mb = float(os.environ.get("STUB_SPAM_MB", "0"))
    if mb:
        line = "progress tile 000000 of 999999 ........................................................\\n"
        for i in range(int(mb * 1024 * 1024 / len(line))):
            sys.stdout.write(line.replace("000000", f"{i:06d}"))
            if i % 50000 == 0:
                sys.stdout.write(f"WARNING: slow tile {i}\\n")

    if tool == "vectorcraft-cli":
        assert sys.argv[1] == "trace", "vectorcraft-cli needs the 'trace' subcommand"
        code = int(os.environ.get("STUB_VECTOR_EXIT", "0"))
        if code:
            print("ERROR: trace failed: path simplification diverged", file=sys.stderr)
            sys.exit(code)
        need(a, "--input")
        Path(need(a, "--svg-out")).write_text("<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10'/>")
        Path(need(a, "--pdf-out")).write_bytes(PDF)
    elif tool == "photocraft-cli":
        out_dir = Path(need(a, "--out-dir"))
        need(a, "--input")
        if a.get("--trim-alpha", ["false"])[0] == "true":
            need(a, "--target-dpi", "300")
            need(a, "--color-profile", "srgb")
            need(a, "--dimensions", "14x16in")
            art(out_dir / "trimmed.png")
        else:
            need(a, "--target-dpi")
            art(out_dir / "raster_600dpi.png")
    elif tool == "effectcraft-cli":
        out = Path(need(a, "--output"))
        out.parent.mkdir(parents=True, exist_ok=True)
        if "--filter" in a:
            need(a, "--filter", "vintage_screen_300")
            art(out)
        else:
            need(a, "--cylinder-taper")
            need(a, "--input")
            out.write_bytes(PDF)
    elif tool == "designcraft-cli":
        out = Path(need(a, "--output"))
        out.parent.mkdir(parents=True, exist_ok=True)
        if a.get("--mode", [""])[0] == "stitch_matrix":
            need(a, "--palette-limit")
            cols, rows = [int(x) for x in need(a, "--grid-scale").lower().split("x")]
            mode = os.environ.get("STUB_KNIT", "ok")
            if mode == "ok":
                im = Image.new("P", (cols, rows), 0)
                im.putpalette([200, 30, 30, 20, 20, 160, 240, 240, 240, 10, 10, 10] + [0] * (768 - 12))
                ImageDraw.Draw(im).rectangle((2, 2, cols // 2, rows // 2), fill=1)
                ImageDraw.Draw(im).rectangle((cols // 2, rows // 2, cols - 3, rows - 3), fill=2)
                im.save(out, "BMP")
            elif mode == "antialias":
                im = Image.new("RGB", (cols, rows))
                for x in range(cols):
                    for y in range(rows):
                        im.putpixel((x, y), ((x * 7) % 256, (y * 5) % 256, (x + y) % 256))
                im.save(out, "BMP")
            else:
                Image.new("RGBA", (cols, rows), (10, 10, 10, 128)).save(out, "BMP")
        elif a.get("--mode", [""])[0] == "wrap_tile":
            need(a, "--bleed", "0.25")
            need(a, "--input")
            out.write_bytes(PDF)
        elif "--template" in a:
            need(a, "--layer")
            need(a, "--embed")
            out.write_bytes(PDF)
        else:
            need(a, "--input")
            need(a, "--embed")
            out.write_bytes(PDF)
    elif tool == "filmcraft-cli":
        need(a, "--template")
        need(a, "--render-preset")
        Path(need(a, "--output")).write_bytes(b"\\x00\\x00\\x00\\x18ftypmp42\\x00\\x00\\x00\\x00mp42isom" + b"\\x00" * 64)
    else:
        print(f"unknown tool {tool}", file=sys.stderr)
        sys.exit(65)


if __name__ == "__main__":
    main()
`,K=`.venv
sandbox
build
logs
data
**/__pycache__
*.pyc
`,q=[{id:`package`,label:`Package`},{id:`sql`,label:`Schema`},{id:`config`,label:`Config`},{id:`deploy`,label:`Deploy`},{id:`tests`,label:`Tests`}],J=[{path:`pod_pipeline/__init__.py`,group:`package`,source:ie},{path:`pod_pipeline/config.py`,group:`package`,source:ae},{path:`pod_pipeline/db.py`,group:`package`,source:oe},{path:`pod_pipeline/ingest.py`,group:`package`,source:b},{path:`pod_pipeline/routes.py`,group:`package`,source:x},{path:`pod_pipeline/runner.py`,group:`package`,source:S},{path:`pod_pipeline/validators.py`,group:`package`,source:C},{path:`pod_pipeline/logfilter.py`,group:`package`,source:w},{path:`pod_pipeline/orchestrator.py`,group:`package`,source:T},{path:`pod_pipeline/fourthwall.py`,group:`package`,source:E},{path:`pod_pipeline/worker.py`,group:`package`,source:D},{path:`pod_pipeline/mcp_server.py`,group:`package`,source:O},{path:`sql/schema.sql`,group:`sql`,source:k},{path:`config/products.json`,group:`config`,source:A},{path:`config/pipeline.env.example`,group:`config`,source:j},{path:`requirements.txt`,group:`config`,source:M},{path:`deploy/setup-pipeline.sh`,group:`deploy`,source:N},{path:`deploy/compose.yml`,group:`deploy`,source:P},{path:`deploy/Dockerfile`,group:`deploy`,source:F},{path:`deploy/mcp-stdio.mjs`,group:`deploy`,source:I},{path:`deploy/systemd/pod-mcp.service`,group:`deploy`,source:L},{path:`deploy/systemd/pod-worker.service`,group:`deploy`,source:R},{path:`deploy/systemd/pod-worker.timer`,group:`deploy`,source:z},{path:`deploy/craft-bin/vectorcraft-cli`,group:`deploy`,source:se},{path:`deploy/craft-bin/photocraft-cli`,group:`deploy`,source:B},{path:`deploy/craft-bin/designcraft-cli`,group:`deploy`,source:V},{path:`deploy/craft-bin/effectcraft-cli`,group:`deploy`,source:H},{path:`deploy/craft-bin/filmcraft-cli`,group:`deploy`,source:U},{path:`.dockerignore`,group:`deploy`,source:K},{path:`tests/conftest.py`,group:`tests`,source:W},{path:`tests/stubs/craft_stub.py`,group:`tests`,source:G}];function Y(e){let t=J.find(t=>t.path===e);if(!t)throw Error(e);return t}async function ce(e){try{return await navigator.clipboard.writeText(e),!0}catch{try{let t=document.createElement(`textarea`);t.value=e,t.setAttribute(`readonly`,``),document.body.appendChild(t),t.select();let n=document.execCommand(`copy`);return t.remove(),n}catch{return!1}}}function le(e,t){let n=new Blob([t],{type:`text/plain;charset=utf-8`}),r=URL.createObjectURL(n),i=document.createElement(`a`);i.href=r,i.download=e,i.click(),URL.revokeObjectURL(r)}function X({text:e,label:t=`Copy`}){let[n,r]=(0,c.useState)(!1);return(0,v.jsxs)(`button`,{type:`button`,className:`inline-flex h-11 items-center gap-2 border border-fg/15 px-3 text-sm text-fg transition-colors duration-150 hover:border-brass hover:text-brass`,onClick:()=>{ce(e).then(e=>{e&&(r(!0),window.setTimeout(()=>r(!1),1400))})},children:[n?(0,v.jsx)(i,{className:`size-4`,"aria-hidden":`true`}):(0,v.jsx)(a,{className:`size-4`,"aria-hidden":`true`}),n?`Copied`:t]})}function Z({filename:e,text:t}){return(0,v.jsxs)(`button`,{type:`button`,className:`inline-flex h-11 items-center gap-2 border border-fg/15 px-3 text-sm text-fg transition-colors duration-150 hover:border-brass hover:text-brass`,onClick:()=>le(e,t),children:[(0,v.jsx)(o,{className:`size-4`,"aria-hidden":`true`}),`Download`]})}var ue=[`Place this tree at /opt/pod-pipeline on a Debian or Ubuntu VPS.`,`Edit config/products.json. fourthwall_template_id comes from python -m pod_pipeline.worker --list-templates. knit_grid must be the factory COLSxROWS, or the BMP validator rejects the file.`,`Run deploy/setup-pipeline.sh as root. It installs ImageMagick, Potrace, Ghostscript, ffmpeg, Docker, and a Postgres 16 container bound to 127.0.0.1:5432.`,`The script writes config/pipeline.env with a database password and POD_CREDENTIAL_KEY, applies sql/schema.sql, and enables pod-mcp plus a one-minute drain timer.`,`Insert a users_saas_accounts row. The Fourthwall secret is pgp_sym_encrypt'd with POD_CREDENTIAL_KEY. The comment at the top of schema.sql is the statement.`,`Drop settled files into data/inbox/<account_id>/. The drain scans, or the agent calls trigger_pipeline_job.`];function de({onOpen:e}){let t=Y(`deploy/setup-pipeline.sh`),n=Y(`sql/schema.sql`);return(0,v.jsxs)(`div`,{className:`flex flex-col gap-6`,children:[(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`h2`,{className:`text-xl font-medium`,children:`VPS playbook`}),(0,v.jsx)(`p`,{className:`mt-1 max-w-3xl text-sm text-pretty text-muted`,children:`The Python package is the pipeline. This script is the machine around it. Re-running the script keeps an existing env file and any Craft binary already in bin/.`})]}),(0,v.jsx)(`ol`,{className:`flex flex-col gap-3`,children:ue.map((e,t)=>(0,v.jsxs)(`li`,{className:`grid grid-cols-[2rem_1fr] gap-3`,children:[(0,v.jsx)(`span`,{className:`font-mono text-xs text-brass tabular-nums`,children:String(t+1).padStart(2,`0`)}),(0,v.jsx)(`p`,{className:`text-sm text-pretty`,children:e})]},e))}),(0,v.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,v.jsx)(`button`,{type:`button`,className:`h-11 border border-fg/15 px-3 text-sm hover:border-brass`,onClick:()=>e(`pod_pipeline/mcp_server.py`),children:`MCP server`}),(0,v.jsx)(`button`,{type:`button`,className:`h-11 border border-fg/15 px-3 text-sm hover:border-brass`,onClick:()=>e(`config/products.json`),children:`products.json`}),(0,v.jsx)(`button`,{type:`button`,className:`h-11 border border-fg/15 px-3 text-sm hover:border-brass`,onClick:()=>e(`deploy/compose.yml`),children:`compose.yml`})]}),(0,v.jsx)(Q,{title:t.path,source:t.source}),(0,v.jsx)(Q,{title:n.path,source:n.source})]})}function Q({title:e,source:t}){let n=e.split(`/`).pop()??e;return(0,v.jsxs)(`section`,{children:[(0,v.jsxs)(`div`,{className:`flex flex-wrap items-center justify-between gap-2`,children:[(0,v.jsx)(`h3`,{className:`font-mono text-sm`,children:e}),(0,v.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,v.jsx)(X,{text:t}),(0,v.jsx)(Z,{filename:n,text:t})]})]}),(0,v.jsx)(`pre`,{className:`mt-2 max-h-screen overflow-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg`,children:t})]})}function fe({family:e,onFamily:t}){return(0,v.jsxs)(`div`,{className:`flex flex-col gap-4`,children:[(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`h2`,{className:`text-xl font-medium`,children:`Fourthwall routes`}),(0,v.jsx)(`p`,{className:`mt-1 max-w-3xl text-sm text-pretty text-muted`,children:`routes.py is the only file that knows Craft flags. A flag change is one tuple, not a hunt through the orchestrator.`})]}),(0,v.jsx)(`div`,{className:`flex flex-col gap-3`,children:l.map(n=>{let r=n.id===e;return(0,v.jsxs)(`section`,{className:`border `+(r?`border-brass`:`border-fg/10`),children:[(0,v.jsxs)(`button`,{type:`button`,className:`flex w-full flex-col gap-1 p-3 text-left md:flex-row md:items-baseline md:justify-between`,"aria-expanded":r,onClick:()=>t(n.id),children:[(0,v.jsx)(`span`,{className:`text-base font-medium`,children:n.name}),(0,v.jsx)(`span`,{className:`text-sm text-muted`,children:n.focus})]}),r?(0,v.jsxs)(`div`,{className:`flex flex-col gap-3 border-t border-fg/10 p-3`,children:[(0,v.jsx)(`p`,{className:`text-sm`,children:n.blanks}),(0,v.jsxs)(`p`,{className:`font-mono text-xs text-muted`,children:[`trace `,n.traceExtra?`+ ${n.traceExtra}`:`with no extra flags`,` · upload `,n.upload]}),(0,v.jsx)(`ol`,{className:`flex flex-col gap-3`,children:n.steps.map((e,t)=>(0,v.jsxs)(`li`,{children:[(0,v.jsxs)(`p`,{className:`text-sm`,children:[(0,v.jsx)(`span`,{className:`font-mono text-xs text-brass`,children:String(t+1).padStart(2,`0`)}),` `,e.name,(0,v.jsxs)(`span`,{className:`text-muted`,children:[` · `,e.module]}),e.validator?(0,v.jsxs)(`span`,{className:`text-muted`,children:[` · `,e.validator]}):null,e.timeout?(0,v.jsxs)(`span`,{className:`text-muted`,children:[` · timeout `,e.timeout]}):null]}),(0,v.jsx)(`p`,{className:`mt-1 overflow-x-auto font-mono text-xs break-all text-fg md:break-normal`,children:e.command}),(0,v.jsx)(`p`,{className:`mt-1 font-mono text-xs text-muted`,children:e.output})]},e.name))}),n.note?(0,v.jsx)(`p`,{className:`text-sm text-pretty text-muted`,children:n.note}):null]}):null]},n.id)})}),(0,v.jsxs)(`section`,{children:[(0,v.jsx)(`h3`,{className:`text-base font-medium`,children:`Assumptions the route file already marks`}),(0,v.jsx)(`ul`,{className:`mt-2 flex flex-col gap-2`,children:u.map(e=>(0,v.jsx)(`li`,{className:`border-l border-brass pl-3 text-sm text-pretty text-muted`,children:e},e))})]})]})}var pe=[{name:`memory`,value:`2g, and memory-swap equal to memory so the container cannot swap`,where:`POD_DOCKER_MEMORY`},{name:`cpu`,value:`1.5 cpus, cpu-shares 256 against a default 1024 web process`,where:`POD_DOCKER_CPUS`},{name:`pids`,value:`256`,where:`runner.build_command`},{name:`network`,value:`none. Craft cannot reach Fourthwall or the agent.`,where:`--network none`},{name:`privileges`,value:`cap-drop ALL, no-new-privileges, read-only root`,where:`docker run`},{name:`tmp`,value:`tmpfs /tmp, 512m, HOME=/tmp`,where:`docker run`},{name:`mounts`,value:`only that run's sandbox and build directories`,where:`-v work -v build`},{name:`native`,value:`nice -n 10 and ionice idle class. nice is not applied to the docker client.`,where:`POD_NICE_LEVEL`},{name:`logs`,value:`streamed. Disk cap 5 MiB. Agent digest 20 error lines, 12 tail lines, 2000 characters.`,where:`logfilter.py`},{name:`postgres`,value:`error_digest sliced to 8000 characters. Sync payloads capped at 32 KiB.`,where:`db.py · schema.sql`}],$=[{name:`trace exit 1`,value:`Tier-1 raster fallback. trace_state becomes raster_fallback. The run continues.`},{name:`other trace exit`,value:`trace_state trace_failed. The run fails. No second tracer.`},{name:`exit -9, -15, 137, 143, 75`,value:`Transient. Retried up to POD max_attempts, default 2.`},{name:`step timeout`,value:`Process group SIGTERM, then SIGKILL. Docker container is killed by name. Transient.`},{name:`validator reject`,value:`Not retried. The same binary would write the same file.`},{name:`flush timeout`,value:`Output never settled for two polls. The step fails.`},{name:`sha256 mismatch`,value:`Asset quarantined before any Craft process starts.`},{name:`Fourthwall 406`,value:`publish_state needs_manual_upload. The run itself succeeds.`},{name:`create 5xx`,value:`Not retried. A retry could duplicate the product.`},{name:`429`,value:`Up to three retries using Retry-After. Upload-url is also capped at 20 per minute.`},{name:`worker vanished`,value:`recover_stale_runs sees a dead pid and puts the orchestrator row back to queued.`}];function me({onOpen:e}){return(0,v.jsxs)(`div`,{className:`flex flex-col gap-6`,children:[(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`h2`,{className:`text-xl font-medium`,children:`Sandbox and faults`}),(0,v.jsx)(`p`,{className:`mt-1 max-w-3xl text-sm text-pretty text-muted`,children:`Docker limits are what protect the web server. nice on the docker client would not reach processes the daemon starts.`})]}),(0,v.jsxs)(`section`,{children:[(0,v.jsx)(`h3`,{className:`text-base font-medium`,children:`Tree`}),(0,v.jsx)(`pre`,{className:`mt-2 overflow-x-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg`,children:m})]}),(0,v.jsxs)(`section`,{children:[(0,v.jsxs)(`div`,{className:`flex flex-wrap items-center justify-between gap-2`,children:[(0,v.jsx)(`h3`,{className:`text-base font-medium`,children:`Docker wrap`}),(0,v.jsx)(X,{text:h})]}),(0,v.jsx)(`pre`,{className:`mt-2 overflow-x-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg`,children:h}),(0,v.jsxs)(`p`,{className:`mt-2 text-sm text-muted`,children:[`Native mode, when POD_USE_DOCKER is off: `,ee]})]}),(0,v.jsxs)(`section`,{children:[(0,v.jsx)(`h3`,{className:`text-base font-medium`,children:`Limits`}),(0,v.jsx)(`ul`,{className:`mt-2 border border-fg/10`,children:pe.map(e=>(0,v.jsxs)(`li`,{className:`grid gap-1 border-b border-fg/10 p-3 last:border-b-0 md:grid-cols-[8rem_1fr]`,children:[(0,v.jsx)(`span`,{className:`font-mono text-xs text-brass`,children:e.name}),(0,v.jsxs)(`span`,{className:`text-sm`,children:[e.value,(0,v.jsx)(`span`,{className:`mt-1 block font-mono text-xs text-muted`,children:e.where})]})]},e.name))})]}),(0,v.jsxs)(`section`,{children:[(0,v.jsx)(`h3`,{className:`text-base font-medium`,children:`What happens when a step fails`}),(0,v.jsx)(`ul`,{className:`mt-2 border border-fg/10`,children:$.map(e=>(0,v.jsxs)(`li`,{className:`grid gap-1 border-b border-fg/10 p-3 last:border-b-0 md:grid-cols-[11rem_1fr]`,children:[(0,v.jsx)(`span`,{className:`font-mono text-xs text-brass`,children:e.name}),(0,v.jsx)(`span`,{className:`text-sm text-pretty`,children:e.value})]},e.name))}),(0,v.jsx)(`button`,{type:`button`,className:`mt-3 h-11 border border-fg/15 px-3 text-sm text-fg hover:border-brass`,onClick:()=>e(`pod_pipeline/runner.py`),children:`Open runner.py`})]})]})}function he({file:e,onFile:t}){let n=J.find(t=>t.path===e)??J[0];return(0,v.jsxs)(`div`,{className:`grid gap-4 md:grid-cols-[16rem_1fr]`,children:[(0,v.jsxs)(`div`,{className:`min-w-0`,children:[(0,v.jsxs)(`label`,{className:`mb-3 block md:hidden`,children:[(0,v.jsx)(`span`,{className:`mb-1 block text-xs tracking-wide text-muted`,children:`Source`}),(0,v.jsx)(`select`,{className:`h-11 w-full border border-fg/15 bg-bg px-2 text-sm text-fg`,value:n.path,onChange:e=>t(e.target.value),children:q.map(e=>(0,v.jsx)(`optgroup`,{label:e.label,children:J.filter(t=>t.group===e.id).map(e=>(0,v.jsx)(`option`,{value:e.path,children:e.path},e.path))},e.id))})]}),(0,v.jsx)(`div`,{className:`hidden md:block`,children:q.map(e=>(0,v.jsxs)(`div`,{className:`mb-4`,children:[(0,v.jsx)(`p`,{className:`mb-1 text-xs tracking-wide text-muted`,children:e.label}),(0,v.jsx)(`ul`,{children:J.filter(t=>t.group===e.id).map(e=>(0,v.jsx)(`li`,{children:(0,v.jsx)(`button`,{type:`button`,className:`w-full truncate px-2 py-2 text-left font-mono text-xs `+(e.path===n.path?`bg-fg/10 text-brass`:`text-fg hover:bg-fg/5`),onClick:()=>t(e.path),children:e.path.split(`/`).pop()})},e.path))})]},e.id))})]}),(0,v.jsx)(ge,{file:n})]})}function ge({file:e}){let t=e.source.split(`
`).length,n=e.path.split(`/`).pop()??e.path;return(0,v.jsxs)(`section`,{className:`min-w-0`,children:[(0,v.jsxs)(`div`,{className:`flex flex-wrap items-center justify-between gap-2`,children:[(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`h2`,{className:`font-mono text-sm`,children:e.path}),(0,v.jsxs)(`p`,{className:`font-mono text-xs text-muted tabular-nums`,children:[t,` lines`]})]}),(0,v.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,v.jsx)(X,{text:e.source}),(0,v.jsx)(Z,{filename:n,text:e.source})]})]}),(0,v.jsx)(`pre`,{className:`mt-2 max-h-screen overflow-auto border border-fg/10 p-3 font-mono text-xs leading-relaxed text-fg`,children:e.source})]})}var _e=[{id:`board`,label:`Board`},{id:`routes`,label:`Routes`},{id:`sandbox`,label:`Sandbox`},{id:`playbook`,label:`Playbook`},{id:`sources`,label:`Sources`}];function ve(){let[e,t]=(0,c.useState)(`board`),[n,r]=(0,c.useState)(`apparel`),[i,a]=(0,c.useState)(!1),[o,s]=(0,c.useState)(!0),[l,u]=(0,c.useState)(`pod_pipeline/routes.py`);function d(e){u(e),t(`sources`)}return(0,v.jsxs)(`div`,{className:`min-h-screen bg-bg text-fg`,children:[(0,v.jsxs)(`header`,{className:`flex items-center justify-between gap-4 border-b border-fg/10 px-4 py-3`,children:[(0,v.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,v.jsx)(`img`,{src:`/favicon.svg`,alt:``,width:32,height:32,className:`size-8`}),(0,v.jsxs)(`div`,{children:[(0,v.jsx)(`p`,{className:`text-xs font-medium tracking-wide text-brass`,children:`DEERFLOW`}),(0,v.jsx)(`h1`,{className:`text-lg font-medium leading-tight`,children:`Forge`})]})]}),(0,v.jsxs)(`div`,{className:`hidden text-right sm:block`,children:[(0,v.jsx)(`p`,{className:`text-sm`,children:`pod_pipeline`}),(0,v.jsx)(`p`,{className:`font-mono text-xs text-muted`,children:`Fourthwall Open API · DeepSeek V4.1-Flash`})]})]}),(0,v.jsxs)(`div`,{className:`md:flex`,children:[(0,v.jsx)(`nav`,{className:`flex gap-2 overflow-x-auto border-b border-fg/10 p-3 md:w-44 md:shrink-0 md:flex-col md:border-r md:border-b-0`,"aria-label":`Sections`,children:_e.map(n=>{let r=n.id===e;return(0,v.jsx)(`button`,{type:`button`,"aria-current":r?`page`:void 0,className:`h-11 shrink-0 border-l-2 px-3 text-left text-sm `+(r?`border-brass bg-fg/10 text-fg`:`border-transparent text-muted hover:text-fg`),onClick:()=>t(n.id),children:n.label},n.id)})}),(0,v.jsxs)(`main`,{className:`min-w-0 flex-1 p-4`,children:[e===`board`?(0,v.jsx)(re,{family:n,onFamily:r,traceFails:i,onTraceFails:a,docker:o,onDocker:s}):null,e===`routes`?(0,v.jsx)(fe,{family:n,onFamily:r}):null,e===`sandbox`?(0,v.jsx)(me,{onOpen:d}):null,e===`playbook`?(0,v.jsx)(de,{onOpen:d}):null,e===`sources`?(0,v.jsx)(he,{file:l,onFile:u}):null]})]})]})}function ye(){return(0,v.jsx)(ve,{})}export{ye as component};